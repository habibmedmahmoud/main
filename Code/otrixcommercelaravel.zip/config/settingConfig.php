<?php 
return [
 'config_smtp_hostname' => 'smtp.googlemail.com'  ,
 'config_mail_engine' => 'smtp'  ,
 'config_youtube_url' => 'https://www.youtube.com/channel/UCiWzLziMAOk-oB0pig8TkEg/'  ,
 'config_insta_url' => 'https://www.instagram.com/'  ,
 'config_twitter_url' => 'https://twitter.com/login?lang=en'  ,
 'config_linkedin_url' => 'https://www.linkedin.com/'  ,
 'config_fb_url' => 'https://www.facebook.com/'  ,
 'config_meta_tag_keywords' => 'asd'  ,
 'config_meta_tag_description' => 'asd'  ,
 'config_meta_title' => 'sad'  ,
 'config_store_url' => 'Otrix.com'  ,
 'config_currency' => '$'  ,
 'config_fax' => '380001'  ,
 'config_telephone' => '09898989898'  ,
 'config_email' => 'otrixapp@gmail.com'  ,
 'config_geocode' => ''  ,
 'config_address' => 'Building Number 121
Ground floor, Office 2 Otrixweb
Commercial, Otrixcity'  ,
 'config_store_owner' => 'Otrix'  ,
 'config_store_name' => 'Otrixcommerce'  ,
 'config_smtp_username' => 'otrixapp@gmail.in'  ,
 'config_smtp_password' => 'tttr'  ,
 'config_smtp_port' => '25'  ,
 'config_smtp_timeout' => '25'  ,
 'config_alert_mail' => 'Register,Orders'  ,
];
