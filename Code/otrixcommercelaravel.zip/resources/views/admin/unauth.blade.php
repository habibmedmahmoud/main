@extends('admin.layouts.app')

@section('content')

    <div class="container-fluid mt-7" style="min-height:800px;">
          <p class="text-center " style="font-size:6rem;font-weight:700;color:red">You don't have access</p>
        </div>
    </div>
@endsection
