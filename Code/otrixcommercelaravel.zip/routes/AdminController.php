<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Validator;

class AdminController extends Controller
{

    public function __construct()
    {
      //  $this->middleware('auth');
    }

    public function index() {
        dd('admin controller');
    }

    public function add() {
        $types = ['type 1','type 2','type 3','type 4'];
        return view('admin.customer.add',compact('types')); //most cases
    }

    public function store(Request $request) {

        $rules = array(
          'firstname' => 'required|min:6|max:15|isNumeric', // make sure the email is an actual email
        );

        $validator = Validator::make($request->all(), $rules);

        if ($validator->fails()) {
            return redirect()->back()->withErrors($validator) // send back all errors to the login form
                ->withInput(); // send back the input (not the password) so that we can repopulate the form
        }

        //here
        dd($request->all());


    }

    public function customer() {

    }


}
