<?php
use App\Models\Language;

    function setPermissionValue($val1,$val2) {

         return $val1 == $val2 ? $val1 : "$val1.$val2";
    }

    function getPermissionGroupName($value) {
        $array = explode('.',$value);
         return $array[0];
    }

    function getLanguages() {
         return Language::where('status',1)->orderBy('created_at','ASC')->get();
    }

?>
