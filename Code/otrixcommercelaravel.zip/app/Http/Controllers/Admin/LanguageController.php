<?php

namespace App\Http\Controllers\Admin;

use App\Models\Language;
use App\Http\Controllers\Controller;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class LanguageController extends Controller
{

    protected $path = '';

    public function __construct()
    {
    }

    public function index(Request $request) {
        $name = $request->get('name', '');
        $records = Language::whereDeletedAt(null)->orderBy('created_at','DESC')->paginate($this->defaultPaginate);
        return view('admin.language.index',['records' => $records]);
    }

    public function add() {
        return view('admin.language.add');
    }

    public function store(Request $request) {

        $this->validate($request, [
            'language_name' => ['required', 'string', 'max:255', 'unique:language'],
            'code' => ['required'],
        ]);

        $language = new Language($request->only('language_name','default_lang','code','status'));

        //set session language
        if($request->default_lang == 1) {
          Language::query()->update(['default_lang' => 0]);
          Language::where('id',$language->id)->update(['default_lang' => 1]);
          session()->put('currentLanguage',$language->id);
          session()->save();
        }

        $language->save();

        return redirect(route('language'))->with('success','Language Created Successfully');
    }

    public function edit($id) {

        return view('admin.language.edit',[
            'data' => Language::findOrFail($id),
        ]);
    }

    public function update(Request $request,$id) {

        $this->validate($request, [
            'language_name' => ['required', 'string', 'max:255', 'unique:language,language_name,'.$id.',id'],
        ]);

        //Update Language
        $language = Language::findOrFail($id);

        //set session language
        if($request->default_lang == 1) {
          Language::query()->update(['default_lang' => 0]);
          Language::where('id',$id)->update(['default_lang' => 1]);
          session()->put('currentLanguage',$id);
          session()->save();
        }

        $language->fill($request->only('default_lang','language_name','status','code'))->save();

        return redirect(route('language'))->with('success','Language Updated Successfully');
    }

    public function delete($id) {

        Language::where('id',$id)->delete();

        return redirect(route('language'))->with('success', 'Language  Deleted Successfully');
    }
}
