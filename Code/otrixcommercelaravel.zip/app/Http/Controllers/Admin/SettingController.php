<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use App\Traits\CustomFileTrait;
use Illuminate\Http\Request;

class SettingController extends Controller
{
    use CustomFileTrait;
    protected $path = '';

    public function __construct() {
        $this->path = public_path(config('constant.file_path.store'));
    }

    public function index(Request $request) {

        $name = $request->get('name', '');

        $records = Setting::select('id','store_id', 'key','value')
            ->whereIn('key',['config_store_name'])
            ->when($name != '', function($q) use($name) {
                    $q->where('config_store_name','like',"%$name%");
            })->paginate($this->defaultPaginate);

        return view('admin.setting.index',['records' => $records]);
    }

    public function add() {
        return view('admin.setting.add',[]);
    }

    protected function validateData ($request) {
        $this->validate($request, [
            'name' => ['required', 'string', 'max:255']
        ]);
    }

    protected function saveAndGetStoreImageArray($imageArray) {
        $dataArray = [];

        foreach($imageArray as $key => $value) {
//            $image = null;
//            $image = $this->saveCustomFileAndGetImageName($value,$this->path);

            $dataArray[] = Setting::setKeyValueArray($key,$this->saveCustomFileAndGetImageName($value,$this->path));

//            $dataArray[] = ['key' => $key,
//            'value' => $this->saveCustomFileAndGetImageName($value,$this->path)];
        }
        return $dataArray;
    }

    protected function getRequestData () {
        return request()->except(array_merge(['_token','_method',Setting::ConfigAlertMail],  Setting::$imageArray));
    }

    public function store(Request $request) {

        $requestData = $this->getRequestData();
        $requestDataArray = [];

        $imageArray = $this->saveAndGetStoreImageArray($request->only(Setting::$imageArray));

        $maxStoreId = Setting::getMaxRowNumber();

        $configAlertMail = $request->only(Setting::ConfigAlertMail);
        $configAlertMailArray = Setting::getconfigAlertMailArray ($configAlertMail, $maxStoreId);

        foreach($requestData as $key => $val) {
            $requestDataArray[] = Setting::setKeyValueArray($key,$val);
        }

        $storingDataArray = array_merge($requestDataArray,$imageArray);
        data_set($storingDataArray,'*.store_id',$maxStoreId);
        $storingDataArray[] = $configAlertMailArray;

        Setting::insert($storingDataArray);

        return response()->json([
                'code' => 200,
                'msg' => 'Store Created Successfully',
                'route' => route('setting')
            ]
            ,200);
    }

    public function edit($id) {


        $data = Setting::select('key','value')->whereStoreId($id)->pluck('value','key')->toArray();

        return view('admin.setting.edit',[
            'data' => $data,
        ]);
    }

    public function update(Request $request,$id) {

        $images = Setting::select('value')->where('store_id', $id)->whereIn('key',['config_store_image','config_icon_image','config_image'])->pluck('value')->toArray();
        $this->deleteImages($images);

        Setting::deleteByStoreId($id);

        $requestData = $this->getRequestData();
        $requestDataArray = [];

        $imageArray = $this->saveAndGetStoreImageArray($request->only(Setting::$imageArray));
        $maxStoreId = $id;

        $configAlertMail = $request->only(Setting::ConfigAlertMail);
        $configAlertMailArray = Setting::getconfigAlertMailArray ($configAlertMail, $maxStoreId);

        foreach($requestData as $key => $val) {
            $requestDataArray[] = Setting::setKeyValueArray($key,$val);
        }

        $storingDataArray = array_merge($requestDataArray,$imageArray);
        data_set($storingDataArray,'*.store_id',$maxStoreId);
        $storingDataArray[] = $configAlertMailArray;

        Setting::insert($storingDataArray);
        $getSetting   = Setting::all();
        $val  =		"<?php \n";
        $val  .= 	"return [\n";
        foreach ($getSetting as $key => $value) {
            $val  .= " '".$value->key."' => '".addslashes ($value->value)."'  ,\n";
        }
        $val  .= 	"];\n";
        			$filename = base_path().'/config/settingConfig.php';
        			$fp=fopen($filename,"w+");
        			fwrite($fp,$val);
        			fclose($fp);
        return response()->json([
                'code' => 200,
                'msg' => 'Store Updated Successfully',
                'route' => route('setting')
            ]
            ,200);
    }

    protected function deleteImages($images) {

        foreach($images as $key => $val) {
            $this->removeOldImage($val,$this->path);
        }

    }

    public function delete($id) {
        if(! $data = Order::whereId($id)->first()) {
            return redirect()->back()->with('error', 'Something went wrong');
        }

        OrderProduct::whereOrderId($data->id)->delete();
        OrderHistory::whereOrderId($data->id)->delete();
        $data->delete();
        return redirect(route('order'))->with('success', 'Order  Deleted Successfully');
    }
}
