<?php

namespace App\Providers;

use Config;
use Illuminate\Support\ServiceProvider;
use Illuminate\Pagination\Paginator;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }

    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
      //set mail config dynamic
      $config = array(
                   'driver'     => config('settingConfig.config_mail_engine'),
                   'host'       => config('settingConfig.config_smtp_hostname'),
                   'port'       => config('settingConfig.config_smtp_port'),
                   'from'       => array('address' => config('settingConfig.config_email'), 'name' =>config('settingConfig.config_store_name')),
                   'encryption' => 'tls',
                   'username'   => config('settingConfig.config_smtp_username'),
                   'password'   => config('settingConfig.config_smtp_password'),
                   'sendmail'   => '/usr/sbin/sendmail -bs',
                   'pretend'    => false,
               );

        Config::set('mail', $config);

        Paginator::useBootstrap();

    }
}
