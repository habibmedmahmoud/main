<footer class="footer">
    <?php echo $__env->make('admin.layouts.footers.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>
<?php /**PATH G:\php\www\otrixcommercelaravel\resources\views/admin/layouts/footers/auth.blade.php ENDPATH**/ ?>