

<?php $__env->startSection('content'); ?>

    <div class="container-fluid mt-7" style="min-height:800px;">
          <p class="text-center " style="font-size:6rem;font-weight:700;color:red">You don't have access</p>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/u554892978/domains/otrixcommerce.in/public_html/resources/views/admin/unauth.blade.php ENDPATH**/ ?>