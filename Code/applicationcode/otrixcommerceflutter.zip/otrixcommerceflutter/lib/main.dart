import 'dart:io';

import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/MyBehavior.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/core/global_theme.dart';
import 'package:ecommerce/firebase_options.dart';
import 'package:ecommerce/provider/app_provider.dart';
import 'package:ecommerce/provider/dashboard_provider.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/provider/language_provider.dart';
import 'package:ecommerce/provider/login_register_provider.dart';
import 'package:ecommerce/ui/screens/splash_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:provider/provider.dart';

/// Initialize the [FlutterLocalNotificationsPlugin] package.
late FlutterLocalNotificationsPlugin flutterLocalNotificationsPlugin;

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: commonBackgroundColor,
      statusBarIconBrightness:
          Brightness.dark //or set color with: Color(0xFF0000FF)
      ));

  await initiateFirebase();
  runApp(const MyApp());
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: commonBackgroundColor,
      statusBarIconBrightness: Brightness.dark));
}

initiateFirebase() async {
  WidgetsFlutterBinding.ensureInitialized();
  // await Firebase.initializeApp();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );

  if (!kIsWeb) {
    flutterLocalNotificationsPlugin = FlutterLocalNotificationsPlugin();
    if (Platform.isAndroid) {
      AndroidNotificationChannel channel = const AndroidNotificationChannel(
        'high_importance_channel', // id
        'High Importance Notifications', // title
        description:
            'This channel is used for important notifications.', // description
        importance: Importance.high,
      );

      await flutterLocalNotificationsPlugin
          .resolvePlatformSpecificImplementation<
              AndroidFlutterLocalNotificationsPlugin>()
          ?.createNotificationChannel(channel);
    }

    await FirebaseMessaging.instance
        .setForegroundNotificationPresentationOptions(
      alert: true,
      badge: true,
      sound: true,
    );
  }
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => LoginRegisterProvider()),
        ChangeNotifierProvider(create: (_) => HomeProvider()),
        ChangeNotifierProvider(create: (_) => DashboardProvider()),
        ChangeNotifierProvider(
          create: (_) => AppProvider(),
        ),
        ChangeNotifierProvider(
          create: (_) => LanguageProvider(),
        ), /*
        ChangeNotifierProvider(
          create: (_) => ProductProvider(),
        ),*/
      ],
      child: MaterialApp(
        title: 'Otrixcommece Flutter',
        scaffoldMessengerKey: AppGlobal.scaffoldMessengerKey,
        debugShowCheckedModeBanner: false,
        builder: (context, child) {
          return ScrollConfiguration(
            behavior: MyBehavior(),
            child: child ?? const SplashScreen(),
          );
        },
        theme: themeData ,
        home: const SplashScreen(),
      ),
    );
  }
}
