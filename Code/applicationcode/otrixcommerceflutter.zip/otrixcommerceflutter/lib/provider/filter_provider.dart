import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_sliders/sliders.dart';

class FilterProductListProvider extends ChangeNotifier {
  int selectedPrice = 0;
  int selectedRangeStart = 0;
  int selectedRangeEnd = 0;
  double rageLimit = 100;
  int selectedStar = 0;
  bool isDataChanged = false;

  FilterProductListProvider(
      {
      required this.selectedStar,
      required this.selectedRangeStart,
      required this.selectedRangeEnd,
      required this.rageLimit,
      required this.selectedPrice});

  setSelectedPrice(int price) {
    selectedPrice = price;
    isDataChanged = true;
    notifyListeners();
  }

  updateRangeValue(SfRangeValues rangeValues) {
    try{
      selectedRangeStart=int.parse(rangeValues.start.round().toString());
      selectedRangeEnd=int.parse(rangeValues.end.round().toString());
      isDataChanged = true;
      notifyListeners();
    }catch(ex){
      print("exception == ${ex.toString()}");
    }
  }

  setSelectedRating(int rating) {
    selectedStar = rating;
    isDataChanged = true;
    notifyListeners();
  }
}
