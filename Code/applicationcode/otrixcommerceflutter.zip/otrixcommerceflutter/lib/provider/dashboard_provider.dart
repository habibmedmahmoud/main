import 'package:flutter/foundation.dart';

// ignore: constant_identifier_names
enum DashboardScreenView { HOME, LOGIN, REGISTER, CATEGORIES, PROFILE, SETTING, CART, PROFILE_LOGIN, PROFILE_REGISTER,  }

class DashboardProvider extends ChangeNotifier {
  DashboardScreenView currentView = DashboardScreenView.HOME;


  changeViewNotifier(DashboardScreenView view) {
    currentView = view;
    notifyListeners();
  }
}
