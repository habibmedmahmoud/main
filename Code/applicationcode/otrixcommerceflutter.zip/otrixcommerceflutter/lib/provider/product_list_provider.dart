import 'package:dio/dio.dart';
import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/models/common_response.dart';
import 'package:ecommerce/models/home_model/ResponseHome.dart';
import 'package:ecommerce/models/product_list_models/pagination_product_list.dart';
import 'package:ecommerce/models/product_list_models/product_list.dart';
import 'package:ecommerce/network/api_request.dart';
import 'package:flutter/foundation.dart';

import '../core/Constants.dart';

class ProductListProvider extends ChangeNotifier {
  bool showFilter;
  bool isPagination;
  bool isLoading = false;
  String url;
  String title;
  int page = 1;
  List<Products> productsList = [];
  int selectedPrice = 0;
  int selectedRangeStart = 0;
  int selectedRangeEnd = 0;
  int selectedStar = 0;
  int lastPage = 1;
  double rageLimit = 1000;
  bool isMoreLoading = false;

  ProductListProvider(
      this.showFilter, this.isPagination, this.url, this.title) {
    isLoading = true;
    if (isPagination) {
      callToGetPaginationProductList(1);
    } else {
      callToGetNonPaginationProductList();
    }
  }

  callToGetNonPaginationProductList() async {
    notifyListeners();
    var response = await ApiRequest().getCommonApiCall(url);

    try {
      if (response is Response) {
        if (response.data is Map<String, dynamic>) {
          CommonResponse commonResponse =
              CommonResponse.fromJson(response.data);
          if (commonResponse.status! == 1) {
            ProductList responseHome = ProductList.fromJson(response.data);
            if (responseHome.data != null) {
              productsList.clear();
              productsList.addAll(responseHome.data ?? []);
              notifyListeners();
            }
          } else {
            AppGlobal.showToast(
                commonResponse.message ?? Constants.something_wrong);
          }
        } else if (response is DioError) {
          AppGlobal.showToast(Constants.something_wrong);
        }
      } else if (response is DioError) {
        AppGlobal.showToast(Constants.something_wrong);
      } else {
        AppGlobal.showToast(Constants.something_wrong);
      }
    } catch (exc) {
      if (kDebugMode) {
        print("exception === ${exc.toString()}");
      }
    }
    isLoading = false;
    notifyListeners();
  }

  callToGetPaginationProductList(int i) async {
    page = i;
    print("page == $page");
    String passUrl = "$url?page=$i";
    if (selectedPrice > 0) {
      passUrl = "$passUrl&filterPrice=$selectedPrice";
    }
    if (selectedRangeEnd > 0) {
      passUrl =
          "$passUrl&filterPriceRange=$selectedRangeStart,$selectedRangeEnd";
    }
    if (selectedStar > 0) {
      passUrl = "$passUrl&filterRating=$selectedStar";
    }
    if (i == 1) {
      productsList.clear();
      isLoading = true;
      lastPage = 1;
    } else {
      isMoreLoading = true;
    }
    notifyListeners();

    var response = await ApiRequest().getCommonApiCall(url);

    try {
      if (response is Response) {
        if (response.data is Map<String, dynamic>) {
          CommonResponse commonResponse =
              CommonResponse.fromJson(response.data);
          if (commonResponse.status! == 1) {
            PaginationProductList responseHome =
                PaginationProductList.fromJson(response.data);
            if (responseHome.productsList != null) {
              if (responseHome.productsList!.data != null) {
                productsList.addAll(responseHome.productsList!.data ?? []);
                notifyListeners();
              }
              lastPage = responseHome.productsList!.lastPage ?? 1;
              notifyListeners();
            }
          } else {
            AppGlobal.showToast(
                commonResponse.message ?? Constants.something_wrong);
          }
        } else if (response is DioError) {
          AppGlobal.showToast(Constants.something_wrong);
        }
      } else if (response is DioError) {
        AppGlobal.showToast(Constants.something_wrong);
      } else {
        AppGlobal.showToast(Constants.something_wrong);
      }
    } catch (exc) {
      if (kDebugMode) {
        print("exception === ${exc.toString()}");
      }
    }
    isLoading = false;
    isMoreLoading = false;
    notifyListeners();
  }



  void updateFilterData(
      {required selectedPrice,
      required selectedRangeStart,
      required selectedRangeEnd,
      required selectedStar}) {
    this.selectedPrice = selectedPrice;
    this.selectedRangeStart = selectedRangeStart;
    this.selectedRangeEnd = selectedRangeEnd;
    this.selectedStar = selectedStar;
    callToGetPaginationProductList(1);
  }
}
