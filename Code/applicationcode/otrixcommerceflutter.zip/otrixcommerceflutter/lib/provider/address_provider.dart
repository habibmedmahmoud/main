import 'package:dio/dio.dart';
import 'package:ecommerce/models/address/add_update_address.dart';
import 'package:ecommerce/models/address/address_model.dart';
import 'package:ecommerce/models/address/address_response.dart';
import 'package:ecommerce/models/address/countriesModel.dart';
import 'package:ecommerce/network/api_request.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:flutter/material.dart';

class AddressProvider extends ChangeNotifier {
  bool isAddShow = false;
  bool isListLoading = true;
  bool addAddressLoading = false;
  late BuildContext context;
  String? slectedCountryText;
  List<AddressModel> addressList = [];
  List<CountryModel> countryList = [];
  CountryModel? selectedCountry;
  bool countryChange = false;

  AddressProvider(this.context) {
    fetchAddressList();
  }

  fetchAddressList() async {
    var response = await ApiRequest().getCommonApiCall(ApiServices.getAddress);
    try {
      AddressResponse responseHome = AddressResponse.fromJson(response.data);
      if (responseHome.data != null) {
        countryList.addAll(responseHome.countries ?? []);
        addressList.addAll(responseHome.data ?? []);
        notifyListeners();
      }
      // ignore: empty_catches
    } catch (ex) {}
    isListLoading = false;
    notifyListeners();
  }

  selectCountry(CountryModel? country) {
    selectedCountry = country;
    countryChange = true;
    notifyListeners();
    countryChange = false;
    addAddressLoading = false;
    notifyListeners();
  }

  Future<bool> addAddress(Map<String, dynamic> data) async {
    addAddressLoading = true;
    notifyListeners();
    var response = await ApiRequest()
        .postCommonApiCall(FormData.fromMap(data), ApiServices.addAddress);
    if (response != null) {
      try {
        AddUpdateAddress addUpdateAddress =
            AddUpdateAddress.fromJson(response.data);
        addressList.clear();
        addressList.addAll(addUpdateAddress.addresses ?? []);
        addAddressLoading = false;
        notifyListeners();
        return true;
        // ignore: empty_catches
      } catch (ex) {}
    }
    addAddressLoading = false;
    notifyListeners();
    return false;
  }

  Future<bool> updateAddress(Map<String, dynamic> data, String id) async {
    addAddressLoading = true;
    notifyListeners();
    var response = await ApiRequest().postCommonApiCall(
        FormData.fromMap(data), "${ApiServices.editAddress}$id");
    if (response != null) {
      try {
        AddUpdateAddress addUpdateAddress =
            AddUpdateAddress.fromJson(response.data);
        addressList.clear();
        addressList.addAll(addUpdateAddress.addresses ?? []);
        addAddressLoading = false;
        notifyListeners();
        return true;
        // ignore: empty_catches
      } catch (ex) {}
    }
    addAddressLoading = false;
    notifyListeners();
    return false;
  }

   Future<bool> deleteAddress(AddressModel addressItem) async {

     notifyListeners();
     var response = await ApiRequest().postCommonApiCall(
         FormData.fromMap({}), "${ApiServices.deleteAddress}${addressItem.id}");
     if (response != null) {
       try {
         AddUpdateAddress addUpdateAddress =
         AddUpdateAddress.fromJson(response.data);
         addressList.clear();
         addressList.addAll(addUpdateAddress.addresses ?? []);
         addAddressLoading = false;
         notifyListeners();
         return true;
         // ignore: empty_catches
       } catch (ex) {}
     }
     notifyListeners();
     return false;

   }
}
