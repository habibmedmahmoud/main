import 'package:flutter/material.dart';

class LanguageProvider extends ChangeNotifier {
  String selectedLanguage = "en";

  changeLanguage(String newLang) {
    selectedLanguage = newLang;
    notifyListeners();
  }
}
