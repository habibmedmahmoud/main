// ignore_for_file: empty_catches

import 'dart:convert';
import 'dart:io';

import 'package:dio/dio.dart';
import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/Constants.dart';
import 'package:ecommerce/models/BrandsResponse.dart';
import 'package:ecommerce/models/Category.dart';
import 'package:ecommerce/models/CategoryResponse.dart';
import 'package:ecommerce/models/UserData.dart';
import 'package:ecommerce/models/auth/LoginResponse.dart';
import 'package:ecommerce/models/auth/UpdateProfileResponse.dart';
import 'package:ecommerce/models/cart/ApplyDiscountResponse.dart';
import 'package:ecommerce/models/cart/CartData.dart';
import 'package:ecommerce/models/cart/CartResponse.dart';
import 'package:ecommerce/models/cart/Discount.dart';
import 'package:ecommerce/models/common_response.dart';
import 'package:ecommerce/models/home_model/ResponseHome.dart';
import 'package:ecommerce/network/api_request.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/foundation.dart';
import 'package:google_sign_in/google_sign_in.dart';

class HomeProvider extends ChangeNotifier {
  bool isHomeDataLoaded = false;
  bool isBrandLoading = false;
  bool isLoginLoading = false;
  bool isRegisterLoading = false;
  bool isUserLoggedIn = false;
  bool imageUploading = false;
  bool profileUpdating = false;
  bool cartItemsLoading = false;
  bool catLoading = false;
  UserData? userData;

  late List<Categories> categories = [];
  Banners? banners;
  List<String> wishListItems = [];

  List<Categories> categoriesLis = [];
  List<Products> newProducts = [];
  List<Products> trendingProducts = [];
  List<Products> dodProducts = [];
  List<BrandsData> brandsList = [];
  List<BrandsData> manufacturersList = [];

  //Cart
  List<CartData> cartItemList = [];
  CartResponse? cartResponse;
  int cartCount = 0;
  Discount? discount;
  String? grandTotalNew;

  fetchHomeData() async {
    getUserData();
    var response = await ApiRequest().getCommonApiCall(ApiServices.homePage);

    if (response is Response) {
      if (response.data is Map<String, dynamic>) {
        CommonResponse commonResponse = CommonResponse.fromJson(response.data);
        if (commonResponse.status! == 1) {
          ResponseHome responseHome = ResponseHome.fromJson(response.data);
          if (responseHome.data != null) {
            categories = responseHome.data!.categories ?? [];
            banners = (responseHome.data!.banners ?? {}) as Banners?;
            newProducts = (responseHome.data!.newProducts ?? []);
            trendingProducts = (responseHome.data!.trendingProducts ?? []);
            dodProducts = (responseHome.data!.dodProducts ?? []);
            manufacturersList = (responseHome.data!.manufacturers ?? []);
          }
        } else {
          AppGlobal.showToast(
              commonResponse.message ?? Constants.something_wrong);
        }
      } else {
        AppGlobal.showToast(Constants.something_wrong);
      }
    } else if (response is DioError) {
      AppGlobal.showToast(Constants.something_wrong);
    } else {
      AppGlobal.showToast(Constants.something_wrong);
    }
    isHomeDataLoaded = true;
    notifyListeners();
  }

  fetCategoriesResponse() async {
    catLoading=true;
    notifyListeners();
    var response =
        await ApiRequest().getCommonApiCall(ApiServices.getCategories);

    if (response is Response) {
      if (response.data is Map<String, dynamic>) {
        CommonResponse commonResponse = CommonResponse.fromJson(response.data);
        if (commonResponse.status! == 1) {
          CategoryResponse responseHome =
              CategoryResponse.fromJson(response.data);
          if (responseHome.data != null) {
            categoriesLis.clear();
            categoriesLis.addAll(responseHome.data!);
          }
        } else {
          AppGlobal.showToast(
              commonResponse.message ?? Constants.something_wrong);
        }
      } else {
        AppGlobal.showToast(Constants.something_wrong);
      }
    } else if (response is DioError) {
      AppGlobal.showToast(Constants.something_wrong);
    } else {
      AppGlobal.showToast(Constants.something_wrong);
    }
    catLoading = false;
    notifyListeners();
  }

  fetBrandsResponse() async {
    isBrandLoading = true;
    notifyListeners();
    var response =
        await ApiRequest().getCommonApiCall(ApiServices.getManufacturers);

    if (response is Response) {
      if (response.data is Map<String, dynamic>) {
        CommonResponse commonResponse = CommonResponse.fromJson(response.data);
        if (commonResponse.status! == 1) {
          BrandsResponse responseHome = BrandsResponse.fromJson(response.data);
          if (responseHome.data != null) {
            brandsList.clear();
            brandsList.addAll(responseHome.data!);
            notifyListeners();
          }
        } else {
          AppGlobal.showToast(
              commonResponse.message ?? Constants.something_wrong);
        }
      } else {
        AppGlobal.showToast(Constants.something_wrong);
      }
    } else if (response is DioError) {
      AppGlobal.showToast(Constants.something_wrong);
    } else {
      AppGlobal.showToast(Constants.something_wrong);
    }
    isBrandLoading = true;
    notifyListeners();
  }

  Future<UserData?> getUserData() async {
    bool result = await checkSession();

    userData = null;
    isUserLoggedIn = false;
    cartCount = 0;
    wishListItems.clear();
    if (result) {
      try {
        String userD = await AppGlobal.getString(Constants.user_data);
        if (userD.isNotEmpty) {
          try {
            userData = UserData.fromJson(jsonDecode(userD));
            isUserLoggedIn = true;
            cartCount = await AppGlobal.getInt(Constants.cartCount) ?? 0;
            wishListItems.clear();
            wishListItems
                .addAll(await AppGlobal.getStringList(Constants.wishList));
            notifyListeners();
            return userData;
          } catch (ex) {
            return null;
          }
        }
      } catch (ex) {
        debugPrint("Exception=== $ex");
      }
    }
    return null;
  }

  loginUser(Map<String, String> mapValue) async {
    isLoginLoading = true;
    notifyListeners();
    print("map=== ${mapValue.toString()}");
    final data = FormData.fromMap(mapValue);

    var response =
        await ApiRequest().postCommonApiCall(data, ApiServices.login);

    if (response is Response) {
      if (response.data is Map<String, dynamic>) {
        CommonResponse commonResponse = CommonResponse.fromJson(response.data);
        if (commonResponse.status! == 1) {
          LoginResponse responseHome = LoginResponse.fromJson(response.data);
          if (responseHome.data != null) {
            isUserLoggedIn = true;
            userData = responseHome.data;
            AppGlobal.setString(
                Constants.user_data, jsonEncode(userData!.toJson()));
            notifyListeners();
          }
          if (responseHome.cartCount != null && responseHome.cartCount != "") {
            cartCount = int.parse(responseHome.cartCount!);

            AppGlobal.setInt(Constants.cartCount, cartCount);
            notifyListeners();
          }
          wishListItems.clear();
          wishListItems.addAll(responseHome.wishlistData ?? []);

          AppGlobal.setStringList(Constants.wishList, wishListItems);
          notifyListeners();
        } else {
          AppGlobal.showToast(
              commonResponse.message ?? Constants.something_wrong);
        }
      } else {
        AppGlobal.showToast(Constants.something_wrong);
      }
    } else if (response is DioError) {
      AppGlobal.showToast(Constants.something_wrong);
    } else {
      AppGlobal.showToast(Constants.something_wrong);
    }
    isLoginLoading = false;
    notifyListeners();
  }

  void updateWishListItem(String wishlistItemId) {
    if (wishListItems.contains(wishlistItemId)) {
      wishListItems.remove(wishlistItemId);
    } else {
      wishListItems.add(wishlistItemId);
    }
    AppGlobal.setStringList(Constants.wishList, wishListItems);
    notifyListeners();
  }

  Future<bool> updateDeleteWishListItem(String wishlistId) async {
    var response = await ApiRequest().postCommonApiCall(
        FormData.fromMap({"product_id": wishlistId}),
        ApiServices.addUpdateWishlist);

    if (response is Response) {
      if (response.data is Map<String, dynamic>) {
        CommonResponse commonResponse = CommonResponse.fromJson(response.data);
        if (commonResponse.status! == 1) {
          return true;
        } else {
          AppGlobal.showSnackbar(
              commonResponse.message ?? Constants.something_wrong,
              type: 2);
        }
      } else {
        AppGlobal.showSnackbar(Constants.something_wrong, type: 2);
      }
    } else if (response is DioError) {
      AppGlobal.showSnackbar(Constants.something_wrong, type: 2);
    } else {
      AppGlobal.showSnackbar(Constants.something_wrong, type: 2);
    }
    return false;
  }

  uploadImage(File imageFile) async {
    imageUploading = true;
    notifyListeners();
    var response = await ApiRequest()
        .uploadProfileImage(imageFile, ApiServices.changeProfilePicture);
    if (response != null) {
      try {
        UpdateProfileResponse updateProfileResponse =
            UpdateProfileResponse.fromJson(response.data);
        if (updateProfileResponse.data != null) {
          userData = updateProfileResponse.data;
          AppGlobal.setString(Constants.user_data,
              jsonEncode(updateProfileResponse.data!.toJson()));
        }
      } catch (ex) {}
    }
    imageUploading = false;
    notifyListeners();
  }

  updateUserProfile(Map<String, String> value) async {
    profileUpdating = true;
    notifyListeners();
    var response = await ApiRequest()
        .postCommonApiCall(FormData.fromMap(value), ApiServices.updateProfile);
    if (response != null) {
      try {
        UpdateProfileResponse updateProfileResponse =
            UpdateProfileResponse.fromJson(response.data);
        if (updateProfileResponse.data != null) {
          userData = updateProfileResponse.data;
          AppGlobal.setString(Constants.user_data,
              jsonEncode(updateProfileResponse.data!.toJson()));
          AppGlobal.showSnackbar(updateProfileResponse.message ?? "", type: 1);
        }
      } catch (ex) {}
    }
    profileUpdating = false;
    notifyListeners();
  }

  Future<bool> logout() async {
    notifyListeners();
    var response = await ApiRequest().getCommonApiCall(ApiServices.logout);
    if (response != null) {
      try {
        CommonResponse commonResponse = CommonResponse.fromJson(response.data);
        if (commonResponse.status == 1) {
          userData = null;
          cartCount = 0;
          wishListItems.clear();
          isUserLoggedIn = false;
          await AppGlobal.setString(Constants.user_data, "");
          await AppGlobal.setInt(Constants.cartCount, 0);
          await AppGlobal.setStringList(Constants.wishList, []);
          await AppGlobal.logOut();
          notifyListeners();
          return true;
        }
        // ignore: empty_catches
      } catch (ex) {}
    }
    notifyListeners();
    return false;
  }

  updateCartCount(int val) {
    cartCount = val;
    notifyListeners();
    AppGlobal.setInt(Constants.cartCount, val);
  }

  getCartDetailApi() async {
    cartItemsLoading = true;
    cartItemList.clear();
    discount = null;
    grandTotalNew = null;
    notifyListeners();

    var response = await ApiRequest().getCommonApiCall(ApiServices.getCart);
    if (response != null) {
      try {
        CartResponse addToCartResponse = CartResponse.fromJson(response.data);
        cartResponse = addToCartResponse;
        discount = addToCartResponse.discount;
        cartItemList.addAll(addToCartResponse.cartData ?? []);
        grandTotalNew = addToCartResponse.grandTotal;
        if (addToCartResponse.cartCount != null) {
          cartCount = int.parse(addToCartResponse.cartCount!);
        }
      } catch (ex) {
        AppGlobal.showSnackbar(ex.toString(), type: 2);
      }
    } else {
      cartCount = 0;
      AppGlobal.setInt(Constants.cartCount, 0);
    }

    cartItemsLoading = false;
    notifyListeners();
  }

  applyDiscount(String couponCode) async {
    discount = null;
    grandTotalNew = null;
    notifyListeners();

    var response = await ApiRequest().postCommonApiCall(
        FormData.fromMap({"couponCode": couponCode}), ApiServices.applyCoupon);
    if (response != null) {
      try {
        ApplyDiscountResponse addToCartResponse =
            ApplyDiscountResponse.fromJson(response.data);
        discount = addToCartResponse.discount;
        grandTotalNew = addToCartResponse.grandTotal;
      } catch (ex) {}
    }

    cartItemsLoading = false;
    notifyListeners();
  }

  updateCartQty(String cartId, int qty) async {
    /* discount = null;
    grandTotalNew = null;
    notifyListeners();*/

    var response = await ApiRequest().postCommonApiCall(
        FormData.fromMap({"cart_id": cartId, "quantity": qty}),
        ApiServices.updateCart);
    if (response != null) {
      try {
        CartResponse addToCartResponse = CartResponse.fromJson(response.data);
        cartResponse = addToCartResponse;
        discount = addToCartResponse.discount;
        cartItemList.clear();
        cartItemList.addAll(addToCartResponse.cartData ?? []);
        grandTotalNew = addToCartResponse.grandTotal;
        if (addToCartResponse.cartCount != null) {
          cartCount = int.parse(addToCartResponse.cartCount!);
        }
      } catch (ex) {
        print("ex====${ex.toString()}");
      }
    }

    cartItemsLoading = false;
    notifyListeners();
  }

  deleteCartITem(String cartId) async {
    var response = await ApiRequest().postCommonApiCall(
        FormData.fromMap({"cart_id": cartId}), ApiServices.deleteCart);
    if (response != null) {
      try {
        CartResponse addToCartResponse = CartResponse.fromJson(response.data);
        cartResponse = addToCartResponse;
        discount = addToCartResponse.discount;
        cartItemList.clear();
        cartItemList.addAll(addToCartResponse.cartData ?? []);
        grandTotalNew = addToCartResponse.grandTotal;
      } catch (ex) {}
    }

    cartItemsLoading = false;
    notifyListeners();
  }

  setDiscount(Discount? dis) {
    discount = dis;
    grandTotalNew = null;
    notifyListeners();
  }

  updateWishList(List<Products> wishListProducts) {
    wishListItems.clear();
    for (Products products in wishListProducts) {
      wishListItems.add(products.productDescription!.productId!);
    }
    notifyListeners();
    AppGlobal.setStringList(Constants.wishList, wishListItems);
  }

  googleLogin() async {
    isLoginLoading = true;
    notifyListeners();
    GoogleSignIn _googleSignIn = GoogleSignIn(
      scopes: <String>[
        'email',
        'https://www.googleapis.com/auth/contacts.readonly',
      ],
    );

    try {
      if (_googleSignIn.currentUser != null) await _googleSignIn.disconnect();
      GoogleSignInAccount? user = await _googleSignIn.signIn();
      print("user===== ${user}");
      print("_googleSignIn.currentUser===== ${_googleSignIn.currentUser}");
      if (user != null) {
        if (user.email != null) {
          await loginUser({
            "email": user.email,
            "password": user.email,
            "creation": "G",
            "firebase_token": await FirebaseMessaging.instance.getToken() ?? ""
          });
        }
      }
    } catch (error) {
      if (kDebugMode) {
        print(error);
      }
      AppGlobal.showSnackbar("${error.toString()}");
    }
    isLoginLoading = false;
    notifyListeners();
  }

  registerUser(Map<String, dynamic> requestData) async {
    isRegisterLoading = true;
    notifyListeners();
    final data = FormData.fromMap(requestData);

    var response =
        await ApiRequest().postCommonApiCall(data, ApiServices.register);

    if (response != null) {
      try {
        LoginResponse responseHome = LoginResponse.fromJson(response.data);
        if (responseHome.data != null) {
          isUserLoggedIn = true;
          userData = responseHome.data;
          AppGlobal.setString(
              Constants.user_data, jsonEncode(userData!.toJson()));
          notifyListeners();
        }
        cartCount = 0;
        wishListItems.clear();
        AppGlobal.setStringList(Constants.wishList, wishListItems);
        notifyListeners();
      } catch (ex) {
        print("ex=== ${ex.toString()}");
      }
    }

    isRegisterLoading = false;
    notifyListeners();
  }

  checkSession() async {
    var response = await ApiRequest().getCommonApiCall(ApiServices.checkLogin);
    if (response != null) {
      try {
        if (response.data is Map<String, dynamic>) {
          if (response.data['loginStatus'] == 1) {
            return true;
          }
        }
      } catch (ex) {
        return false;
      }
    }
    return false;
  }
}
