import 'package:dio/dio.dart';
import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/models/common_response.dart';
import 'package:ecommerce/network/api_request.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:flutter/foundation.dart';

class ChangePasswordProvider extends ChangeNotifier {
  bool oldPasswordShow = false;
  bool newPasswordShow = false;
  bool confirmPasswordShow = false;
  bool passwordChanging = false;

  updateOldPassShow() {
    oldPasswordShow = !oldPasswordShow;
    notifyListeners();
  }

  updateNewPassShow() {
    newPasswordShow = !newPasswordShow;
    notifyListeners();
  }

  updateConfirmPassShow() {
    confirmPasswordShow = !confirmPasswordShow;
    notifyListeners();
  }

  changePassword(Map<String, String> value) async {
    passwordChanging = true;
    notifyListeners();
    var response = await ApiRequest()
        .postCommonApiCall(FormData.fromMap(value), ApiServices.changePassword);
    if (response != null) {
      try {
        CommonResponse updateProfileResponse =
            CommonResponse.fromJson(response.data);
        AppGlobal.showSnackbar(updateProfileResponse.message ?? "", type: 1);
        passwordChanging = false;
        notifyListeners();
        return true;
      } catch (ex) {}
    }
    passwordChanging = false;
    notifyListeners();
    return false;
  }
}
