import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/models/home_model/ResponseHome.dart';
import 'package:ecommerce/models/product_list_models/product_list.dart';
import 'package:ecommerce/network/api_request.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:flutter/material.dart';

class SearchProvider extends ChangeNotifier {
  BuildContext context;
  bool searching = false;
  List<Products> searchProductList = [];
  String searchQuery = "";

  SearchProvider(this.context);

  searchProduct(String value) async {
    searchProductList.clear();
    searchQuery = value;
    notifyListeners();
    if (value.length < 3) {
      return;
    } else {
      searching = true;
      notifyListeners();
      var response = await ApiRequest()
          .getCommonApiCall("${ApiServices.searchProducts}$value");
      if (response != null) {
        try {
          ProductList responseHome = ProductList.fromJson(response.data);
          if (responseHome.data != null) {
            searchProductList.addAll(responseHome.data ?? []);
          }
        } catch (ex) {
          AppGlobal.showSnackbar(ex.toString(), type: 2);
        }
      }
      searching = false;
      notifyListeners();
    }
  }
}
