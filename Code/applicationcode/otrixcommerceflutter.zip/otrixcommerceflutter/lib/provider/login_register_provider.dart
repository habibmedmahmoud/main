import 'package:flutter/foundation.dart';

class LoginRegisterProvider extends ChangeNotifier {

}