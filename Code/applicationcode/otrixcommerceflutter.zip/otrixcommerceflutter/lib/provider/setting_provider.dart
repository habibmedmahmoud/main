// ignore_for_file: non_constant_identifier_names, empty_catches

import 'package:ecommerce/models/Category.dart';
import 'package:ecommerce/models/setting/PagesData.dart';
import 'package:ecommerce/models/setting/PagesResponse.dart';
import 'package:ecommerce/network/api_request.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SettingProvider extends ChangeNotifier {
  bool loading = false;
  BuildContext context;
  PagesData? pagesData;
  List<Categories> categoriesLis = [];
  List<String> forYouList = ["For You"];
  List<int> selectedNotifications = [];
  List<int> selectedForYou = [];

  SettingProvider(this.context, {required String pageType, int? pageNumber}) {
    if (pageType == 'page' && pageNumber != null) {
      callGetpagesApi(pageNumber);
    } else if (pageType == 'notification') {
      categoriesLis.addAll(context.read<HomeProvider>().categories);
      notifyListeners();
    }
  }

  callGetpagesApi(int pageNumber) async {
    loading = true;
    notifyListeners();
    var response = await ApiRequest()
        .getCommonApiCall("${ApiServices.getPages}$pageNumber");
    if (response != null) {
      try {
        PagesResponse pagesResponse = PagesResponse.fromJson(response.data);
        pagesData = pagesResponse.data;
      } catch (ex) {}
    }
    loading = false;
    notifyListeners();
  }

  UpdateForYouSelection(int index) {
    selectedForYou.contains(index)
        ? selectedForYou.remove(index)
        : selectedForYou.add(index);
    notifyListeners();
  }

  UpdateNotificaitonSelection(int index) {
    selectedNotifications.contains(index)
        ? selectedNotifications.remove(index)
        : selectedNotifications.add(index);
    notifyListeners();
  }
}
