// ignore_for_file: use_build_context_synchronously

import 'package:dio/dio.dart';
import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/address/address_model.dart';
import 'package:ecommerce/models/address/countriesModel.dart';
import 'package:ecommerce/models/checkout/CheckoutData.dart';
import 'package:ecommerce/models/checkout/CheckoutResponse.dart';
import 'package:ecommerce/models/checkout/OrderSummary.dart';
import 'package:ecommerce/models/checkout/SelectShippingResponse.dart';
import 'package:ecommerce/models/checkout/Shipping.dart';
import 'package:ecommerce/models/checkout/ShippingMethods.dart';
import 'package:ecommerce/models/order/PlaceOrderResponse.dart';
import 'package:ecommerce/network/api_request.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/ui/screens/order_success_screen.dart';
import 'package:flutter/material.dart';

class CheckoutProvider extends ChangeNotifier {
  BuildContext context;
  bool checkoutLoading = true;
  int checkoutSelection = 0; // 0 for address 1 for payment
  AddressModel? selectedAddress;
  List<AddressModel> addressList = [];
  String? selectedAddressId;
  ShippingMethods? selectedShippingMethod;
  List<ShippingMethods> shippingMethodsList = [];
  List<CountryModel> countryList = [];
  CheckoutData? checkoutData;
  Shipping? selectedShipping;
  List<OrderSummary> orderSummaryList = [];
  String? grandTotal;
  int selectedPaymentMethods = -1;

  CheckoutProvider(this.context) {
    callGetCheckoutData();
  }

  callGetCheckoutData() async {
    checkoutLoading = true;
    addressList.clear();
    shippingMethodsList.clear();
    countryList.clear();
    notifyListeners();
    var response =
        await ApiRequest().getCommonApiCall(ApiServices.getCheckoutData);
    if (response != null) {
      try {
        CheckoutResponse checkoutResponse =
            CheckoutResponse.fromJson(response.data);
        if (checkoutResponse.data != null) {
          checkoutData = checkoutResponse.data;
          addressList.addAll(checkoutData!.addresses ?? []);
          shippingMethodsList.addAll(checkoutData!.shippingMethods ?? []);
          countryList.addAll(checkoutData!.countries ?? []);
          if (addressList.isNotEmpty && selectedAddressId == null) {
            selectedAddressId = addressList.first.id;
          }
        }
      } catch (ex) {
        print("Exception=== ${ex.toString()}");
        AppGlobal.showSnackbar(ex.toString(), type: 2);
      }
    }

    checkoutLoading = false;
    notifyListeners();
  }

  selectNewAddress(String? addressList) {
    selectedAddressId = addressList;
    notifyListeners();
  }

  selectNewShippingMethod(ShippingMethods shippingMethodsList) {
    selectedShippingMethod = shippingMethodsList;
    notifyListeners();
  }

  changeView(int i) {
    checkoutSelection = i;
    notifyListeners();
    if (i == 1) {
      callToGetOrderSummary();
    }
  }

  callToGetOrderSummary() async {
    checkoutLoading = true;
    notifyListeners();
    var response = await ApiRequest().postCommonApiCall(FormData.fromMap({}),
        "${ApiServices.selectShipping}${selectedShippingMethod!.id}");
    if (response != null) {
      try {
        SelectShippingResponse checkoutResponse =
            SelectShippingResponse.fromJson(response.data);
        orderSummaryList.addAll(checkoutResponse.orderSummary ?? []);
        grandTotal = checkoutResponse.grandTotal;
        selectedShipping = checkoutResponse.shipping;
      } catch (ex) {
        AppGlobal.showSnackbar(ex.toString(), type: 2);
      }
    }

    checkoutLoading = false;
    notifyListeners();
  }

  changePaymentMethod(int index) {
    selectedPaymentMethods = index;
    notifyListeners();
  }

  placeOrder(String comment) async {
    checkoutLoading = true;
    notifyListeners();

    var data = {
      "payment_method": Common.paymentMethods[selectedPaymentMethods]['value'],
      "transaction_id": "",
      "address_id": selectedAddressId,
      "comment": comment
    };
    var response = await ApiRequest()
        .postCommonApiCall(FormData.fromMap(data), ApiServices.placeOrder);
    if (response != null) {
      try {
        PlaceOrderResponse placeOrderResponse =
            PlaceOrderResponse.fromJson(response.data);
        if (placeOrderResponse.orderID != null) {
          Navigator.of(context).pushAndRemoveUntil(
              MaterialPageRoute(
                  builder: (context) =>
                      OrderSuccessScreen(orderId: placeOrderResponse.orderID!.toString())),
              (Route<dynamic> route) => false);
        }
      } catch (ex) {
        AppGlobal.showSnackbar(ex.toString(), type: 2);
      }
    }

    checkoutLoading = false;
    notifyListeners();
  }
}
