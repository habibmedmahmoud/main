import 'dart:convert';

import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/Constants.dart';
import 'package:ecommerce/models/UserData.dart';
import 'package:flutter/foundation.dart';

class AppProvider extends ChangeNotifier {
  String language = "en";
  bool isUserLoggedIn = false;
  UserData? userData;

  initAppProvider() async {
    language = await AppGlobal.getString(Constants.appLanguage);
    if (language.isEmpty) {
      language = "en";
      await AppGlobal.setString(Constants.appLanguage, "en");
    }
    notifyListeners();
  }

  AppProvider() {
    AppGlobal.getString(Constants.appLanguage).asStream().listen((event) {
      language = event;
      if (language.isEmpty) {
        language = "en";
        AppGlobal.setString(Constants.appLanguage, "en");
      }
      if (kDebugMode) {
        print("language == $language");
      }
      notifyListeners();
    });

    notifyListeners();
  }

  Future<UserData?> getUserData() async {
    String userD = await AppGlobal.getString(Constants.user_data);
    if (userD.isNotEmpty) {
      try {
        userData = UserData.fromJson(jsonDecode(userD));
        isUserLoggedIn = true;
        notifyListeners();
        return userData;
      } catch (ex) {
        return null;
      }
    }
    return null;
  }
}
