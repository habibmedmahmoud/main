import 'package:dio/dio.dart';
import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/Constants.dart';
import 'package:ecommerce/models/common_response.dart';
import 'package:ecommerce/models/home_model/ResponseHome.dart';
import 'package:ecommerce/models/product_list_models/product_list.dart';
import 'package:ecommerce/network/api_request.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class WishListProvider extends ChangeNotifier {
  bool isLoading = true;
  BuildContext context;

  List<Products> wishListProducts = [];

  WishListProvider(this.context) {
    getMyWishListItems();
  }

  getMyWishListItems() async {
    var response = await ApiRequest().getCommonApiCall(ApiServices.getWishlist);

    if (response != null) {
      ProductList responseHome = ProductList.fromJson(response.data);
      if (responseHome.data != null) {
        wishListProducts.clear();
        wishListProducts.addAll(responseHome.data ?? []);

        Provider.of<HomeProvider>(context, listen: false)
            .updateWishList(wishListProducts);
        notifyListeners();
      }
    }
    isLoading = false;
    notifyListeners();
  }

  Future<bool> updateDeleteWishListItem(String wishlistId) async {
    var response = await ApiRequest().postCommonApiCall(
        FormData.fromMap({"product_id": wishlistId}),
        ApiServices.addUpdateWishlist);

    if (response is Response) {
      if (response.data is Map<String, dynamic>) {
        CommonResponse commonResponse = CommonResponse.fromJson(response.data);
        if (commonResponse.status! == 1) {
          return true;
        } else {
          AppGlobal.showSnackbar(
              commonResponse.message ?? Constants.something_wrong,
              type: 2);
        }
      } else {
        AppGlobal.showSnackbar(Constants.something_wrong, type: 2);
      }
    } else if (response is DioError) {
      AppGlobal.showSnackbar(Constants.something_wrong, type: 2);
    } else {
      AppGlobal.showSnackbar(Constants.something_wrong, type: 2);
    }
    return false;
  }

  deleteItem(Products products) {
    wishListProducts.remove(products);
    notifyListeners();
  }
}
