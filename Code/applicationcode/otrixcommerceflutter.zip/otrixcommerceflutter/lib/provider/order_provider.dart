import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/models/order/OrderListResponse.dart';
import 'package:ecommerce/models/order/order_item_data.dart';
import 'package:ecommerce/network/api_request.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:flutter/material.dart';

class OrderProvider extends ChangeNotifier {
  BuildContext context;
  bool orderLoading = false;
  int page = 1;
  int lastPage = 1;
  List<OrderItem> orderList = [];

  OrderProvider(this.context) {
    page = 1;
    callGetOrderList();
  }

  callGetOrderList() async {
    if (page == 1) {
      orderLoading = true;
      orderList.clear();
      notifyListeners();
    }
    var response = await ApiRequest()
        .getCommonApiCall("${ApiServices.getOrdersList}$page");
    if (response != null) {
      try {
        OrderListResponse orderListResponse =
            OrderListResponse.fromJson(response.data);
        if (orderListResponse.data != null) {
          if (orderListResponse.data!.lastPage != null) {
            lastPage = orderListResponse.data!.lastPage!;
            orderList.addAll(orderListResponse.data!.data ?? []);
          }
        }
        // ignore: empty_catches
      } catch (ex) {
        print("exception ===${ex.toString()}");
      }
    }
    orderLoading = false;
    notifyListeners();
  }
}
