// ignore_for_file: use_build_context_synchronously

import 'package:dio/dio.dart';
import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/Constants.dart';
import 'package:ecommerce/models/cart/AddToCartResponse.dart';
import 'package:ecommerce/models/common_response.dart';
import 'package:ecommerce/models/product/ProductDetailResponse.dart';
import 'package:ecommerce/models/product/ProductOption.dart';
import 'package:ecommerce/network/api_request.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class ProductProvider extends ChangeNotifier {
  bool isProductLoaded = false;
  BuildContext context;
  ProductDetailResponseData? productData;
  int selectedQty = 1;
  bool inStock = false;
  String? productId;
  ProductOption? selectedProductOption;

  ProductProvider(this.context, this.productId) {
    fetChProductDetail();
  }

  fetChProductDetail() async {
    productData = null;
    selectedProductOption = null;
    isProductLoaded = false;
    selectedQty = 1;
    notifyListeners();
    var response = await ApiRequest()
        .getCommonApiCall(ApiServices.productDetail + productId!);

    try {
      if (response is Response) {
        if (response.data is Map<String, dynamic>) {
          CommonResponse commonResponse =
              CommonResponse.fromJson(response.data);
          if (commonResponse.status! == 1) {
            ProductDetailResponse responseHome =
                ProductDetailResponse.fromJson(response.data);
            if (responseHome.data != null) {
              productData = responseHome.data;
              checkStock();
              notifyListeners();
            }
          } else {
            AppGlobal.showToast(
                commonResponse.message ?? Constants.something_wrong);
          }
        } else if (response is DioError) {
          AppGlobal.showToast(Constants.something_wrong);
        }
      } else if (response is DioError) {
        AppGlobal.showToast(Constants.something_wrong);
      } else {
        AppGlobal.showToast(Constants.something_wrong);
      }
    } catch (exc) {
      if (kDebugMode) {
        print("exception === ${exc}");
      }
    }
    isProductLoaded = true;
    notifyListeners();
  }

  changeQty(bool type) {
    // type ==true increment, false Decrement
    if (productData != null) {
      if (productData!.data != null) {
        if (productData!.data!.quantity != null) {
          if (type) {
            if (productData!.data!.quantity! > selectedQty) {
              selectedQty++;
              notifyListeners();
            }
          } else if (selectedQty > 1) {
            selectedQty--;
            notifyListeners();
          }
        }
      }
    }
  }

  checkStock() {
    if (productData != null) {
      if (productData!.data != null) {
        if (productData!.data!.quantity != null) {
          if (productData!.data!.quantity! > 0) {
            inStock = true;
            notifyListeners();
          }
        }
      }
    }
  }

  selectNewProductOption(ProductOption productSpecial) {
    selectedProductOption = productSpecial;
    notifyListeners();
  }

  addToCart() async {
    Map<String, dynamic> data = {
      "product_id": productId,
      "quantity": selectedQty,
      if (selectedProductOption != null)
        "options": selectedProductOption!.type == "color"
            ? {"optionColorSelected": selectedProductOption!.optionId}
            : selectedProductOption!.type == "select"
                ? {"optionSelectSelected": selectedProductOption!.optionId}
                : {"optionSizeSelected": selectedProductOption!.optionId}
    };
    if (kDebugMode) {
      print("data === ${data.toString()}");
    }
    var response = await ApiRequest()
        .postCommonApiCall(FormData.fromMap(data), ApiServices.addToCart);
    if (response != null) {
      try {
        AddToCartResponse addToCartResponse =
            AddToCartResponse.fromJson(response.data);
        AppGlobal.showSnackbar(
            addToCartResponse.message ?? "Product Added To Cart!",
            type: 1);
        Provider.of<HomeProvider>(context, listen: false)
            .updateCartCount(int.parse(addToCartResponse.cartCount!));
        // ignore: empty_catches
      } catch (ex) {}
    }
    notifyListeners();
  }
}
