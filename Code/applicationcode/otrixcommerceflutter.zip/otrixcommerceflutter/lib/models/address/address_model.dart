class AddressModel {
  String? id;
  String? customerId;
  String? name;
  String? address1;
  String? address2;
  String? city;
  String? postcode;
  int? countryId;
  String? createdAt;
  String? country;

  AddressModel(
      {this.id,
        this.customerId,
        this.name,
        this.address1,
        this.address2,
        this.city,
        this.postcode,
        this.countryId,
        this.createdAt,
        this.country});

  AddressModel.fromJson(Map<String, dynamic> json) {
    id = json['id']?.toString();
    customerId = json['customer_id']?.toString();
    name = json['name'];
    address1 = json['address_1'];
    address2 = json['address_2'];
    city = json['city'];
    postcode = json['postcode'];
    countryId = json['country_id'];
    createdAt = json['created_at'];
    country = json['country'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['customer_id'] = customerId;
    data['name'] = name;
    data['address_1'] = address1;
    data['address_2'] = address2;
    data['city'] = city;
    data['postcode'] = postcode;
    data['country_id'] = countryId;
    data['created_at'] = createdAt;
    data['country'] = country;
    return data;
  }
}