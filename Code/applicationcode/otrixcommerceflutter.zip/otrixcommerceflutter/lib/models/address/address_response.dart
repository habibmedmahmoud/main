import 'package:ecommerce/models/address/address_model.dart';
import 'package:ecommerce/models/address/countriesModel.dart';

class AddressResponse {
  int? status;
  List<AddressModel>? data;
  List<CountryModel>? countries;

  AddressResponse({this.status, this.data, this.countries});

  AddressResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['data'] != null) {
      data = <AddressModel>[];
      json['data'].forEach((v) {
        data!.add(AddressModel.fromJson(v));
      });
    }
    if (json['countries'] != null) {
      countries = <CountryModel>[];
      json['countries'].forEach((v) {
        countries!.add(CountryModel.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    if (countries != null) {
      data['countries'] = countries!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}