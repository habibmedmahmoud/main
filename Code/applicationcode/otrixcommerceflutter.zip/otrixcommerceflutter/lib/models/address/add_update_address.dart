import 'package:ecommerce/models/address/address_model.dart';

class AddUpdateAddress {
  int? status;
  String? message;
  List<AddressModel>? addresses;

  AddUpdateAddress({this.status, this.message, this.addresses});

  AddUpdateAddress.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    if (json['addresses'] != null) {
      addresses = <AddressModel>[];
      json['addresses'].forEach((v) {
        addresses!.add(AddressModel.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    data['message'] = message;
    if (addresses != null) {
      data['addresses'] = addresses!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}
