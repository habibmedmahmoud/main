class CountryModel {
  int? id;
  String? name;
  String? isoCode3;
  String? postcodeRequired;
  String? status;

  CountryModel(
      {this.id, this.name, this.isoCode3, this.postcodeRequired, this.status});

  CountryModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    isoCode3 = json['iso_code_3'];
    postcodeRequired = json['postcode_required'];
    status = json['status']?.toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['iso_code_3'] = isoCode3;
    data['postcode_required'] = postcodeRequired;
    data['status'] = status;
    return data;
  }
}
