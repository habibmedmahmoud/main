import 'dart:convert';

import 'package:ecommerce/models/BrandsResponse.dart';
import 'package:ecommerce/models/Category.dart';
import 'package:ecommerce/models/product/ProductSpecial.dart';

/// status : 1
/// data : {"categories":[{"category_id":9,"image":"1654235672kisspng-apple-watch-series-2-apple-watch-series-3-apple-wa-smart-apple-watch-sports-watch-band-5a8687ca23b730.4356046615187660261463-removebg-preview.png","parent_id":"0","sort_order":"9","status":"1","category_description":{"name":"Electronic","category_id":9}},{"category_id":8,"image":"1654168410Category_08.jpg","parent_id":"0","sort_order":"8","status":"1","category_description":{"name":"Heels Sandal","category_id":8}},{"category_id":7,"image":"1654168381Category_07.jpg","parent_id":"0","sort_order":"7","status":"1","category_description":{"name":"Ladies Dress","category_id":7}},{"category_id":6,"image":"1654168347Category_01.jpg","parent_id":"0","sort_order":"6","status":"1","category_description":{"name":"Beauty","category_id":6}},{"category_id":5,"image":"1654168241Category_02.jpg","parent_id":"0","sort_order":"5","status":"1","category_description":{"name":"Travel","category_id":5}},{"category_id":4,"image":"1654168211Category_06.jpg","parent_id":"0","sort_order":"4","status":"1","category_description":{"name":"Kids Wear","category_id":4}},{"category_id":3,"image":"1654168182Category_03.jpg","parent_id":"0","sort_order":"3","status":"1","category_description":{"name":"Grocery","category_id":3}},{"category_id":2,"image":"1654168151Category_04.jpg","parent_id":"0","sort_order":"2","status":"1","category_description":{"name":"Shoes","category_id":2}}],"banners":{"id":1,"name":"Application Home Page Slider","status":"1","images":[{"image":"16472862101.jpg","sort_order":"1","banner_id":"1"},{"image":"16472862102.jpg","sort_order":"2","banner_id":"1"},{"image":"16472862103.jpg","sort_order":"3","banner_id":"1"},{"image":"16472862104.jpg","sort_order":"4","banner_id":"1"}]},"manufacturers":[{"id":1,"name":"Zara","status":"1","sort_order":"1","image":"16541736458756.jpg"},{"id":2,"name":"Nike","status":"1","sort_order":"2","image":"16541736618756.jpg"},{"id":3,"name":"Puma","status":"1","sort_order":"3","image":"16541736728756.jpg"},{"id":4,"name":"Samsung","status":"1","sort_order":"4","image":"16541736848756.jpg"},{"id":5,"name":"Big Basket","status":"1","sort_order":"5","image":"16541737038756.jpg"},{"id":6,"name":"Apple","status":"1","sort_order":"6","image":"16541737388756.jpg"},{"id":7,"name":"London Britches","status":"1","sort_order":"7","image":"16541737508756.jpg"}],"newProducts":[{"id":1,"image":"1654175272Product_02.png","category_id":"2","model":"Puma","price":"650.00","quantity":"496","sort_order":"1","status":"1","date_available":"01/06/2022","review_avg":"4.50000","product_description":{"name":"Pumma Runing Shoes","id":36,"product_id":"1"},"special":null},{"id":3,"image":"1654233432Product_04.png","category_id":"1","model":"Shirt","price":"450.00","quantity":"493","sort_order":"1","status":"1","date_available":"01/06/2022","review_avg":null,"product_description":{"name":"Men Shirt","id":43,"product_id":"3"},"special":null},{"id":13,"image":"1654236389joshua-aragon-FGXqbqbGt5o-unsplash-removebg-preview-removebg-preview.png","category_id":"9","model":"LAPTOP100","price":"999.00","quantity":"4998","sort_order":"1","status":"1","date_available":"03/06/2022","review_avg":null,"product_description":{"name":"Laptop","id":33,"product_id":"13"},"special":null},{"id":12,"image":"1654235975hardik-sharma-CrPAvN29Nhs-unsplash-removebg-preview.png","category_id":"9","model":"Mobile22","price":"650.00","quantity":"500","sort_order":"1","status":"1","date_available":"03/06/2022","review_avg":null,"product_description":{"name":"Smart Phone","id":31,"product_id":"12"},"special":null}],"trendingProducts":[{"id":3,"image":"1654233432Product_04.png","category_id":"1","model":"Shirt","price":"450.00","quantity":"493","sort_order":"1","status":"1","date_available":"01/06/2022","review_avg":null,"product_description":{"name":"Men Shirt","id":43,"product_id":"3"},"special":null},{"id":1,"image":"1654175272Product_02.png","category_id":"2","model":"Puma","price":"650.00","quantity":"496","sort_order":"1","status":"1","date_available":"01/06/2022","review_avg":"4.50000","product_description":{"name":"Pumma Runing Shoes","id":36,"product_id":"1"},"special":null},{"id":8,"image":"1654234757valerie-elash-gsKdPcIyeGg-unsplash-removebg-preview.png","category_id":"7","model":"DRESS","price":"580.00","quantity":"397","sort_order":"1","status":"1","date_available":"03/06/2022","review_avg":null,"product_description":{"name":"Ladies Dress","id":21,"product_id":"8"},"special":null},{"id":13,"image":"1654236389joshua-aragon-FGXqbqbGt5o-unsplash-removebg-preview-removebg-preview.png","category_id":"9","model":"LAPTOP100","price":"999.00","quantity":"4998","sort_order":"1","status":"1","date_available":"03/06/2022","review_avg":null,"product_description":{"name":"Laptop","id":33,"product_id":"13"},"special":null}],"dodProducts":[{"id":1,"product_id":"4","review_avg":null,"product_description":{"name":"AXE body Spray","id":13,"product_id":"4"},"special":{"product_id":"4","price":"40.0000","start_date":"01/06/2022","end_date":"30/09/2022"},"product_details":{"id":4,"image":"1654233987Product_08.png","price":"50.00","quantity":"500","sort_order":"1","status":"1","date_available":"01/06/2022"}},{"id":2,"product_id":"6","review_avg":null,"product_description":{"name":"Essential Cap","id":17,"product_id":"6"},"special":{"product_id":"6","price":"60.0000","start_date":"01/06/2022","end_date":"31/10/2022"},"product_details":{"id":6,"image":"1654234349Product_11.jpg","price":"90.00","quantity":"500","sort_order":"1","status":"1","date_available":"03/06/2022"}},{"id":3,"product_id":"7","review_avg":null,"product_description":{"name":"Bag","id":19,"product_id":"7"},"special":{"product_id":"7","price":"500.0000","start_date":"01/06/2022","end_date":"30/11/2022"},"product_details":{"id":7,"image":"1654234529Product_24.jpg","price":"650.00","quantity":"248","sort_order":"1","status":"1","date_available":"03/06/2022"}},{"id":4,"product_id":"9","review_avg":null,"product_description":{"name":"Men Blue Shoes","id":23,"product_id":"9"},"special":{"product_id":"9","price":"300.0000","start_date":"01/06/2022","end_date":"31/10/2022"},"product_details":{"id":9,"image":"1654234911Product_06.png","price":"350.00","quantity":"499","sort_order":"1","status":"1","date_available":"03/06/2022"}}]}

ResponseHome responseHomeFromJson(String str) =>
    ResponseHome.fromJson(json.decode(str));

String responseHomeToJson(ResponseHome data) => json.encode(data.toJson());

class ResponseHome {
  ResponseHome({
    int? status,
    Data? data,
  }) {
    _status = status;
    _data = data;
  }

  ResponseHome.fromJson(dynamic json) {
    _status = json['status'];
    _data = json['data'] != null ? Data.fromJson(json['data']) : null;
  }

  int? _status;
  Data? _data;

  ResponseHome copyWith({
    int? status,
    Data? data,
  }) =>
      ResponseHome(
        status: status ?? _status,
        data: data ?? _data,
      );

  int? get status => _status;

  Data? get data => _data;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['status'] = _status;
    if (_data != null) {
      map['data'] = _data?.toJson();
    }
    return map;
  }
}

Data dataFromJson(String str) => Data.fromJson(json.decode(str));

String dataToJson(Data data) => json.encode(data.toJson());

class Data {
  Data({
    List<Categories>? categories,
    Banners? banners,
    List<BrandsData>? manufacturers,
    List<Products>? newProducts,
    List<Products>? trendingProducts,
    List<Products>? dodProducts,
  }) {
    _categories = categories;
    _banners = banners;
    _manufacturers = manufacturers;
    _newProducts = newProducts;
    _trendingProducts = trendingProducts;
    _dodProducts = dodProducts;
  }

  Data.fromJson(dynamic json) {
    if (json['categories'] != null) {
      _categories = [];
      json['categories'].forEach((v) {
        _categories?.add(Categories.fromJson(v));
      });
    }
    _banners =
        json['banners'] != null ? Banners.fromJson(json['banners']) : null;
    if (json['manufacturers'] != null) {
      _manufacturers = [];
      json['manufacturers'].forEach((v) {
        _manufacturers?.add(BrandsData.fromJson(v));
      });
    }
    if (json['newProducts'] != null) {
      _newProducts = [];
      json['newProducts'].forEach((v) {
        _newProducts?.add(Products.fromJson(v));
      });
    }
    if (json['trendingProducts'] != null) {
      _trendingProducts = [];
      json['trendingProducts'].forEach((v) {
        _trendingProducts?.add(Products.fromJson(v));
      });
    }
    if (json['flutter_dod'] != null) {
      _dodProducts = [];
      json['flutter_dod'].forEach((v) {
        _dodProducts?.add(Products.fromJson(v));
      });
    }
  }

  List<Categories>? _categories;
  Banners? _banners;
  List<BrandsData>? _manufacturers;
  List<Products>? _newProducts;
  List<Products>? _trendingProducts;
  List<Products>? _dodProducts;

  Data copyWith({
    List<Categories>? categories,
    Banners? banners,
    List<BrandsData>? manufacturers,
    List<Products>? newProducts,
    List<Products>? trendingProducts,
    List<Products>? dodProducts,
  }) =>
      Data(
        categories: categories ?? _categories,
        banners: banners ?? _banners,
        manufacturers: manufacturers ?? _manufacturers,
        newProducts: newProducts ?? _newProducts,
        trendingProducts: trendingProducts ?? _trendingProducts,
        dodProducts: dodProducts ?? _dodProducts,
      );

  List<Categories>? get categories => _categories;

  Banners? get banners => _banners;

  List<BrandsData>? get manufacturers => _manufacturers;

  List<Products>? get newProducts => _newProducts;

  List<Products>? get trendingProducts => _trendingProducts;

  List<Products>? get dodProducts => _dodProducts;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    if (_categories != null) {
      map['categories'] = _categories?.map((v) => v.toJson()).toList();
    }
    if (_banners != null) {
      map['banners'] = _banners?.toJson();
    }
    if (_manufacturers != null) {
      map['manufacturers'] = _manufacturers?.map((v) => v.toJson()).toList();
    }
    if (_newProducts != null) {
      map['newProducts'] = _newProducts?.map((v) => v.toJson()).toList();
    }
    if (_trendingProducts != null) {
      map['trendingProducts'] =
          _trendingProducts?.map((v) => v.toJson()).toList();
    }
    if (_dodProducts != null) {
      map['flutter_dod'] = _dodProducts?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// id : 4
/// image : "1654233987Product_08.png"
/// price : "50.00"
/// quantity : "500"
/// sort_order : "1"
/// status : "1"
/// date_available : "01/06/2022"

ProductDetails productDetailsFromJson(String str) =>
    ProductDetails.fromJson(json.decode(str));

String productDetailsToJson(ProductDetails data) => json.encode(data.toJson());

class ProductDetails {
  ProductDetails({
    int? id,
    String? image,
    String? price,
    String? quantity,
    String? sortOrder,
    String? status,
    String? dateAvailable,
  }) {
    _id = id;
    _image = image;
    _price = price;
    _quantity = quantity;
    _sortOrder = sortOrder;
    _status = status;
    _dateAvailable = dateAvailable;
  }

  ProductDetails.fromJson(dynamic json) {
    _id = json['id'];
    _image = json['image'];
    _price = json['price'];
    _quantity = json['quantity'];
    _sortOrder = json['sort_order'];
    _status = json['status'];
    _dateAvailable = json['date_available'];
  }

  int? _id;
  String? _image;
  String? _price;
  String? _quantity;
  String? _sortOrder;
  String? _status;
  String? _dateAvailable;

  ProductDetails copyWith({
    int? id,
    String? image,
    String? price,
    String? quantity,
    String? sortOrder,
    String? status,
    String? dateAvailable,
  }) =>
      ProductDetails(
        id: id ?? _id,
        image: image ?? _image,
        price: price ?? _price,
        quantity: quantity ?? _quantity,
        sortOrder: sortOrder ?? _sortOrder,
        status: status ?? _status,
        dateAvailable: dateAvailable ?? _dateAvailable,
      );

  int? get id => _id;

  String? get image => _image;

  String? get price => _price;

  String? get quantity => _quantity;

  String? get sortOrder => _sortOrder;

  String? get status => _status;

  String? get dateAvailable => _dateAvailable;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['image'] = _image;
    map['price'] = _price;
    map['quantity'] = _quantity;
    map['sort_order'] = _sortOrder;
    map['status'] = _status;
    map['date_available'] = _dateAvailable;
    return map;
  }
}

/// product_id : "4"
/// price : "40.0000"
/// start_date : "01/06/2022"
/// end_date : "30/09/2022"

/*Special specialFromJson(String str) => Special.fromJson(json.decode(str));

String specialToJson(Special data) => json.encode(data.toJson());

class Special {
  Special({
    String? productId,
    String? price,
    String? startDate,
    String? endDate,
  }) {
    _productId = productId;
    _price = price;
    _startDate = startDate;
    _endDate = endDate;
  }

  Special.fromJson(dynamic json) {
    _productId = json['product_id'];
    _price = json['price'];
    _startDate = json['start_date'];
    _endDate = json['end_date'];
  }

  String? _productId;
  String? _price;
  String? _startDate;
  String? _endDate;

  Special copyWith({
    String? productId,
    String? price,
    String? startDate,
    String? endDate,
  }) =>
      Special(
        productId: productId ?? _productId,
        price: price ?? _price,
        startDate: startDate ?? _startDate,
        endDate: endDate ?? _endDate,
      );

  String? get productId => _productId;

  String? get price => _price;

  String? get startDate => _startDate;

  String? get endDate => _endDate;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['product_id'] = _productId;
    map['price'] = _price;
    map['start_date'] = _startDate;
    map['end_date'] = _endDate;
    return map;
  }
}*/

/// name : "AXE body Spray"
/// id : 13
/// product_id : "4"

ProductDescription productDescriptionFromJson(String str) =>
    ProductDescription.fromJson(json.decode(str));

String productDescriptionToJson(ProductDescription data) =>
    json.encode(data.toJson());

class ProductDescription {
  ProductDescription({
    String? name,
    int? id,
    String? productId,
  }) {
    _name = name;
    _id = id;
    _productId = productId;
  }

  ProductDescription.fromJson(dynamic json) {
    _name = json['name'];
    _id = json['id'];
    _productId = json['product_id'];
  }

  String? _name;
  int? _id;
  String? _productId;

  ProductDescription copyWith({
    String? name,
    int? id,
    String? productId,
  }) =>
      ProductDescription(
        name: name ?? _name,
        id: id ?? _id,
        productId: productId ?? _productId,
      );

  String? get name => _name;

  int? get id => _id;

  String? get productId => _productId;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['id'] = _id;
    map['product_id'] = _productId;
    return map;
  }
}

Products productsFromJson(String str) => Products.fromJson(json.decode(str));

String productsToJson(Products data) => json.encode(data.toJson());

class Products {
  Products({
    int? id,
    String? image,
    String? categoryId,
    String? model,
    String? price,
    int? quantity,
    int? sortOrder,
    int? status,
    String? dateAvailable,
    String? reviewAvg,
    ProductDescription? productDescription,
    ProductSpecial? special,
  }) {
    _id = id;
    _image = image;
    _categoryId = categoryId;
    _model = model;
    _price = price;
    _quantity = quantity;
    _sortOrder = sortOrder;
    _status = status;
    _dateAvailable = dateAvailable;
    _reviewAvg = reviewAvg;
    _productDescription = productDescription;
    _special = special;
  }

  Products.fromJson(dynamic json) {
    _id = json['id'];
    _image = json['image'];
    _categoryId = json['category_id']?.toString();
    _model = json['model'];
    _price = json['price'];
    _quantity = json['quantity'];
    _sortOrder = json['sort_order'];
    _status = json['status'];
    _dateAvailable = json['date_available'];
    _reviewAvg = json['review_avg'];
    _productDescription = json['product_description'] != null
        ? ProductDescription.fromJson(json['product_description'])
        : null;
    _special = json['special'] != null
        ? ProductSpecial.fromJson(json['special'])
        : null;
  }

  int? _id;
  String? _image;
  String? _categoryId;
  String? _model;
  String? _price;
  int? _quantity;
  int? _sortOrder;
  int? _status;
  String? _dateAvailable;
  String? _reviewAvg;
  ProductDescription? _productDescription;
  ProductSpecial? _special;

  Products copyWith({
    int? id,
    String? image,
    String? categoryId,
    String? model,
    String? price,
    int? quantity,
    int? sortOrder,
    int? status,
    String? dateAvailable,
    String? reviewAvg,
    ProductDescription? productDescription,
    ProductSpecial? special,
  }) =>
      Products(
        id: id ?? _id,
        image: image ?? _image,
        categoryId: categoryId ?? _categoryId,
        model: model ?? _model,
        price: price ?? _price,
        quantity: quantity ?? _quantity ,
        sortOrder: sortOrder ?? _sortOrder,
        status: status ?? _status,
        dateAvailable: dateAvailable ?? _dateAvailable,
        reviewAvg: reviewAvg ?? _reviewAvg,
        productDescription: productDescription ?? _productDescription,
        special: special ?? _special,
      );

  int? get id => _id;

  String? get image => _image;

  String? get categoryId => _categoryId;

  String? get model => _model;

  String? get price => _price;

  int? get quantity => _quantity;

  int? get sortOrder => _sortOrder;

  int? get status => _status;

  String? get dateAvailable => _dateAvailable;

  String? get reviewAvg => _reviewAvg;

  ProductDescription? get productDescription => _productDescription;

  ProductSpecial? get special => _special;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['image'] = _image;
    map['category_id'] = _categoryId;
    map['model'] = _model;
    map['price'] = _price;
    map['quantity'] = _quantity;
    map['sort_order'] = _sortOrder;
    map['status'] = _status;
    map['date_available'] = _dateAvailable;
    map['review_avg'] = _reviewAvg;
    if (_productDescription != null) {
      map['product_description'] = _productDescription?.toJson();
    }
    if (_special != null) {
      map['special'] = _special?.toJson();
    }
    return map;
  }
}

/// id : 1
/// name : "Application Home Page Slider"
/// status : "1"
/// images : [{"image":"16472862101.jpg","sort_order":"1","banner_id":"1"},{"image":"16472862102.jpg","sort_order":"2","banner_id":"1"},{"image":"16472862103.jpg","sort_order":"3","banner_id":"1"},{"image":"16472862104.jpg","sort_order":"4","banner_id":"1"}]

Banners bannersFromJson(String str) => Banners.fromJson(json.decode(str));

String bannersToJson(Banners data) => json.encode(data.toJson());

class Banners {
  Banners({
    int? id,
    String? name,
    int? status,
    List<Images>? images,
  }) {
    _id = id;
    _name = name;
    _status = status;
    _images = images;
  }

  Banners.fromJson(dynamic json) {
    _id = json['id'];
    _name = json['name'];
    _status = json['status'];
    if (json['images'] != null) {
      _images = [];
      json['images'].forEach((v) {
        _images?.add(Images.fromJson(v));
      });
    }
  }

  int? _id;
  String? _name;
  int? _status;
  List<Images>? _images;

  Banners copyWith({
    int? id,
    String? name,
    int? status,
    List<Images>? images,
  }) =>
      Banners(
        id: id ?? _id,
        name: name ?? _name,
        status: status ?? _status,
        images: images ?? _images,
      );

  int? get id => _id;

  String? get name => _name;

  int? get status => _status;

  List<Images>? get images => _images;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['id'] = _id;
    map['name'] = _name;
    map['status'] = _status;
    if (_images != null) {
      map['images'] = _images?.map((v) => v.toJson()).toList();
    }
    return map;
  }
}

/// image : "16472862101.jpg"
/// sort_order : "1"
/// banner_id : "1"

Images imagesFromJson(String str) => Images.fromJson(json.decode(str));

String imagesToJson(Images data) => json.encode(data.toJson());

class Images {
  Images({
    String? image,
    int? sortOrder,
    int? bannerId,
  }) {
    _image = image;
    _sortOrder = sortOrder;
    _bannerId = bannerId;
  }

  Images.fromJson(dynamic json) {
    _image = json['image'];
    _sortOrder = json['sort_order'];
    _bannerId = json['banner_id'];
  }

  String? _image;
  int? _sortOrder;
  int? _bannerId;

  Images copyWith({
    String? image,
    int? sortOrder,
    int? bannerId,
  }) =>
      Images(
        image: image ?? _image,
        sortOrder: sortOrder ?? _sortOrder,
        bannerId: bannerId ?? _bannerId,
      );

  String? get image => _image;

  int? get sortOrder => _sortOrder;

  int? get bannerId => _bannerId;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['image'] = _image;
    map['sort_order'] = _sortOrder;
    map['banner_id'] = _bannerId;
    return map;
  }
}

/// category_id : 9
/// image : "1654235672kisspng-apple-watch-series-2-apple-watch-series-3-apple-wa-smart-apple-watch-sports-watch-band-5a8687ca23b730.4356046615187660261463-removebg-preview.png"
/// parent_id : "0"
/// sort_order : "9"
/// status : "1"
/// category_description : {"name":"Electronic","category_id":9}

