class PagesData {
  int? id;
  String? title;
  String? heading;
  String? description;

  PagesData({this.id, this.title, this.heading,   this.description});

  PagesData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    title = json['title'];
    heading = json['heading'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['title'] = title;
    data['heading'] = heading;
    data['description'] = description;
    return data;
  }
}