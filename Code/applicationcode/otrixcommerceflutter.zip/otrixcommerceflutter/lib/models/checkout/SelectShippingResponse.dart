import 'package:ecommerce/models/checkout/OrderSummary.dart';
import 'package:ecommerce/models/checkout/Shipping.dart';

class SelectShippingResponse {
  int? status;
  Shipping? shipping;
  List<OrderSummary>? orderSummary;
  String? grandTotal;

  SelectShippingResponse(
      {this.status, this.shipping, this.orderSummary, this.grandTotal});

  SelectShippingResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    shipping =
        json['shipping'] != null ? Shipping.fromJson(json['shipping']) : null;
    if (json['orderSummary'] != null) {
      orderSummary = <OrderSummary>[];
      json['orderSummary'].forEach((v) {
        orderSummary!.add(OrderSummary.fromJson(v));
      });
    }
    grandTotal = json['grandTotal'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    if (shipping != null) {
      data['shipping'] = shipping!.toJson();
    }
    if (orderSummary != null) {
      data['orderSummary'] = orderSummary!.map((v) => v.toJson()).toList();
    }
    data['grandTotal'] = grandTotal;
    return data;
  }
}
