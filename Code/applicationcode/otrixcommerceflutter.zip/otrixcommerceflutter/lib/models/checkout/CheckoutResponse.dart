import 'package:ecommerce/models/checkout/CheckoutData.dart';

class CheckoutResponse {
  int? status;
  CheckoutData? data;

  CheckoutResponse({this.status, this.data});

  CheckoutResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data = json['data'] != null ? CheckoutData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}
