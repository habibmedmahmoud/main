import 'package:ecommerce/models/address/address_model.dart';
import 'package:ecommerce/models/address/countriesModel.dart';
import 'package:ecommerce/models/checkout/ShippingMethods.dart';

class CheckoutData {
  List<ShippingMethods>? shippingMethods = [];
  List<AddressModel>? addresses = [];
  List<CountryModel>? countries = [];

  CheckoutData({this.shippingMethods, this.addresses, this.countries});

  CheckoutData.fromJson(Map<String, dynamic> json) {
    if (json['shippingMethods'] != null) {
      shippingMethods = <ShippingMethods>[];
      json['shippingMethods'].forEach((v) {
        shippingMethods!.add(ShippingMethods.fromJson(v));
      });
    }
    if (json['addresses'] != null) {
      addresses = <AddressModel>[];
      json['addresses'].forEach((v) {
        addresses!.add(AddressModel.fromJson(v));
      });
    }
    if (json['countries'] != null) {
      countries = <CountryModel>[];
      json['countries'].forEach((v) {
        countries!.add(CountryModel.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (shippingMethods != null) {
      data['shippingMethods'] =
          shippingMethods!.map((v) => v.toJson()).toList();
    }
    if (addresses != null) {
      data['addresses'] = addresses!.map((v) => v.toJson()).toList();
    }
    if (countries != null) {
      data['countries'] = countries!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}
