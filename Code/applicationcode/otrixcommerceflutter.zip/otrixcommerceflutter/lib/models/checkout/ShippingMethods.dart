
class ShippingMethods {
  int? id;
  String? name;
  String? shippingCharge;
  String? status; 

  ShippingMethods(
      {this.id,
        this.name,
        this.shippingCharge,
        this.status, });

  ShippingMethods.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    shippingCharge = json['shipping_charge'];
    status = json['status']?.toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['shipping_charge'] = shippingCharge;
    data['status'] = status;
    return data;
  }
}