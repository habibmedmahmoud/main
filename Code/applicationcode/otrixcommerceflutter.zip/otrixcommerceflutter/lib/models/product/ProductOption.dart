class ProductOption {
  String? productOptionId;
  String? productId;
  String? optionId;
  String? label;
  String? price;
  String? colorCode;
  bool? required;
  String? name;
  String? type;

  ProductOption(
      {this.productOptionId,
      this.productId,
      this.optionId,
      this.label,
      this.price,
      this.colorCode,
      this.required,
      this.name,
      this.type});

  ProductOption.fromJson(Map<String, dynamic> json) {
    productOptionId = json['product_option_id']?.toString();
    productId = json['product_id']?.toString();
    optionId = json['option_id']?.toString();
    label = json['label'];
    price = json['price'];
    colorCode = json['color_code'];
    required = json['required'];
    name = json['name'];
    type = json['type'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['product_option_id'] = productOptionId;
    data['product_id'] = productId;
    data['option_id'] = optionId;
    data['label'] = label;
    data['price'] = price;
    data['color_code'] = colorCode;
    data['required'] = required;
    data['name'] = name;
    data['type'] = type;
    return data;
  }
}
