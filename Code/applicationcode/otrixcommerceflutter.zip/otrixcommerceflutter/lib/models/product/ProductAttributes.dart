
class ProductAttributes {
  int? id;
  String? productId;
  String? attributeId;
  String? text;
  String? groupId;
  String? name;
  String? groupName;

  ProductAttributes(
      {this.id,
        this.productId,
        this.attributeId,
        this.text,
        this.groupId,
        this.name,
        this.groupName});

  ProductAttributes.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    productId = json['product_id'];
    attributeId = json['attribute_id'];
    text = json['text'];
    groupId = json['group_id'];
    name = json['name'];
    groupName = json['groupName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['product_id'] = this.productId;
    data['attribute_id'] = this.attributeId;
    data['text'] = this.text;
    data['group_id'] = this.groupId;
    data['name'] = this.name;
    data['groupName'] = this.groupName;
    return data;
  }
}