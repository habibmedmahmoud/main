
import 'package:ecommerce/models/product/ProductDetailResponse.dart';
import 'package:ecommerce/models/product/ProductSpecial.dart';

class RelatedProducts {
  int? id;
  String? image;
  String? price;
  int? quantity;
  int? sortOrder;
  int? status;
  String? dateAvailable;
  String? reviewAvg;
  ProductDescription? productDescription;
  ProductSpecial? special;

  RelatedProducts(
      {this.id,
        this.image,
        this.price,
        this.quantity,
        this.sortOrder,
        this.status,
        this.dateAvailable,
        this.reviewAvg,
        this.productDescription,
        this.special});

  RelatedProducts.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    image = json['image'];
    price = json['price'];
    quantity = json['quantity'] ;
    sortOrder = json['sort_order'] ;
    status = json['status'] ;
    dateAvailable = json['date_available'];
    reviewAvg = json['review_avg'];
    productDescription = json['product_description'] != null
        ? ProductDescription.fromJson(json['product_description'])
        : null;
    special = json['special'] != null
        ? ProductSpecial.fromJson(json['special'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['image'] = image;
    data['price'] = price;
    data['quantity'] = quantity;
    data['sort_order'] = sortOrder;
    data['status'] = status;
    data['date_available'] = dateAvailable;
    data['review_avg'] = reviewAvg;
    if (productDescription != null) {
      data['product_description'] = productDescription!.toJson();
    }
    if (special != null) {
      data['special'] = special!.toJson();
    }
    return data;
  }
}