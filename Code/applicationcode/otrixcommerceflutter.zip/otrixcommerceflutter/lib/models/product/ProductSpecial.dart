class ProductSpecial {
  int? id;
  String? productId;
  String? price;
  String? startDate;
  String? endDate;

  ProductSpecial(
      {this.id, this.productId, this.price, this.startDate, this.endDate});

  ProductSpecial.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    productId = json['product_id']?.toString();
    price = json['price']?.toString();
    startDate = json['start_date'];
    endDate = json['end_date'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['product_id'] = productId;
    data['price'] = price;
    data['start_date'] = startDate;
    data['end_date'] = endDate;
    return data;
  }
}