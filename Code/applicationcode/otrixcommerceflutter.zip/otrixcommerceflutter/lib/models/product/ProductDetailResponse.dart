// ignore: file_names
import 'package:ecommerce/models/product/ProductAttributes.dart';
import 'package:ecommerce/models/product/ProductOption.dart';
import 'package:ecommerce/models/product/ProductSpecial.dart';
import 'package:ecommerce/models/product/RelatedProducts.dart';

class ProductDetailResponse {
  int? status;
  ProductDetailResponseData? data;

  ProductDetailResponse({this.status, this.data});

  ProductDetailResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data = json['data'] != null
        ? ProductDetailResponseData.fromJson(json['data'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}

class ProductDetailResponseData {
  List<RelatedProducts>? relatedProducts;
  List<ProductImages>? productImages;
  Map<String, List<ProductAttributes>>? productAttributes;
  ProductSpecial? productSpecial;
  ProductData? data;
  int? totalReviews;
  String? star1;
  String? star2;
  String? star3;
  String? star4;
  String? star5;
  String? avgReview;
  Map<String, List<ProductOption>>? productOptions;

  ProductDetailResponseData(
      {this.relatedProducts,
      this.productImages,
      this.productAttributes,
      this.productSpecial,
      this.data,
      this.totalReviews,
      this.star1,
      this.star2,
      this.star3,
      this.star4,
      this.star5,
      this.avgReview,
      this.productOptions});

  ProductDetailResponseData.fromJson(Map<String, dynamic> json) {
    if (json['reletedProducts'] != null) {
      relatedProducts = <RelatedProducts>[];
      json['reletedProducts'].forEach((v) {
        relatedProducts!.add(RelatedProducts.fromJson(v));
      });
    }
    if (json['productImages'] != null) {
      productImages = <ProductImages>[];
      json['productImages'].forEach((v) {
        productImages!.add(ProductImages.fromJson(v));
      });
    }
    if (json['productAttributes'] != null) {
      productAttributes = {};
      var d = json['productAttributes'];
      if (d is Map<String, dynamic>) {
        for (var element in d.keys) {
          List<ProductAttributes> pOptions = [];
          var listItem = d[element];
          if (listItem is List) {
            for (var v in listItem) {
              pOptions.add(ProductAttributes.fromJson(v));
            }
          }
          productAttributes!.addAll({element.toString(): pOptions});
        }
      }
    }
    productSpecial = json['productSpecial'] != null
        ? ProductSpecial.fromJson(json['productSpecial'])
        : null;
    data = json['data'] != null ? ProductData.fromJson(json['data']) : null;
    totalReviews = json['totalReviews'];
    star1 = json['star1'];
    star2 = json['star2'];
    star3 = json['star3'];
    star4 = json['star4'];
    star5 = json['star5'];
    avgReview = json['avgReview'];
    if (json['productOptions'] != null) {
      productOptions = {};
      var d = json['productOptions'];
      if (d is Map<String, dynamic>) {
        for (var element in d.keys) {
          List<ProductOption> pOptions = [];
          var listItem = d[element];
          if (listItem is List) {
            for (var v in listItem) {
              pOptions.add(ProductOption.fromJson(v));
            }
          }
          productOptions!.addAll({element.toString(): pOptions});
        }
      }
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    if (relatedProducts != null) {
      data['reletedProducts'] =
          relatedProducts!.map((v) => v.toJson()).toList();
    }
    if (productImages != null) {
      data['productImages'] = productImages!.map((v) => v.toJson()).toList();
    }
    if (productAttributes != null) {
      Map<String, dynamic> d = {};
      for (var element in productAttributes!.keys) {
        List<Map<String, dynamic>> listItem = [];
        productAttributes![element]!.forEach((element) {
          listItem.add(element.toJson());
        });
        d.addAll({element: listItem});
      }
      data['productAttributes'] = d;
    }

    if (productSpecial != null) {
      data['productSpecial'] = productSpecial!.toJson();
    }
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    data['totalReviews'] = totalReviews;
    data['star1'] = star1;
    data['star2'] = star2;
    data['star3'] = star3;
    data['star4'] = star4;
    data['star5'] = star5;
    data['avgReview'] = avgReview;
    if (productOptions != null) {
      Map<String, dynamic> d = {};
      for (var element in productOptions!.keys) {
        List<Map<String, dynamic>> listItem = [];
        productOptions![element]!.forEach((element) {
          listItem.add(element.toJson());
        });
        d.addAll({element: listItem});
      }
      data['productOptions'] = d;
    }
    return data;
  }
}

class ProductImages {
  int? id;
  String? productId;
  String? image;
  String? sortOrderImage;

  ProductImages({this.id, this.productId, this.image, this.sortOrderImage});

  ProductImages.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    productId = json['product_id']?.toString();
    image = json['image'];
    sortOrderImage = json['sort_order_image']?.toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['product_id'] = productId;
    data['image'] = image;
    data['sort_order_image'] = sortOrderImage;
    return data;
  }
}

class General {
  int? id;
  String? productId;
  String? attributeId;
  String? text;
  String? groupId;
  String? name;
  String? groupName;

  General(
      {this.id,
      this.productId,
      this.attributeId,
      this.text,
      this.groupId,
      this.name,
      this.groupName});

  General.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    productId = json['product_id'];
    attributeId = json['attribute_id'];
    text = json['text'];
    groupId = json['group_id'];
    name = json['name'];
    groupName = json['groupName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['product_id'] = productId;
    data['attribute_id'] = attributeId;
    data['text'] = text;
    data['group_id'] = groupId;
    data['name'] = name;
    data['groupName'] = groupName;
    return data;
  }
}

class Category {
  String? name;
  int? categoryId;

  Category({this.name, this.categoryId});

  Category.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    categoryId = json['category_id'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    data['category_id'] = categoryId;
    return data;
  }
}

class ProductDescription {
  int? id;
  String? productId;
  String? name;
  String? description;

  ProductDescription({this.id, this.productId, this.name, this.description});

  ProductDescription.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    productId = json['product_id']?.toString();
    name = json['name'];
    description = json['description'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['product_id'] = productId;
    data['name'] = name;
    data['description'] = description;
    return data;
  }
}

class ProductData {
  int? id;
  int? categoryId;
  String? sellerId;
  String? model;
  String? jan;
  String? isbn;
  String? mpn;
  String? location;
  int? quantity;
  int? stockStatusId;
  String? image;
  int? manufacturerId;
  String? shipping;
  String? price;
  int? points;
  int? taxRateId;
  String? dateAvailable;
  String? weight;
  String? length;
  String? width;
  String? height;
  int? lengthClassId;
  int? subtract;
  int? minimum;
  int? sortOrder;
  int? status;
  int? viewed;
  int? weightClassId;
  String? createdAt;
  String? updatedAt;
  String? deletedAt;
  Category? category;
  ProductDescription? productDescription;

  ProductData(
      {this.id,
      this.categoryId,
      this.sellerId,
      this.model,
      this.jan,
      this.isbn,
      this.mpn,
      this.location,
      this.quantity,
      this.stockStatusId,
      this.image,
      this.manufacturerId,
      this.shipping,
      this.price,
      this.points,
      this.taxRateId,
      this.dateAvailable,
      this.weight,
      this.weightClassId,
      this.length,
      this.width,
      this.height,
      this.lengthClassId,
      this.subtract,
      this.minimum,
      this.sortOrder,
      this.status,
      this.viewed,
      this.createdAt,
      this.updatedAt,
      this.deletedAt,
      this.category,
      this.productDescription});

  ProductData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    categoryId = json['category_id'];
    sellerId = json['seller_id'];
    model = json['model'];
    jan = json['jan'];
    isbn = json['isbn'];
    mpn = json['mpn'];
    location = json['location'];
    quantity = json['quantity'];
    stockStatusId = json['stock_status_id'];
    image = json['image'];
    manufacturerId = json['manufacturer_id'];
    shipping = json['shipping'];
    price = json['price'];
    points = json['points'];
    taxRateId = json['tax_rate_id'];
    dateAvailable = json['date_available'];
    weight = json['weight'];
    weightClassId = json['weight_class_id'];
    length = json['length'];
    width = json['width'];
    height = json['height'];
    lengthClassId = json['length_class_id'];
    subtract = json['subtract'];
    minimum = json['minimum'];
    sortOrder = json['sort_order'];
    status = json['status'];
    viewed = json['viewed'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
    deletedAt = json['deleted_at'];
    category =
        json['category'] != null ? Category.fromJson(json['category']) : null;
    productDescription = json['product_description'] != null
        ? ProductDescription.fromJson(json['product_description'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['category_id'] = categoryId;
    data['seller_id'] = sellerId;
    data['model'] = model;
    data['jan'] = jan;
    data['isbn'] = isbn;
    data['mpn'] = mpn;
    data['location'] = location;
    data['quantity'] = quantity;
    data['stock_status_id'] = stockStatusId;
    data['image'] = image;
    data['manufacturer_id'] = manufacturerId;
    data['shipping'] = shipping;
    data['price'] = price;
    data['points'] = points;
    data['tax_rate_id'] = taxRateId;
    data['date_available'] = dateAvailable;
    data['weight'] = weight;
    data['weight_class_id'] = weightClassId;
    data['length'] = length;
    data['width'] = width;
    data['height'] = height;
    data['length_class_id'] = lengthClassId;
    data['subtract'] = subtract;
    data['minimum'] = minimum;
    data['sort_order'] = sortOrder;
    data['status'] = status;
    data['viewed'] = viewed;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
    data['deleted_at'] = deletedAt;
    if (category != null) {
      data['category'] = category!.toJson();
    }
    if (productDescription != null) {
      data['product_description'] = productDescription!.toJson();
    }
    return data;
  }
}
