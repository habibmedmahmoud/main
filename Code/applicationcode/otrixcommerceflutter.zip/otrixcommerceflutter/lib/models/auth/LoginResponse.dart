import 'package:ecommerce/models/UserData.dart';

class LoginResponse {
  int? status;
  List<String>? wishlistData;
  String? cartCount;
  String? message;
  UserData? data;

  LoginResponse(
      {this.status,
      this.wishlistData,
      this.cartCount,
      this.message,
      this.data});

  LoginResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    wishlistData =
        json['wishlistData'] == null ? [] : json['wishlistData'].cast<String>();
    cartCount = json['cartCount'];
    message = json['message'];
    data = json['data'] != null ? UserData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    data['wishlistData'] = wishlistData;
    data['cartCount'] = cartCount;
    data['message'] = message;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}
