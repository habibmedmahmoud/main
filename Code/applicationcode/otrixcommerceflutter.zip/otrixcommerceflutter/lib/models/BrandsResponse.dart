class BrandsResponse {
  int? status;
  List<BrandsData>? data = [];

  BrandsResponse({this.status, this.data});

  BrandsResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    if (json['data'] != null) {
      data = <BrandsData>[];
      json['data'].forEach((v) {
        data!.add(BrandsData.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = Map<String, dynamic>();
    data['status'] = status;
    if (this.data != null) {
      data['data'] = this.data!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class BrandsData {
  int? id;
  String? name;
  int? status;
  int? sortOrder;
  String? image;

  BrandsData({this.id, this.name, this.status, this.sortOrder, this.image});

  BrandsData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    status = json['status'];
    sortOrder = json['sort_order'];
    image = json['image'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['name'] = name;
    data['status'] = status;
    data['sort_order'] = sortOrder;
    data['image'] = image;
    return data;
  }
}
