class CartData {
  String? cartId;
  String? name;
  String? price;
  String? quantity;
  String? image;
  int? id;
  int? totalPrice;
  String? special;
  String? taxStatus;
  String? taxType;
  String? rate;
  String? taxName;

  CartData(
      {this.cartId,
      this.name,
      this.price,
      this.quantity,
      this.image,
      this.id,
      this.totalPrice,
      this.special,
      this.taxStatus,
      this.taxType,
      this.rate,
      this.taxName});

  CartData.fromJson(Map<String, dynamic> json) {
    cartId = json['cart_id']?.toString();
    name = json['name'];
    price = json['price'];
    quantity = json['quantity']?.toString();
    image = json['image'];
    id = json['id'];
    totalPrice = json['totalPrice'];
    special = json['special'];
    taxStatus = json['taxStatus'];
    taxType = json['taxType'];
    rate = json['rate'];
    taxName = json['taxName'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['cart_id'] = cartId;
    data['name'] = name;
    data['price'] = price;
    data['quantity'] = quantity;
    data['image'] = image;
    data['id'] = id;
    data['totalPrice'] = totalPrice;
    data['special'] = special;
    data['taxStatus'] = taxStatus;
    data['taxType'] = taxType;
    data['rate'] = rate;
    data['taxName'] = taxName;
    return data;
  }
}
