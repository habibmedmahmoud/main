class Taxes {
  String? name;
  double? taxAmount;

  Taxes({this.name, this.taxAmount});

  Taxes.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    taxAmount = json['taxAmount'] != null ?  double.parse(json['taxAmount'].toString()) : 0;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    data['taxAmount'] = taxAmount;
    return data;
  }
}
