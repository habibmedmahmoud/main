import 'package:ecommerce/models/cart/CartData.dart';
import 'package:ecommerce/models/cart/Discount.dart';
import 'package:ecommerce/models/cart/Taxes.dart';

class CartResponse {
  int? status;
  List<CartData>? cartData;
  String? subTotal;
  Discount? discount;
  Taxes? taxes;
  String? grandTotal;
  String? cartCount;

  CartResponse(
      {this.status,
      this.cartData,
      this.subTotal,
      this.discount,
      this.taxes,
      this.cartCount,
      this.grandTotal});

  CartResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    cartCount = json['cartCount'];
    if (json['cartData'] != null) {
      cartData = <CartData>[];
      json['cartData'].forEach((v) {
        cartData!.add(CartData.fromJson(v));
      });
    }
    subTotal = json['subTotal'];
    taxes = json['taxes'] != null ? Taxes.fromJson(json['taxes']) : null;
    discount = json['discount'] != null
        ?   Discount.fromJson(json['discount'])
            : null ;
    grandTotal = json['grandTotal'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    if (cartData != null) {
      data['cartData'] = cartData!.map((v) => v.toJson()).toList();
    }
    data['subTotal'] = subTotal;
    if (taxes != null) {
      data['taxes'] = taxes!.toJson();
    }
    if (discount != null) {
      data['discount'] = discount!.toJson();
    }
    data['grandTotal'] = grandTotal;
    data['cartCount'] = cartCount;
    return data;
  }
}
