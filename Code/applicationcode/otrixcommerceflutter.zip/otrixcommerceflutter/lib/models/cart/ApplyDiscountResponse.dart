import 'package:ecommerce/models/cart/Discount.dart';

class ApplyDiscountResponse {
  int? status;
  String? message;
  Discount? discount;
  String? grandTotal;

  ApplyDiscountResponse(
      {this.status, this.message, this.discount, this.grandTotal});

  ApplyDiscountResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    discount =
        json['discount'] != null ? Discount.fromJson(json['discount']) : null;
    grandTotal = json['grandTotal'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    data['message'] = message;
    if (discount != null) {
      data['discount'] = discount!.toJson();
    }
    data['grandTotal'] = grandTotal;
    return data;
  }
}
