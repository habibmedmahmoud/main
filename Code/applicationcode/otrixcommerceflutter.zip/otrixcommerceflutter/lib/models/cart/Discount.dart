class Discount {
  String? name;
  String? discountAmt;
  String? type;
  String? discount;

  Discount({this.name, this.discountAmt, this.type, this.discount});

  Discount.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    discountAmt = json['discountAmt'];
    type = json['type']?.toString();
    discount = json['discount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    data['discountAmt'] = discountAmt;
    data['type'] = type;
    data['discount'] = discount;
    return data;
  }
}