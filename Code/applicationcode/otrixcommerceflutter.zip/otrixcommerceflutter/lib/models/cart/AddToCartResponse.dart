class AddToCartResponse {
  int? status;
  String? message;
  String? cartCount;

  AddToCartResponse({this.status, this.message, this.cartCount});

  AddToCartResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    cartCount = json['cartCount'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    data['message'] = message;
    data['cartCount'] = cartCount;
    return data;
  }
}
