class OrderProduct {
  String? name;
  String? quantity;
  String? image;
  String? orderId;
  String? productId;
  String? total;

  OrderProduct(
      {this.name,
        this.quantity,
        this.image,
        this.orderId,
        this.productId,
        this.total});

  OrderProduct.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    quantity = json['quantity']?.toString();
    image = json['image'];
    orderId = json['order_id']?.toString();
    productId = json['product_id']?.toString();
    total = json['total']?.toString();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['name'] = name;
    data['quantity'] = quantity;
    data['image'] = image;
    data['order_id'] = orderId;
    data['product_id'] = productId;
    data['total'] = total;
    return data;
  }
}