import 'package:ecommerce/models/order/order_data.dart';

class OrderListResponse {
  int? status;
  OrderData? data;

  OrderListResponse({this.status, this.data});

  OrderListResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    data = json['data'] != null ? OrderData.fromJson(json['data']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    if (this.data != null) {
      data['data'] = this.data!.toJson();
    }
    return data;
  }
}
