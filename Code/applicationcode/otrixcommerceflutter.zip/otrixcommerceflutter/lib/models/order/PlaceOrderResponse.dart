class PlaceOrderResponse {
  int? status;
  String? message;
  int? orderID;

  PlaceOrderResponse({this.status, this.message, this.orderID});

  PlaceOrderResponse.fromJson(Map<String, dynamic> json) {
    status = json['status'];
    message = json['message'];
    orderID = json['orderID'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['status'] = status;
    data['message'] = message;
    data['orderID'] = orderID;
    return data;
  }
}
