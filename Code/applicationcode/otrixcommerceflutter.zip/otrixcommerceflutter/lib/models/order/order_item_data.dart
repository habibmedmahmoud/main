import 'package:ecommerce/models/order/order_product.dart';
import 'package:ecommerce/models/order/order_status.dart';

class OrderItem {
  int? id;
  String? invoiceNo;
  String? invoicePrefix;
  String? customerId;
  //Null? customerGroupId;
  String? firstname;
  String? lastname;
  String? email;
  String? telephone;
  String? shippingName;
  String? shippingAddress1;
  String? shippingAddress2;
  String? shippingCity;
  String? shippingPostcode;
  String? shippingCountryId;
  String? comment;
  String? total;
  String? orderStatusId;
  //Null? commission;
  String? taxAmount;
  String? discount;
  String? shippingCharge;
  String? paymentMethod;
  String? transactionId;
  String? grandTotal;
 // Null? tracking;
 // Null? languageId;
 // Null? ip;
  String? orderDate;
 // Null? forwardedIp;
 // Null? userAgent;
 // Null? acceptLanguage;
  String? createdAt;
  String? updatedAt;
 // Null? deletedAt;
  OrderStatus? orderStatus;
  List<OrderProduct>? products;

  OrderItem(
      {this.id,
        this.invoiceNo,
        this.invoicePrefix,
        this.customerId,
      //  this.customerGroupId,
        this.firstname,
        this.lastname,
        this.email,
        this.telephone,
        this.shippingName,
        this.shippingAddress1,
        this.shippingAddress2,
        this.shippingCity,
        this.shippingPostcode,
        this.shippingCountryId,
        this.comment,
        this.total,
        this.orderStatusId,
     //   this.commission,
        this.taxAmount,
        this.discount,
        this.shippingCharge,
        this.paymentMethod,
        this.transactionId,
        this.grandTotal,
      //  this.tracking,
     //   this.languageId,
      //  this.ip,
        this.orderDate,
      //  this.forwardedIp,
      //  this.userAgent,
     //   this.acceptLanguage,
        this.createdAt,
        this.updatedAt,
      //  this.deletedAt,
        this.orderStatus,
        this.products});

  OrderItem.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    invoiceNo = json['invoice_no']?.toString();
    invoicePrefix = json['invoice_prefix'];
    customerId = json['customer_id']?.toString();
   // customerGroupId = json['customer_group_id'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    email = json['email'];
    telephone = json['telephone'];
    shippingName = json['shipping_name'];
    shippingAddress1 = json['shipping_address_1'];
    shippingAddress2 = json['shipping_address_2'];
    shippingCity = json['shipping_city'];
    shippingPostcode = json['shipping_postcode'];
    shippingCountryId = json['shipping_country_id']?.toString();
    comment = json['comment'];
    total = json['total'];
    orderStatusId = json['order_status_id']?.toString();
  //  commission = json['commission'];
    taxAmount = json['tax_amount'];
    discount = json['discount'];
    shippingCharge = json['shipping_charge'];
    paymentMethod = json['payment_method'];
    transactionId = json['transaction_id']?.toString();
    grandTotal = json['grand_total'];
  //  tracking = json['tracking'];
  //  languageId = json['language_id'];
  //  ip = json['ip'];
    orderDate = json['order_date'];
  //  forwardedIp = json['forwarded_ip'];
  //  userAgent = json['user_agent'];
  //  acceptLanguage = json['accept_language'];
    createdAt = json['created_at'];
    updatedAt = json['updated_at'];
  //  deletedAt = json['deleted_at'];
    orderStatus = json['order_status'] != null
        ? OrderStatus.fromJson(json['order_status'])
        : null;
    if (json['products'] != null) {
      products = <OrderProduct>[];
      json['products'].forEach((v) {
        products!.add(OrderProduct.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['invoice_no'] = invoiceNo;
    data['invoice_prefix'] = invoicePrefix;
    data['customer_id'] = customerId;
  //  data['customer_group_id'] = customerGroupId;
    data['firstname'] = firstname;
    data['lastname'] = lastname;
    data['email'] = email;
    data['telephone'] = telephone;
    data['shipping_name'] = shippingName;
    data['shipping_address_1'] = shippingAddress1;
    data['shipping_address_2'] = shippingAddress2;
    data['shipping_city'] = shippingCity;
    data['shipping_postcode'] = shippingPostcode;
    data['shipping_country_id'] = shippingCountryId;
    data['comment'] = comment;
    data['total'] = total;
    data['order_status_id'] = orderStatusId;
   // data['commission'] = commission;
    data['tax_amount'] = taxAmount;
    data['discount'] = discount;
    data['shipping_charge'] = shippingCharge;
    data['payment_method'] = paymentMethod;
    data['transaction_id'] = transactionId;
    data['grand_total'] = grandTotal;
  //  data['tracking'] = tracking;
 //   data['language_id'] = languageId;
  //  data['ip'] = ip;
    data['order_date'] = orderDate;
  //  data['forwarded_ip'] = forwardedIp;
  //  data['user_agent'] = userAgent;
  //  data['accept_language'] = acceptLanguage;
    data['created_at'] = createdAt;
    data['updated_at'] = updatedAt;
   // data['deleted_at'] = deletedAt;
    if (orderStatus != null) {
      data['order_status'] = orderStatus!.toJson();
    }
    if (products != null) {
      data['products'] = products!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}
