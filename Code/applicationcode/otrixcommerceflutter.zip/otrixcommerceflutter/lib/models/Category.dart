
import 'dart:convert';

Categories categoriesFromJson(String str) =>
    Categories.fromJson(json.decode(str));

String categoriesToJson(Categories data) => json.encode(data.toJson());

class Categories {
  Categories({
    int? categoryId,
    String? image,
    String? parentId,
    String? sortOrder,
    String? status,
    CategoryDescription? categoryDescription,
  }) {
    _categoryId = categoryId;
    _image = image;
    _parentId = parentId;
    _sortOrder = sortOrder;
    _status = status;
    _categoryDescription = categoryDescription;
  }

  Categories.fromJson(dynamic json) {
    _categoryId = json['category_id'];
    _image = json['image'];
    _parentId = json['parent_id'];
    _sortOrder = json['sort_order'];
    _status = json['status'];
    _categoryDescription = json['category_description'] != null
        ? CategoryDescription.fromJson(json['category_description'])
        : null;
  }

  int? _categoryId;
  String? _image;
  String? _parentId;
  String? _sortOrder;
  String? _status;
  CategoryDescription? _categoryDescription;

  Categories copyWith({
    int? categoryId,
    String? image,
    String? parentId,
    String? sortOrder,
    String? status,
    CategoryDescription? categoryDescription,
  }) =>
      Categories(
        categoryId: categoryId ?? _categoryId,
        image: image ?? _image,
        parentId: parentId ?? _parentId,
        sortOrder: sortOrder ?? _sortOrder,
        status: status ?? _status,
        categoryDescription: categoryDescription ?? _categoryDescription,
      );

  int? get categoryId => _categoryId;

  String? get image => _image;

  String? get parentId => _parentId;

  String? get sortOrder => _sortOrder;

  String? get status => _status;

  CategoryDescription? get categoryDescription => _categoryDescription;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['category_id'] = _categoryId;
    map['image'] = _image;
    map['parent_id'] = _parentId;
    map['sort_order'] = _sortOrder;
    map['status'] = _status;
    if (_categoryDescription != null) {
      map['category_description'] = _categoryDescription?.toJson();
    }
    return map;
  }
}

/// name : "Electronic"
/// category_id : 9

CategoryDescription categoryDescriptionFromJson(String str) =>
    CategoryDescription.fromJson(json.decode(str));

String categoryDescriptionToJson(CategoryDescription data) =>
    json.encode(data.toJson());

class CategoryDescription {
  CategoryDescription({
    String? name,
    int? categoryId,
  }) {
    _name = name;
    _categoryId = categoryId;
  }

  CategoryDescription.fromJson(dynamic json) {
    _name = json['name'];
    _categoryId = json['category_id'];
  }

  String? _name;
  int? _categoryId;

  CategoryDescription copyWith({
    String? name,
    int? categoryId,
  }) =>
      CategoryDescription(
        name: name ?? _name,
        categoryId: categoryId ?? _categoryId,
      );

  String? get name => _name;

  int? get categoryId => _categoryId;

  Map<String, dynamic> toJson() {
    final map = <String, dynamic>{};
    map['name'] = _name;
    map['category_id'] = _categoryId;
    return map;
  }
}