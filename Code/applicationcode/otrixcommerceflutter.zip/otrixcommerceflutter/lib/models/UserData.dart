class UserData {
  int? id;
  String? email;
  String? image;
  String? firstname;
  String? lastname;
  String? telephone;
  String? creation;
  String? firebaseToken;
  String? updatedAt;

  UserData(
      {this.id,
      this.email,
      this.image,
      this.firstname,
      this.lastname,
      this.telephone,
      this.creation,
      this.firebaseToken,
      this.updatedAt});

  UserData.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    email = json['email'];
    image = json['image'];
    firstname = json['firstname'];
    lastname = json['lastname'];
    telephone = json['telephone'];
    creation = json['creation'];
    firebaseToken = json['firebase_token'];
    updatedAt = json['updated_at'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = <String, dynamic>{};
    data['id'] = id;
    data['email'] = email;
    data['image'] = image;
    data['firstname'] = firstname;
    data['lastname'] = lastname;
    data['telephone'] = telephone;
    data['creation'] = creation;
    data['firebase_token'] = firebaseToken;
    data['updated_at'] = updatedAt;
    return data;
  }
}
