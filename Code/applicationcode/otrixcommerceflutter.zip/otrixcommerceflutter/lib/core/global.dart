class Global {
  static String theme = 'light';

  static setTheme(String val) {
    theme = val;
  }

  static getTheme() {
    return theme;
  }
}
