import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:ecommerce/core/Constants.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'common.dart';

class AppGlobal {
  static GlobalKey<ScaffoldMessengerState> scaffoldMessengerKey =
      GlobalKey<ScaffoldMessengerState>();

  static setString(String key, String value) async {
    var prefs = await SharedPreferences.getInstance();
    prefs.setString(key, value);
  }

  static Future<String> getString(String key) async {
    var prefs = await SharedPreferences.getInstance();
    return prefs.getString(key) ?? "";
  }

  static setDouble(String key, double value) async {
    var prefs = await SharedPreferences.getInstance();
    prefs.setDouble(key, value);
  }

  static getDouble(String key) async {
    var prefs = await SharedPreferences.getInstance();
    return prefs.getDouble(key);
  }

  static setInt(String key, int value) async {
    var prefs = await SharedPreferences.getInstance();
    prefs.setInt(key, value);
  }

  static setStringList(String key, List<String> value) async {
    var prefs = await SharedPreferences.getInstance();
    prefs.setStringList(key, value);
  }

  static getStringList(String key) async {
    var prefs = await SharedPreferences.getInstance();
    return prefs.getStringList(key) ?? [];
  }

  static getInt(String key) async {
    var prefs = await SharedPreferences.getInstance();
    return prefs.getInt(key);
  }

  static showToast(String message) {
    Fluttertoast.showToast(
        msg: message,
        toastLength: Toast.LENGTH_SHORT,
        gravity: ToastGravity.BOTTOM,
        timeInSecForIosWeb: 4,
        backgroundColor: Colors.black38,
        textColor: Colors.white,
        fontSize: 15.0);
  }

  static fieldFocusChange(
      BuildContext context, FocusNode currentFocus, FocusNode nextFocus) {
    currentFocus.unfocus();
    FocusScope.of(context).requestFocus(nextFocus);
  }

  static isNetConnected() async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    bool connected = false;
    if (connectivityResult == ConnectivityResult.mobile ||
        connectivityResult == ConnectivityResult.wifi) {
      connected = true;
    }
    return connected;
  }

  static logOut() async {
    SharedPreferences preferences = await SharedPreferences.getInstance();
    preferences.clear();
    preferences.setString(Constants.firstTime, "1");
  }

  static String priceToDecimal(double value) {
    var f = NumberFormat("###.00", "en_US");
    return f.format(value).toString();
  }

  static String formatDate(String strDate) {
    var today = DateTime.parse(strDate);

    var formatter = DateFormat('dd MMM,yyyy');
    String formatted = formatter.format(today);
    return formatted;
  }

  static String formatDateTime(String strDate) {
    var today = DateTime.parse(strDate);

    var formatter = DateFormat('dd MMM,yyyy | hh:mm a');
    String formatted = formatter.format(today);
    return formatted;
  }

  static bool emailValidate(String value) {
    // ignore: unnecessary_null_comparison
    if (value == null) return false;
    return RegExp(
            r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
        .hasMatch(value);
  }

  static showSnackbar(String message, {int? type}) async {
    final snackBar = SnackBar(
      content: Text(
        message,
        style:
            const TextStyle(color: white, fontFamily: mediumFont, fontSize: 14),
      ),
      backgroundColor: type == 1
          ? Colors.green
          : type == 2
              ? Colors.red
              : primaryColor,
      duration: const Duration(milliseconds: 1000),
      action: SnackBarAction(
        label: 'Close',
        textColor: white,
        disabledTextColor: white,
        onPressed: () {
          scaffoldMessengerKey.currentState?.hideCurrentSnackBar();
        },
      ),
    );
    // ignore: deprecated_member_use
    scaffoldMessengerKey.currentState?.showSnackBar(snackBar);
  }

  String? mobileNumberValidator(String? p1) {
    if (p1 == null) {
      return "Enter mobile number";
    } else if (p1.isEmpty) {
      return "Enter mobile number";
    } else if (p1.length < 10) {
      return "Enter valid mobile number";
    } else {
      return null;
    }
  }

  String? emailValidator(String? p1) {
    if (p1 == null) {
      return "Enter Email";
    } else if (p1.isEmpty) {
      return "Enter Email Address";
    } else if (!emailValidate(p1)) {
      return "Enter valid email ";
    } else {
      return null;
    }
  }

  String? passwordValidator(String? p1) {
    if (p1 == null) {
      return "Enter password";
    } else if (p1.isEmpty) {
      return "Enter password";
    } else if (p1.length < 4) {
      return "Enter minimum 4 character password";
    } else {
      return null;
    }
  }

  String? confirmPasswordValidator(String? p1, String? p2) {
    if (p2 == null) {
      return null;
    } else if (p2.isEmpty) {
      return null;
    } else if (p1 != p2) {
      return "Confirm password Does not match";
    } else {
      return null;
    }
  }

  String? valueValidator(String? val, String error) {
    if (val == null) {
      return error;
    } else if (val.trim().isEmpty) {
      return error;
    } else {
      return null;
    }
  }

  static getDiscountCalculation(String originalPrice, String discountPrice) {
    return ((100 *
                (double.parse(originalPrice) - double.parse(discountPrice))) /
            double.parse(originalPrice))
        .toStringAsFixed(2);
  }

  static Color getHexColor(String hexString) {
    final buffer = StringBuffer();
    if (hexString.length == 6 || hexString.length == 7) buffer.write('ff');
    buffer.write(hexString.replaceFirst('#', ''));
    return Color(int.parse(buffer.toString(), radix: 16));
  }
}
