
import 'package:ecommerce/core/global.dart';
import 'package:flutter/material.dart';

const white = Colors.white;
const black = Colors.black;
const grey = Colors.grey;
const blackLight = Colors.black12;
const blackDarkLight = Colors.black54;
const lightBlack = Color.fromRGBO(74, 74, 74, 1);
const Color primaryColor = Color(0xff626ABB);
const Color assetColor = Color(0xff121533);
const Color backgroundColor = Color(0xffE5E5E5);
const Color greyTextColor = Color(0xff767787);
const Color commonBackgroundColor =  Color(0xffFAFAFA);
const Color buttonColor = Color(0xff123c89);

const String appName = "Otrix E-Commerce";
const String currency = "\$";

const String mediumFont = "MediumFont";
const String boldFont = "BoldFont";
const String lightFont = "LightFont";
const String blackFont = "BlackFont";
const String regularFont = "RegularFont";

const String somethingWrong = "Something wrong please try again";

class Common {

  static  List paymentMethods = [
    { "id": "1", "name": 'Credit / Debit / ATM Card', "value": 'creditCard' },
    { "id": "2", "name": "Cash On Delivery", "value": 'cod' }
  ];

  static Color getPrimaryColor() {
    return Global.theme == 'dark' ? black : primaryColor;
  }


  static Color getWhitePrimaryColor() {
    return Global.theme == 'dark' ? white : primaryColor;
  }

  static Color getBackgroundColor() {
    return Global.theme == 'dark' ? const Color(0xff212121) : commonBackgroundColor;
  }

  static Color getAppBarBgColor() {
    return Global.theme == 'dark' ? const Color(0xffBDBDBD) : primaryColor;
  }

  static Color getWhiteBlackColor() {
    return Global.theme == 'dark' ? white : black;
  }
  static Color getButtonFooterColor() {
    return Global.theme == 'dark' ? const Color(0xff616161) : buttonColor;
  }
  static Color getCardBGColor() {
    return Global.theme == 'dark' ? const Color(0xff424242) : white;
  }


  static Color getProfileButtonColor() {
    return Global.theme == 'dark' ? const Color(0xff9E9E9E) : primaryColor;
  }

  static Color getMessageInputBackgroundColor() {
    return Global.theme == 'dark' ? Colors.grey : Colors.grey.shade300;
  }




  static Color  lightWhite= const Color(0xfff7f7f8);
  static Color  textColor= const Color(0xff121533);
  static Color  customGray= const Color.fromRGBO(182, 182, 182, 1);
  static Color  customPurple= const Color.fromARGB(1,255, 229,0);

  /*

    secondry_text_color: '#767787',
    link_color: '#626ABB',
    themeColor: "#626ABB",
    categoryBG: '#f5f5ff',
    red: '#ff4848',
    success: '#00A36C',
    arrow_color: 'rgb(200,204,216)',
    custom_pink: 'rgb(247,74,105)',
    loader_bg: 'rgba(128,128,128,0.5)',
    white: '#fff',
    offWhite: 'rgb(255,255,255)',
    newTag: 'rgba(103, 103, 105, 1)',
    black: 'rgb(0,0,0)',
    light_gray: 'rgb(237,237,237)',
    placeholderTextColor: 'rgb(152,152,152)',
    backgroundColor: 'rgb(250,250,250)',
    languageBackgroundColor: 'rgba(255,255,255, 0.8)',
    lightYellowBackground: 'white',
    selectedGreen: 'rgba(0,118,22, 0.2)',
    green_text: '#0EC139',
    black_text: '#000000',
    dark_gray_text: '#AAAAAA',
    light_gray_text: '#EEEEEE',
    light_white_text: '#FAFAFA',
    tab_bar_color: 'rgb(250,250,250)',

    themeGreen: 'rgb(0,118,22)',
    yellow_text: 'rgb(250,200,0)',
    transparent: '#ffffff00',
    dark_grey: 'rgb(128,128,128)',
    line_color: 'rgb(210,210,210)',
    silverBackground: '#77e319',
    themeYellow: '#6dba2b',
    inactiveTabColor: '#ffffff70',*/


}
