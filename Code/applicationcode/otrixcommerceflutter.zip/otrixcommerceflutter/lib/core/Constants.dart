// ignore: file_names
import 'package:flutter/material.dart';

class Constants {


  // ignore: constant_identifier_names
  static const String login_user_id = "login_user_id";
  static const String firstTime = "first_time";

  // ignore: constant_identifier_names
  static const String user_data = "user_data";
  static const String pushToken = "push_token";
  static const String accessToken = "access_token";
  static const String theme = "theme";
  static const String appTheme = "appTheme";
  static const String appLanguage = "appLanguage";
  static const String cartCount = "cartCount";
  static const String wishList = "wishList";

  // ignore: constant_identifier_names
  static const String something_wrong = "Something wrong please try again";
  static const String exit_warning = "Click again for exit app";


}
