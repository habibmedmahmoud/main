import 'package:ecommerce/core/common.dart';
import 'package:flutter/material.dart';

ThemeData themeData = ThemeData(
    backgroundColor: commonBackgroundColor,
    primaryColor: primaryColor,
    shadowColor: greyTextColor,
    primaryColorLight: white,
    scaffoldBackgroundColor: commonBackgroundColor,
    textTheme: const TextTheme(
      bodyText1: TextStyle(
        color: Colors.black,
      ),
      bodyText2: TextStyle(
        color: greyTextColor,
      ),
      subtitle1: TextStyle(
        color: Colors.black,
      ),
      subtitle2: TextStyle(
        color: greyTextColor,
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
        focusedErrorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(3.0),
          borderSide: const BorderSide(width: 0.5, color: Colors.green),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(3.0),
          borderSide: const BorderSide(color: Colors.red, width: 0.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(3.0),
          borderSide: const BorderSide(width: 0.5, color: Colors.green),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(3.0),
          borderSide: const BorderSide(color: greyTextColor, width: 0.5),
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(3.0),
          borderSide: const BorderSide(color: primaryColor, width: 0.5),
        ),
        iconColor: Colors.black,
        prefixIconColor: Colors.black,
        suffixIconColor: Colors.black,
        labelStyle: const TextStyle(color: Colors.black)),
    hintColor: Colors.black,
    snackBarTheme: const SnackBarThemeData(
      backgroundColor: primaryColor,
    ),
    colorScheme: ColorScheme.fromSwatch().copyWith(
      primary: commonBackgroundColor,
      secondary: assetColor,
      background: Colors.blue,
    ));
