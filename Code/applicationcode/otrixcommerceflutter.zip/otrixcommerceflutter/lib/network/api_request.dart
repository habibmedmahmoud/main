// ignore_for_file: depend_on_referenced_packages, unnecessary_type_check

import 'dart:io';

import 'package:dio/dio.dart';
import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/Constants.dart';
import 'package:ecommerce/models/common_response.dart';
import 'package:ecommerce/network/api_manager.dart';
import 'package:http_parser/http_parser.dart';
import 'package:path/path.dart';

class ApiRequest {
  ApiRequest();

  postCommonApiCall(var data, String url) async {
    var dio = ApiManager().getDio();
    try {
      var response = await dio.post(url, data: data);

      if (response is Response) {
        if (response.data is Map<String, dynamic>) {
          CommonResponse commonResponse =
              CommonResponse.fromJson(response.data);
          if (commonResponse.status! == 1) {
            return response;
          } else {
            AppGlobal.showSnackbar(
                commonResponse.message ?? Constants.something_wrong,
                type: 2);
            return null;
          }
        } else if (response.data is DioError) {
          AppGlobal.showSnackbar(
              response.statusMessage ?? Constants.something_wrong,
              type: 2);
          return null;
        } else {
          AppGlobal.showSnackbar(Constants.something_wrong, type: 2);
          return null;
        }
      } else if (response is DioError) {
        AppGlobal.showSnackbar(
            response.statusMessage ?? Constants.something_wrong,
            type: 2);
        return null;
      } else {
        AppGlobal.showSnackbar(Constants.something_wrong, type: 2);
        return null;
      }
    } catch (ex) {
      AppGlobal.showSnackbar(ex.toString(), type: 2);
      return null;
    }
  }

  getCommonApiCall(String url) async {
    var dio = ApiManager().getDio();

    try {
      var response = await dio.get(url);

      if (response is Response) {
        if (response.data is Map<String, dynamic>) {
          CommonResponse commonResponse =
              CommonResponse.fromJson(response.data);
          if (commonResponse.status! == 1) {
            return response;
          } else {
            AppGlobal.showSnackbar(
                commonResponse.message ?? Constants.something_wrong,
                type: 2);
            return null;
          }
        } else if (response.data is DioError) {
          AppGlobal.showSnackbar(
              response.statusMessage ?? Constants.something_wrong,
              type: 2);
          return null;
        } else {
          AppGlobal.showSnackbar(Constants.something_wrong, type: 2);
          return null;
        }
      } else if (response is DioError) {
        AppGlobal.showSnackbar(
            response.statusMessage ?? Constants.something_wrong,
            type: 2);
        return null;
      } else {
        AppGlobal.showSnackbar(Constants.something_wrong, type: 2);
        return null;
      }
    } catch (ex) {
      AppGlobal.showSnackbar(ex.toString(), type: 2);
      return null;
    }
  }

  uploadProfileImage(File? imageFile, String url) async {
    MultipartFile? image;
    var dio = ApiManager().getDio();

    if (imageFile != null) {
      var endWithData = imageFile.path.split(".");
      MediaType contentTypeIMage =
          MediaType('image', endWithData[endWithData.length - 1].toString());
      if (imageFile.path.endsWith("png")) {
        contentTypeIMage = MediaType('image', 'png');
      } else if (imageFile.path.endsWith("jpeg")) {
        contentTypeIMage = MediaType('image', 'jpeg');
      } else if (imageFile.path.endsWith("jpg")) {
        contentTypeIMage = MediaType('image', 'jpg');
      }

      image = await MultipartFile.fromFile(imageFile.path,
          contentType: contentTypeIMage, filename: basename(imageFile.path));

    }
    var formData = FormData.fromMap({
      "image": image,
    });

    try {
      var response = await dio.post(url, data: formData);

      if (response is Response) {
        if (response.data is Map<String, dynamic>) {
          CommonResponse commonResponse =
              CommonResponse.fromJson(response.data);
          if (commonResponse.status! == 1) {
            return response;
          } else {
            AppGlobal.showSnackbar(
                commonResponse.message ?? Constants.something_wrong,
                type: 2);
            return null;
          }
        } else if (response.data is DioError) {
          AppGlobal.showSnackbar(
              response.statusMessage ?? Constants.something_wrong,
              type: 2);
          return null;
        } else {
          AppGlobal.showSnackbar(Constants.something_wrong, type: 2);
          return null;
        }
      } else if (response is DioError) {
        AppGlobal.showSnackbar(
            response.statusMessage ?? Constants.something_wrong,
            type: 2);
        return null;
      } else {
        AppGlobal.showSnackbar(Constants.something_wrong, type: 2);
        return null;
      }
    } catch (ex) {
      AppGlobal.showSnackbar(ex.toString(), type: 2);
      return null;
    }
  }
}
