import 'package:cookie_jar/cookie_jar.dart';
import 'package:dio/dio.dart';
import 'package:dio_cookie_manager/dio_cookie_manager.dart';

import 'api_services.dart';

class ApiManager {
  static final ApiManager _singleton = ApiManager._internal();

  late Dio dio;

  factory ApiManager() {
    return _singleton;
  }

  ApiManager._internal();

  Future<void> configureDio(String appdocPath) async {
    BaseOptions options = BaseOptions(
        baseUrl: ApiServices.BASE_URL,
        connectTimeout: 50000,
        receiveTimeout: 40000,
        headers: {"token": ApiServices.apiKey});

    dio = Dio(options);

    var cookieJar = PersistCookieJar(
      storage: FileStorage(appdocPath + "/.cookies"),
      ignoreExpires: true,
    );

    dio.interceptors.addAll({
      LogInterceptor(
        request: true,
        responseBody: true,
        error: true,
        requestBody: true,
      ),
      CookieManager(cookieJar),
    });
  }

  Dio getDio() {
    return dio;
  }
}
