class ApiServices {
  static const String BASE_URL = 'https://otrixcommerce.in/api/';
  static const String uploadURL = 'https://otrixcommerce.in/public/uploads/';
  static const String apiKey = 'RuQChqz2FqJkP6wMAQiVlLx5BA6MMB';

  // Document URLS
  static const String uploadCategoryURL = 'category/';
  static const String uploadProductURL = 'product/';
  static const String uploadManufacturerURL = 'manufacturer/';
  static const String uploadBannerURL = 'banner/';
  static const String uploadUserProfileURL = 'user/';

//General end points
  static const String homePage = 'getHomePage';
  static const String productDetail = 'productDetail/';
  static const String getCategories = 'getCategories/';
  static const String getManufacturers = 'getManufacturers';
  static const String getProductByCategory = 'getProductByCategory/';
  static const String getProductByManufacturer = 'getProductByManufacturer/';
  static const String getDODProductsFlutter = 'getDODProductsFlutter';
  static const String getTrendingProducts = 'getTrendingProducts';
  static const String getNewProducts = 'getNewProducts';
  static const String getPages = 'getPages/';
  static const String searchProducts = 'searchProducts?q=';
  static const String checkLogin = 'checkLogin';

//User End points
  static const String   login = 'user/login';
  static const String logout = 'user/logout';
  static const String register = 'user/register';
  static const String getWishlist = 'user/getWishlist';
  static const String addUpdateWishlist = 'user/addUpdateWishlist';
  static const String getAddress = 'user/getAdress';
  static const String addAddress = 'user/addAddress';
  static const String editAddress = 'user/editAddress/';
  static const String changeProfilePicture = 'user/changeProfilePicture';
  static const String updateProfile = 'user/updateProfile';
  static const String changePassword = 'user/changePassword';
  static const String deleteAddress = 'user/deleteAddress/';
  static const String getOrdersList = 'user/getOrdersList?page=';

  // Cart
  static const String addToCart = 'user/addToCart';
  static const String getCart = 'user/getCart';
  static const String applyCoupon = 'user/applyCoupon';
  static const String updateCart = 'user/updateCart';
  static const String deleteCart = 'user/deleteCart';
  static const String getCheckoutData = 'user/getCheckoutData';
  static const String selectShipping = 'user/selectShipping/';
  static const String placeOrder = 'user/placeOrder';
}
