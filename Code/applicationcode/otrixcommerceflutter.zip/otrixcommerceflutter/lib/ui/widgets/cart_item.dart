// ignore_for_file: must_be_immutable

import 'package:cached_network_image/cached_network_image.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/cart/CartData.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

class CartItemWidget extends StatelessWidget {
  CartData cartProductItem;
  VoidCallback? qtyMinus;
  VoidCallback? qtyPlus;
  VoidCallback? openProduct;
  VoidCallback? deleteProduct;

  CartItemWidget(
      {required this.cartProductItem,
      Key? key,
      this.qtyPlus,
      this.qtyMinus,
      this.deleteProduct,
      this.openProduct})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(6.0),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(8),
        child: Container(
          width: double.maxFinite,
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.all(8.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: 100,
                  height: 80,
                  decoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    borderRadius: const BorderRadius.all(Radius.circular(8)),
                    color: Colors.purple[200]!.withOpacity(0.1),
                  ),
                  child: CachedNetworkImage(
                    imageUrl:
                        "${ApiServices.uploadURL}${ApiServices.uploadProductURL}${cartProductItem.image}",
                    // "${ApiServices.uploadURL}${ApiServices.uploadProductURL}${products.image}",
                    placeholder: (context, url) => Container(),
                    errorWidget: (context, url, error) => Container(),
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Expanded(
                            child: InkWell(
                              onTap: () => openProduct!(),
                              child: CustomText(
                                text: "${cartProductItem.name}",
                                color: greyTextColor,
                                family: boldFont,
                                size: 16,
                                maxLines: 1,
                              ),
                            ),
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                          InkWell(
                            onTap: () => deleteProduct!(),
                            child: const Icon(
                              Icons.delete,
                              color: greyTextColor,
                              size: 20,
                            ),
                          ),
                        ],
                      ),
                      CustomText(
                        text: "$currency${cartProductItem.price}",
                        color: primaryColor,
                        family: boldFont,
                        size: 18,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          InkWell(
                              onTap: () => qtyMinus!(),
                              child: const SizedBox(
                                height: 20,
                                child: Icon(
                                  Icons.remove,
                                  color: greyTextColor,
                                  size: 20,
                                ),
                              )),
                          const SizedBox(
                            width: 15,
                          ),
                          CustomText(
                            text: "${cartProductItem.quantity}",
                            color: black,
                            family: mediumFont,
                            size: 14,
                          ),
                          const SizedBox(
                            width: 15,
                          ),
                          InkWell(
                              onTap: () => qtyPlus!(),
                              child: const Icon(
                                Icons.add,
                                color: greyTextColor,
                                size: 20,
                              )),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
