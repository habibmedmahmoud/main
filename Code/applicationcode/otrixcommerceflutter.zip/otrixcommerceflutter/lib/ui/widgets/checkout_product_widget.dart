import 'package:cached_network_image/cached_network_image.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/checkout/OrderSummary.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

class CheckoutProductWidget extends StatelessWidget {
  VoidCallback? openProduct;
  OrderSummary orderSummary;

  CheckoutProductWidget(
      {Key? key, this.openProduct, required this.orderSummary})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(10)),
        color: Colors.white,
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Row(
              children: [
                CachedNetworkImage(
                  imageUrl:
                      "${ApiServices.uploadURL}${ApiServices.uploadProductURL}${orderSummary.image}",
                  height: 70,
                  width: 70,
                  errorWidget: (a, b, c) => Container(),
                ),
                const SizedBox(
                  width: 15,
                ),
                Expanded(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomText(
                      text: '${orderSummary.name}',
                      size: 16,
                      color: greyTextColor,
                      family: boldFont,
                    ),
                    const SizedBox(
                      height: 2,
                    ),
                    CustomText(
                      text: '$currency${orderSummary.price}',
                      size: 16,
                      color: primaryColor,
                      family: mediumFont,
                    ),
                    const SizedBox(
                      height: 2,
                    ),
                    CustomText(
                      text: 'Quantity: ${orderSummary.quantity}',
                      size: 14,
                      color: black,
                      family: regularFont,
                    ),
                  ],
                ))
              ],
            ),
          ),
        ],
      ),
    );
  }
}
