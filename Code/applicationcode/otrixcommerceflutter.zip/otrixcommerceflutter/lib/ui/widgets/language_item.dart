import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class LanguageItemWidget extends StatelessWidget {

  String title;
  VoidCallback onItemClick;
  bool isSelected;

  LanguageItemWidget(
      {Key? key,
        required this.onItemClick,
        required this.isSelected,
        required this.title})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7.0),
      child: ClipRRect(
          borderRadius: BorderRadius.circular(2),
          child: Container(
            width: double.maxFinite,
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.all(const Radius.circular(10)),
              border: isSelected ?  Border.all(color: primaryColor) : const Border()
            ),
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () => onItemClick(),
                child: Padding(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 15, vertical: 20),
                  child: CustomText(
                    text: title,
                    size: 16,
                    family: mediumFont,
                  ),
                ),
              ),
            ),
          )),
    );
  }
}
