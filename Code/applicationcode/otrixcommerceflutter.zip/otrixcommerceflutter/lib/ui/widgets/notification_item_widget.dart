// ignore_for_file: must_be_immutable

import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

class NotificationItemWidget extends StatelessWidget {
  bool isSelected;
  String name;
  Function(bool) onselect;

  NotificationItemWidget(
      {Key? key,
      required this.name,
      required this.isSelected,
      required this.onselect})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(15),
      margin: const EdgeInsets.symmetric(vertical: 5),
      decoration: BoxDecoration(
          color: white,
          borderRadius: const BorderRadius.all(Radius.circular(5)),
          border:
              Border.all(color: greyTextColor.withOpacity(0.3), width: 0.3)),
      child: Row(
        children: [
          SizedBox(
            height: 20,
            width: 20,
            child: Checkbox(
                checkColor: white,
                fillColor: MaterialStateProperty.all<Color>(primaryColor),
                value: isSelected,
                onChanged: (val) => onselect(val ?? false)),
          ),
          const SizedBox(
            width: 15,
          ),
          CustomText(
            text: name,
            family: mediumFont,
            size: 16,
          )
        ],
      ),
    );
  }
}
