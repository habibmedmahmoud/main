import 'package:ecommerce/core/common.dart';
import 'package:flutter/cupertino.dart';


class ProductListLoadingView extends StatelessWidget {
  const ProductListLoadingView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
            mainAxisExtent: 220, crossAxisCount: 2),
        itemBuilder: (context, index) {
          return Container(
            color: white,
            height: 180,
            margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
          );
        },
        itemCount: 100);
  }
}
