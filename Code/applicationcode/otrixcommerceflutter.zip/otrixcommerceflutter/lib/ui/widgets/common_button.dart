import 'package:ecommerce/core/common.dart';
import 'package:flutter/material.dart';

class CommonButton extends StatelessWidget {
  VoidCallback onPressed;
  Widget text;
  Color? buttonColor;
  double? height;
  double? width;
  double? radius;

  CommonButton(
      {Key? key,
      required this.onPressed,
      required this.text,
      this.height,
      this.buttonColor,
      this.width,
      this.radius})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: width ?? double.maxFinite,
      height: height ?? 45,
      child: ElevatedButton(
        onPressed: onPressed,
        style: ElevatedButton.styleFrom(
          primary: buttonColor ?? primaryColor,
          padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 0),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(radius ?? 5),
          ),
        ),
        child: text,
      ),
    );
  }
}
