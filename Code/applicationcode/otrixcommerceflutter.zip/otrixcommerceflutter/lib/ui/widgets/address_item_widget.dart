import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/address/address_model.dart';
import 'package:ecommerce/provider/address_provider.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class AddressItemWidget extends StatelessWidget {
  bool? isDeleteVisible;
  AddressModel addressModel;
  Function? onDelete;
  Function? onEdit;
  bool? isSelected;
  VoidCallback? addressSelection;

  AddressItemWidget(
      {Key? key,
      required this.addressModel,
      this.onDelete,
      this.addressSelection,
      this.onEdit,
      this.isDeleteVisible,
      this.isSelected})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 10.0),
      child: InkWell(
        onTap: addressSelection,
        child: Container(
          decoration: BoxDecoration(
              border: Border.all(
                  color: isSelected == true
                      ? primaryColor
                      : greyTextColor.withOpacity(0.2),
                  width: 0.5),
              color: white,
              borderRadius: const BorderRadius.all(const Radius.circular(10))),
          padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 5.0, vertical: 10),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        text: "${addressModel.name}",
                        color: black,
                        family: regularFont,
                        size: 13,
                      ),
                      CustomText(
                        text: "${addressModel.address1}",
                        color: black,
                        family: regularFont,
                        size: 13,
                      ),
                      CustomText(
                        text: "${addressModel.address2}, ${addressModel.city}",
                        color: black,
                        family: regularFont,
                        size: 13,
                      ),
                      CustomText(
                        text:
                            "${addressModel.postcode} ${addressModel.country}",
                        color: black,
                        family: regularFont,
                        size: 13,
                      ),
                      if (isSelected == true)
                        Row(
                          mainAxisSize: MainAxisSize.max,
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            CustomText(
                              text: "Delivery Address  ",
                              color: primaryColor,
                              family: regularFont,
                              size: 13,
                            ),
                            Image.asset(
                              "assets/images/check.png",
                              height: 15,
                              width: 15,
                            )
                          ],
                        ),
                    ],
                  ),
                ),
                const SizedBox(
                  width: 15,
                ),
                Column(
                  children: [
                    if (isDeleteVisible == true)
                      InkWell(
                        onTap: () {
                          if (onDelete != null) onDelete!();
                        },
                        child: const Icon(
                          Icons.delete,
                          color: Colors.red,
                          size: 20,
                        ),
                      ),
                    const SizedBox(
                      height: 5,
                    ),
                    InkWell(
                      onTap: () {
                        if (onEdit != null) onEdit!();
                      },
                      child: const Icon(
                        Icons.edit,
                        color: black,
                        size: 20,
                      ),
                    )
                  ],
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
