// ignore_for_file: must_be_immutable

import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/checkout_provider.dart';
import 'package:ecommerce/ui/screens/payment_card_screen.dart';
import 'package:ecommerce/ui/widgets/checkout_product_widget.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_form_field.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/payment_metod_item.dart';
import 'package:flutter/material.dart';

class CheckoutPaymentView extends StatefulWidget {
  CheckoutProvider provider;

  CheckoutPaymentView(this.provider, {Key? key}) : super(key: key);

  @override
  State<StatefulWidget> createState() => _CheckoutPaymentViewState(provider);
}

class _CheckoutPaymentViewState extends State<CheckoutPaymentView> {
  TextEditingController commentController = TextEditingController();
  CheckoutProvider provider;

  _CheckoutPaymentViewState(this.provider);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                CustomText(
                  text: "Payment Methods",
                  color: black,
                  family: mediumFont,
                  size: 18,
                ),
                const SizedBox(
                  height: 15,
                ),
                ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemBuilder: (context, index) {
                      return paymentMethodItem(
                        isSelected: index == provider.selectedPaymentMethods,
                        selectPayment: () async {
                          provider.changePaymentMethod(index);
                          if (index == 0 &&
                              Common.paymentMethods[index]['value'] ==
                                  'creditCard') {
                            final result = await Navigator.of(context).push(
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        const PaymentCardScreen()));
                            if (result == "1") {
                              provider.placeOrder(commentController.text.toString().trim());
                            }
                          }
                        },
                      );
                    },
                    separatorBuilder: (context, index) {
                      return const SizedBox(
                        height: 10,
                      );
                    },
                    itemCount: Common.paymentMethods.length),
                const SizedBox(
                  height: 15,
                ),
                CustomText(
                  text: "Order Comments",
                  color: black,
                  family: mediumFont,
                  size: 18,
                ),
                const SizedBox(
                  height: 10,
                ),
                CustomTextFormField(
                  hint: "Enter Order Comments(Optional)",
                  controller: commentController,
                  maxLines: 3,
                ),
                const SizedBox(
                  height: 15,
                ),
                CustomText(
                  text: "Order Summary",
                  color: black,
                  family: mediumFont,
                  size: 18,
                ),
                const SizedBox(
                  height: 5,
                ),
                Container(
                  width: double.maxFinite,
                  height: 0.3,
                  color: greyTextColor,
                ),
                const SizedBox(
                  height: 10,
                ),
                ListView.separated(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    itemBuilder: (context, index) {
                      return CheckoutProductWidget(
                        orderSummary: provider.orderSummaryList[index],
                        openProduct: () {},
                      );
                    },
                    separatorBuilder: (context, index) {
                      return const SizedBox(
                        height: 10,
                      );
                    },
                    itemCount: provider.orderSummaryList.length),
              ],
            ),
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Expanded(
              child: Wrap(
                children: [
                  CustomText(
                    text: "Total : ",
                    size: 20,
                    family: mediumFont,
                  ),
                  CustomText(
                    text: "$currency${provider.grandTotal}",
                    size: 20,
                    color: primaryColor,
                    family: boldFont,
                  ),
                ],
              ),
            ),
            CommonButton(
              onPressed: () {
                if (provider.selectedPaymentMethods == -1) {
                  AppGlobal.showSnackbar("Please select payment method",
                      type: 2);
                }else{
                  provider.placeOrder(commentController.text.toString().trim());
                }
              },
              width: 100,
              buttonColor: Colors.green,
              text: CustomText(
                text: "Place",
                color: white,
                family: mediumFont,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
