import 'package:cached_network_image/cached_network_image.dart';
import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/home_model/ResponseHome.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/ui/screens/login_screen.dart';
import 'package:ecommerce/ui/screens/product_detail_screen.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class HomeProductWidget extends StatelessWidget {
  Products products;
  double itemHeight, itemWidth;
  late bool isNew = false;

  HomeProductWidget(
      {Key? key,
      required this.products,
      required this.itemWidth,
      this.isNew = false,
      required this.itemHeight})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(6.0),
      child: InkWell(
        onTap: () {
          if (products.productDescription != null) {
            Navigator.of(context).push(MaterialPageRoute(
                builder: (BuildContext context) => ProductDetailScreen(
                    productId: products.productDescription!.productId!)));
          }
        },
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Container(
            height: itemHeight,
            color: Colors.white,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Container(
                    color: backgroundColor,
                    child: Stack(
                      children: [
                        Center(
                          child: CachedNetworkImage(
                            imageUrl:
                                "${ApiServices.uploadURL}${ApiServices.uploadProductURL}${products.image}",
                            placeholder: (context, url) =>
                                const CircularProgressIndicator(),
                            errorWidget: (context, url, error) => Container(),
                          ),
                        ),
                        Positioned(
                          top: 5,
                          left: 5,
                          child: !checkStock(products.quantity)
                              ? Card(
                                  color: Colors.red,
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 8.0, vertical: 4),
                                    child: CustomText(
                                      text: 'Out of\nStock',
                                      size: 9,
                                      color: white,
                                      family: mediumFont,
                                    ),
                                  ))
                              : isNew == true
                                  ? Card(
                                      child: Padding(
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 8.0, vertical: 4),
                                      child: CustomText(
                                        text: 'New',
                                        size: 9,
                                        family: mediumFont,
                                      ),
                                    ))
                                  : Container(),
                        ),
                        Positioned(
                          top: 3,
                          right: 3,
                          child: Consumer<HomeProvider>(
                              builder: (context, provider, child) {
                            return InkWell(
                              onTap: () async {
                                if (provider.isUserLoggedIn) {
                                  if (await provider.updateDeleteWishListItem(
                                      products
                                          .productDescription!.productId!)) {
                                    provider.updateWishListItem(products
                                        .productDescription!.productId!);
                                  }
                                } else {
                                  Navigator.of(context).push(MaterialPageRoute(
                                      builder: (BuildContext context) =>
                                          LoginScreen(provider: provider)));
                                }
                              },
                              child: Card(
                                  color: provider.isUserLoggedIn &&
                                          provider.wishListItems.contains(
                                              products.productDescription!
                                                  .productId!)
                                      ? primaryColor
                                      : white,
                                  shape: RoundedRectangleBorder(
                                      borderRadius:
                                          BorderRadius.circular(50.0)),
                                  child: Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 6.0, vertical: 6),
                                    child: Icon(
                                      provider.isUserLoggedIn &&
                                              provider.wishListItems.contains(
                                                  products.productDescription!
                                                      .productId!)
                                          ? Icons.favorite
                                          : Icons.favorite_border,
                                      size: 16,
                                      color: provider.isUserLoggedIn &&
                                              provider.wishListItems.contains(
                                                  products.productDescription!
                                                      .productId!)
                                          ? white
                                          : greyTextColor,
                                    ),
                                  )),
                            );
                          }),
                        ),
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(left: 4.0),
                  child: SizedBox(
                    width: 95,
                    child: RatingBar(
                      itemSize: 18,
                      initialRating: products.reviewAvg != null
                          ? double.parse(products.reviewAvg!)
                          : 0,
                      minRating: 0,
                      direction: Axis.horizontal,
                      itemCount: 5,
                      itemPadding: const EdgeInsets.all(0),
                      wrapAlignment: WrapAlignment.start,
                      updateOnDrag: false,
                      tapOnlyMode: true,
                      ignoreGestures: true,
                      ratingWidget: RatingWidget(
                        full: const Icon(
                          Icons.star_rate_rounded,
                          color: Colors.amber,
                          size: 18,
                        ),
                        half: const Icon(
                          Icons.star_half_rounded,
                          color: Colors.amber,
                          size: 18,
                        ),
                        empty: const Icon(
                          Icons.star_border_rounded,
                          color: greyTextColor,
                          size: 18,
                        ),
                      ),
                      allowHalfRating: true,
                      onRatingUpdate: (rating) => {},
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 3.0, left: 4),
                  child: Text(
                    "${products.productDescription!.name}",
                    maxLines: 1,
                    style: const TextStyle(
                        fontFamily: mediumFont,
                        fontSize: 14,
                        color: greyTextColor),
                  ),
                ),
                products.special != null
                    ? Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 4, vertical: 4),
                        child: Row(
                          children: [
                            Expanded(
                              child: Row(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Padding(
                                    padding: const EdgeInsets.only(top: 2.0),
                                    child: Text(
                                      '$currency${double.parse(products.special!.price ?? "0").toStringAsFixed(2)}',
                                      style: const TextStyle(
                                          fontFamily: boldFont, fontSize: 15),
                                    ),
                                  ),
                                  Text(
                                    '$currency${double.parse(products.price ?? "0").toStringAsFixed(2)}',
                                    style: const TextStyle(
                                        fontFamily: boldFont,
                                        fontSize: 9,
                                        color: greyTextColor,
                                        decoration: TextDecoration.lineThrough),
                                  ),
                                ],
                              ),
                            ),
                            Text(
                              '${AppGlobal.getDiscountCalculation(products.price ?? "0", products.special!.price ?? "0")}%\nOFF',
                              textAlign: TextAlign.center,
                              style: const TextStyle(
                                  fontFamily: mediumFont,
                                  fontSize: 9,
                                  color: primaryColor),
                            ),
                          ],
                        ),
                      )
                    : Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 4, vertical: 4),
                        child: Text(
                          '$currency${products.price!}',
                          style: const TextStyle(
                              fontFamily: boldFont, fontSize: 15),
                        ),
                      ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  bool checkStock(int? quantity) {
    if (quantity != null) {
      try {
        if (quantity > 0) {
          return true;
        }
      } catch (ex) {}
    }
    return false;
  }
}
