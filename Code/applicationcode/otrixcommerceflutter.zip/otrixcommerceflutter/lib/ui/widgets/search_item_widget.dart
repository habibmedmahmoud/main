// ignore_for_file: must_be_immutable

import 'package:cached_network_image/cached_network_image.dart';
import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/home_model/ResponseHome.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

class SearchProductItem extends StatelessWidget {
  VoidCallback? openProduct;
  Products product;

  SearchProductItem({Key? key, required this.product, this.openProduct})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: openProduct,
      child: Container(
        margin: EdgeInsets.all(5),
        decoration: const BoxDecoration(
          borderRadius: BorderRadius.all(Radius.circular(10)),
          color: Colors.white,
        ),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Row(
                children: [
                  Container(
                    height: 70,
                    width: 70,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(5)),
                      color: blackDarkLight.withOpacity(0.1),
                    ),
                    child: product.image != null ? CachedNetworkImage(
                      imageUrl:
                          "${ApiServices.uploadURL}${ApiServices.uploadProductURL}${product.image}",
                      height: 70,
                      width: 70,
                      errorWidget: (a, b, c) => Container(),
                    ) : Container(),
                  ),
                  const SizedBox(
                    width: 15,
                  ),
                  Expanded(
                      child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        text: '${product.productDescription!.name}',
                        size: 16,
                        color: greyTextColor,
                        family: boldFont,
                      ),
                      const SizedBox(
                        height: 2,
                      ),
                      product.special != null
                          ? Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 4, vertical: 4),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding:
                                              const EdgeInsets.only(top: 2.0),
                                          child: Text(
                                            '$currency${double.parse(product.special!.price ?? "0").toStringAsFixed(2)}',
                                            style: const TextStyle(
                                                fontFamily: boldFont,
                                                fontSize: 15),
                                          ),
                                        ),
                                        Text(
                                          '$currency${double.parse(product.price ?? "0").toStringAsFixed(2)}',
                                          style: const TextStyle(
                                              fontFamily: boldFont,
                                              fontSize: 9,
                                              color: greyTextColor,
                                              decoration:
                                                  TextDecoration.lineThrough),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            )
                          : Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 4, vertical: 4),
                              child: Text(
                                '$currency${product.price!}',
                                style: const TextStyle(
                                    fontFamily: boldFont, fontSize: 15),
                              ),
                            ),
                      const SizedBox(
                        height: 2,
                      ),
                      if (product.special != null)
                        Text(
                          '${AppGlobal.getDiscountCalculation(product.price ?? "0", product.special!.price ?? "0")}% OFF',
                          textAlign: TextAlign.center,
                          style: const TextStyle(
                              fontFamily: mediumFont,
                              fontSize: 9,
                              color: primaryColor),
                        ),
                    ],
                  ))
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
