import 'package:cached_network_image/cached_network_image.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/home_model/ResponseHome.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class WishlistItemWidget extends StatelessWidget {
  VoidCallback? itemClick;
  VoidCallback? deleteClick;
  Products productData;

  WishlistItemWidget(
      {Key? key, required this.productData, this.itemClick, this.deleteClick})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(6.0),
      child: InkWell(
        onTap: itemClick,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(8),
          child: Container(
            width: double.maxFinite,
            color: Colors.white,
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    width: 100,
                    height: 80,
                    decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      borderRadius: const BorderRadius.all(Radius.circular(8)),
                      color: Colors.purple[200]!.withOpacity(0.1),
                    ),
                    child: CachedNetworkImage(
                      imageUrl:
                          "${ApiServices.uploadURL}${ApiServices.uploadProductURL}${productData.image}",
                      placeholder: (context, url) =>
                          const CircularProgressIndicator(),
                      errorWidget: (context, url, error) => Container(),
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          width: double.maxFinite,
                          alignment: Alignment.centerRight,
                          child: InkWell(
                            onTap: deleteClick,
                            child: const Icon(
                              Icons.delete,
                              color: greyTextColor,
                              size: 15,
                            ),
                          ),
                        ),
                        CustomText(
                          text: "${productData.productDescription!.name}",
                          color: greyTextColor,
                          family: mediumFont,
                          size: 16,
                          maxLines: 1,
                        ),
                        CustomText(
                          text: "$currency${productData.price}",
                          color: primaryColor,
                          family: mediumFont,
                          size: 16,
                        )
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
