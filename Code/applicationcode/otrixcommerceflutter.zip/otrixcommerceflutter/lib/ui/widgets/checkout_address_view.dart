import 'dart:ui';

import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/address_provider.dart';
import 'package:ecommerce/provider/checkout_provider.dart';
import 'package:ecommerce/ui/screens/add_address_screen.dart';
import 'package:ecommerce/ui/widgets/address_item_widget.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/shipping_method_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CheckoutAddressView extends StatelessWidget {
  CheckoutProvider provider;

  CheckoutAddressView(this.provider, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        CustomText(
          text: "Delivery Address",
          color: black,
          family: mediumFont,
          size: 18,
        ),
        const SizedBox(
          height: 15,
        ),
        SizedBox(
          height: 130,
          // width: double.maxFinite,
          child: ChangeNotifierProvider<AddressProvider>(
            create: (context) => AddressProvider(context),
            child: Consumer<AddressProvider>(
                builder: (context, addressProvider, child) {
              return ListView.builder(
                padding: EdgeInsets.zero,
                scrollDirection: Axis.horizontal,
                shrinkWrap: true,
                itemBuilder: (context, index) {
                  return provider.addressList.length == index
                      ? InkWell(
                          onTap: () async {
                            final result = await Navigator.of(context).push(
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        AddAddressScreen(addressProvider)));
                            if (result == "1") {
                              provider.callGetCheckoutData();
                            }
                          },
                          child: Container(
                            decoration: BoxDecoration(
                                border: Border.all(
                                    color: greyTextColor.withOpacity(0.2),
                                    width: 0.5),
                                color: white,
                                borderRadius: const BorderRadius.all(
                                    Radius.circular(10))),
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10.0, vertical: 5),
                            height: 130,
                            width: 100,
                            child: const Center(
                              child: Icon(
                                Icons.add,
                                size: 30,
                                color: greyTextColor,
                              ),
                            ),
                          ),
                        )
                      : SizedBox(
                          height: 130,
                          width: MediaQuery.of(context).size.width - 70,
                          child: AddressItemWidget(
                              addressModel: provider.addressList[index],
                              onDelete: () {},
                              onEdit: () async {
                                provider.selectNewAddress(provider.addressList[index].id);
                                final result = await Navigator.of(context).push(
                                    MaterialPageRoute(
                                        builder: (BuildContext context) =>
                                            AddAddressScreen(
                                              addressProvider,
                                              addressModel:
                                                  provider.addressList[index],
                                            )));
                                if (result == "1") {
                                  provider.callGetCheckoutData();
                                }
                              },
                              isDeleteVisible: false,
                              addressSelection: () {
                                provider.selectNewAddress(
                                    provider.addressList[index].id);
                              },
                              isSelected: provider.selectedAddressId ==
                                  provider.addressList[index].id),
                        );
                },
                itemCount: provider.addressList.length + 1,
                /*separatorBuilder: (BuildContext context, int index) {
                              return const SizedBox(
                                width: 10,
                              );
                            },*/
              );
            }),
          ),
        ),
        const SizedBox(
          height: 15,
        ),
        CustomText(
          text: "Shipping Methods",
          color: black,
          family: mediumFont,
          size: 18,
        ),
        const SizedBox(
          height: 15,
        ),
        Expanded(
          child: GridView.builder(
              shrinkWrap: true,
              gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                mainAxisExtent: MediaQuery.of(context).size.width / 2 > 160
                    ? 160
                    : MediaQuery.of(context).size.width / 2,
                maxCrossAxisExtent: MediaQuery.of(context).size.width / 2 > 220
                    ? 220
                    : MediaQuery.of(context).size.width / 2,
              ),
              itemBuilder: (context, index) {
                return ShippingMethodWidget(
                  isSelected: provider.selectedShippingMethod ==
                      provider.shippingMethodsList[index],
                  shippingMethod: provider.shippingMethodsList[index],
                  selectShippingMethod: () {
                    provider.selectNewShippingMethod(
                        provider.shippingMethodsList[index]);
                  },
                );
              },
              itemCount: provider.shippingMethodsList.length),
        ),
        const SizedBox(
          height: 15,
        ),
        Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            CommonButton(
              onPressed: () {
                if(provider.selectedAddressId == null ){
                  AppGlobal.showSnackbar("Please add Address and select",type: 2);
                }
                else if(provider.selectedShippingMethod == null ){
                  AppGlobal.showSnackbar("Please select shipping method",type: 2);
                }else{
                  provider.changeView(1);
                }

              },
              width: 130,
              text: CustomText(
                text: "Proceed To Pay",
                color: white,
                family: mediumFont,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
