import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/checkout/ShippingMethods.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

class ShippingMethodWidget extends StatelessWidget {
  bool? isSelected;
  ShippingMethods shippingMethod;
  VoidCallback selectShippingMethod;

  ShippingMethodWidget(
      {Key? key,
      this.isSelected,
      required this.selectShippingMethod,
      required this.shippingMethod})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: InkWell(
          onTap: selectShippingMethod,
          child: Container(
            decoration: BoxDecoration(
                border: Border.all(
                    color: isSelected == true
                        ? primaryColor
                        : greyTextColor.withOpacity(0.2),
                    width: 0.5),
                color: white,
                borderRadius: const BorderRadius.all(Radius.circular(10))),
            padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5),
            child: Stack(
              children: [
                Column(
                  children: [
                    Expanded(
                      child: Center(
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: Image.asset(
                            "assets/images/shipping_fast.png",
                            color:
                                primaryColor, /*
                        height: 100,
                        width: 100,*/
                          ),
                        ),
                      ),
                    ),
                    CustomText(
                      text: "${shippingMethod.name}",
                      align: TextAlign.center,
                      size: 14,
                      family: mediumFont,
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Wrap(
                      children: [
                        CustomText(
                          text: "Charges : ",
                          size: 14,
                          family: mediumFont,
                        ),
                        CustomText(
                          text: "$currency${shippingMethod.shippingCharge}",
                          size: 14,
                          color: primaryColor,
                          family: boldFont,
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 10,
                    )
                  ],
                ),
                if (isSelected == true)
                  Positioned(
                      top: 10,
                      right: 0,
                      child: Image.asset(
                        "assets/images/check.png",
                        height: 20,
                        width: 20,
                      ))
              ],
            ),
          )),
    );
  }
}
