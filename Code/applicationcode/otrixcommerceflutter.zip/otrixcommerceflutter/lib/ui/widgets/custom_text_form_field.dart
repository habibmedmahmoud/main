import 'package:ecommerce/core/common.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class CustomTextFormField extends StatelessWidget {
  TextEditingController? controller;
  String? hint;
  Color? textColor;
  Function(String)? onChange;
  Function(String)? onSubmit;
  String? Function(String?)? validator;
  TextInputAction? textInputAction;
  FocusNode? focusNode;
  bool? obsecure;
  bool? showBottomBorder;
  int? maxLength;
  int? maxLines;
  bool? readOnly;
  TextInputType? textInputType;
  bool? isPassword;
  VoidCallback? onvisibilityChange;

  CustomTextFormField(
      {Key? key,
      this.controller,
      this.hint,
      this.textColor,
      this.onChange,
      this.onSubmit,
      this.textInputAction,
      this.showBottomBorder,
      this.obsecure,
      this.maxLength,
      this.maxLines,
      this.textInputType,
      this.validator,
      this.readOnly,
      this.isPassword = false,
      this.onvisibilityChange,
      this.focusNode})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      // height: (maxLines ?? 1) * 45.0,
      margin: const EdgeInsets.symmetric(vertical: 5),
      child: Center(
        child: TextFormField(
          controller: controller ?? TextEditingController(),
          style: TextStyle(
              color: textColor ?? blackDarkLight,
              fontSize: 14,
              fontFamily: mediumFont),
          maxLines: maxLines ?? 1,
          maxLength: maxLength ?? 500,
          readOnly: readOnly ?? false,
          keyboardType: textInputType ?? TextInputType.text,
          obscureText: obsecure ?? false,
          enabled: readOnly != null ? !readOnly! : true,
          textInputAction: textInputAction ?? TextInputAction.next,
          decoration: InputDecoration(
            contentPadding:
                const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
            hintText: hint ?? 'Enter text',
            counterText: "",
            fillColor: white,
            filled: true,
            suffixIconConstraints: const BoxConstraints(
              maxHeight: 22,
              maxWidth: 30,
            ),
            hintStyle: const TextStyle(
                color: Colors.black26, fontSize: 14, fontFamily: mediumFont),
            isDense: true,
            errorStyle: const TextStyle(
              height: 0.3,
              fontSize: 10,
            ),
            suffixIcon: isPassword!
                ? Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: GestureDetector(
                        onTap: () {
                          onvisibilityChange!();
                        },
                        child: obsecure!
                            ? const Icon(
                                Icons.remove_red_eye,
                                size: 20,
                              )
                            : const Icon(
                                Icons.visibility_off,
                                size: 20,
                              )),
                  )
                : null,
          ),
          onChanged: onChange,
          // focusNode: focusNode ?? FocusNode(),
          onFieldSubmitted: onSubmit,
          validator: validator,
        ),
      ),
    );
  }
}
