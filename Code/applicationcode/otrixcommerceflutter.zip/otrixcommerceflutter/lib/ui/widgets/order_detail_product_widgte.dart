import 'package:cached_network_image/cached_network_image.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/order/order_product.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

class OrderDetailProductWidget extends StatelessWidget {
  VoidCallback? onRateClick;
  OrderProduct orderProduct;
    OrderDetailProductWidget(this.orderProduct, {Key? key, this.onRateClick}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(10)),
        color: Colors.white,
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Row(
              children: [
                CachedNetworkImage(
                  imageUrl: "${ApiServices.uploadURL}${ApiServices.uploadProductURL}${orderProduct.image}",
                  height: 70,
                  width: 70,
                  errorWidget: (contetx, url, abc)=>Container(),
                ),
                const SizedBox(
                  width: 15,
                ),
                Expanded(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          flex: 2,
                          child: CustomText(
                            text: '${orderProduct.name}',
                            size: 14,
                            color: black,
                            family: mediumFont,
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Expanded(
                          flex: 1,
                          child: CustomText(
                            text: orderProduct.total == null ? "" : '$currency${double.parse(orderProduct.total!).toStringAsFixed(2)}',
                            size: 16,
                            color: primaryColor,
                            family: mediumFont,
                          ),
                        ),
                      ],
                    ),
                    CustomText(
                      text: 'Quantity ${orderProduct.quantity}',
                      size: 14,
                      color: greyTextColor,
                      family: regularFont,
                    ),
                  ],
                ))
              ],
            ),
          ),
          const Divider(),
          InkWell(
            onTap: onRateClick,
            child: Material(
              color: Colors.transparent,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8),
                child: Row(
                  mainAxisSize: MainAxisSize.max,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomText(
                      text: 'Rate This Product',
                      color: greyTextColor,
                    ),
                    const SizedBox(
                      width: 5,
                    ),
                    const Icon(
                      Icons.navigate_next,
                      color: primaryColor,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
