import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class SettingItemWidget extends StatelessWidget {
  IconData iconImage;
  String title;
  VoidCallback onItemClick;

  SettingItemWidget(
      {Key? key,
      required this.iconImage,
      required this.onItemClick,
      required this.title})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 7.0),
      child: ClipRRect(
          borderRadius: BorderRadius.circular(2),
          child: Container(
            color: Colors.white,
            child: Material(
              color: Colors.transparent,
              child: InkWell(
                onTap: () => onItemClick(),
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 15, vertical: 20),
                  child: Row(
                    children: [
                      Icon(
                        iconImage,
                        color: greyTextColor,
                        size: 22,
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      Expanded(
                          child: CustomText(
                        text: title,
                        size: 16,
                        family: mediumFont,
                      )),
                      const SizedBox(
                        width: 15,
                      ),
                      const Icon(
                        Icons.navigate_next,
                        size: 20,
                        color: greyTextColor,
                      )
                    ],
                  ),
                ),
              ),
            ),
          )),
    );
  }
}
