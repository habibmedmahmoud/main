
import 'package:ecommerce/core/common.dart';
import 'package:flutter/material.dart';

class CheckoutCustomPaint extends CustomPainter {
  Color selectedColor;

  CheckoutCustomPaint(this.selectedColor);

  @override
  void paint(Canvas canvas, Size size) {
    // Draw Border


    var paint = Paint()
      ..style = PaintingStyle.fill
      ..color = white;

    var path = Path();

    path.moveTo(0.0, 0.0);
    path.lineTo(0.0, size.height);
    path.lineTo(size.width - 15, size.height);
    path.lineTo(size.width, size.height / 2);
    path.lineTo(size.width - 15, 0.0);

    canvas.drawPath(path, paint);

    final paintOrange = Paint()
      ..color = selectedColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;

    canvas.drawLine(
        const Offset(0.0, 0.0), Offset(0.0, size.height), paintOrange);
    canvas.drawLine(Offset(0.0, size.height),
        Offset(size.width - 15, size.height), paintOrange);
    canvas.drawLine(Offset(size.width - 15, size.height),
        Offset(size.width, size.height / 2), paintOrange);
    canvas.drawLine(Offset(size.width, size.height / 2),
        Offset(size.width - 15, 0.0), paintOrange);
    canvas.drawLine(
        Offset(size.width - 15, 0.0), const Offset(0.0, 0.0), paintOrange);

    //Fill Color

  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) {
    return true;
  }
}