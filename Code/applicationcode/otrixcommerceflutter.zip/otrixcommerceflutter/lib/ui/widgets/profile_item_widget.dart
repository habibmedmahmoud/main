import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ProfileItemWidget extends StatelessWidget {
  IconData iconImage;
  String title;
  VoidCallback onItemClick;

  ProfileItemWidget(
      {Key? key,
        required this.iconImage,
        required this.onItemClick,
        required this.title})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3.0),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => onItemClick(),
          child: Padding(
            padding:
            const EdgeInsets.symmetric(horizontal: 5, vertical: 12.0),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Icon(
                  iconImage,
                  color: greyTextColor,
                  size: 22,
                ),
                const SizedBox(
                  width: 20,
                ),
                Expanded(
                    child: CustomText(
                      text: title,
                      size: 16,
                      family: mediumFont,
                    )),
                const SizedBox(
                  width: 15,
                ),
                const Icon(
                  Icons.navigate_next,
                  size: 20,
                  color: greyTextColor,
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
