import 'package:cached_network_image/cached_network_image.dart';
import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/order/order_item_data.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/ui/screens/order_detail_screen.dart';
import 'package:ecommerce/ui/screens/product_detail_screen.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

class OrderItemWidget extends StatelessWidget {
  OrderItem orderItem;

  OrderItemWidget({
    Key? key,
    required this.orderItem,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.all(Radius.circular(10)),
        color: Colors.white,
      ),
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(10.0),
            child: Row(
              children: [
                CachedNetworkImage(
                  imageUrl:
                      "${ApiServices.uploadURL}${ApiServices.uploadProductURL}${orderItem.products!.first.image}",
                  height: 70,
                  width: 70,
                ),
                const SizedBox(
                  width: 15,
                ),
                Expanded(
                    child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomText(
                      text: orderItem.products!.first.name!,
                      size: 14,
                      color: black,
                      family: boldFont,
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    CustomText(
                      text:
                          'Order On ${AppGlobal.formatDate(orderItem.orderDate!)}',
                      size: 14,
                      color: greyTextColor,
                      family: regularFont,
                    ),
                    const SizedBox(
                      height: 5,
                    ),
                    Wrap(
                      children: [
                        CustomText(
                          text: 'Order Status',
                          size: 14,
                          color: greyTextColor,
                          family: regularFont,
                        ),
                        CustomText(
                          text: ' ${orderItem.orderStatus!.name ?? ""}',
                          size: 14,
                          color: black,
                          family: boldFont,
                        ),
                      ],
                    ),
                  ],
                ))
              ],
            ),
          ),
          const Divider(),
          InkWell(
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (BuildContext context) => ProductDetailScreen(
                      productId: orderItem.products!.first.productId!)));
            },
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8),
              child: Row(
                children: [
                  Expanded(
                    child: CustomText(
                      text: 'Buy it Again',
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  const Icon(Icons.navigate_next),
                ],
              ),
            ),
          ),
          const Divider(),
          InkWell(
            onTap: () {
              Navigator.of(context).push(MaterialPageRoute(
                  builder: (BuildContext context) =>
                        OrderDetailScreen(orderItem: orderItem,)));
            },
            child: Material(
              color: Colors.transparent,
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10.0, vertical: 8),
                child: Row(
                  children: [
                    Expanded(
                      child: CustomText(
                        text: 'Order Details',
                      ),
                    ),
                    const SizedBox(
                      width: 10,
                    ),
                    const Icon(Icons.navigate_next),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
