import 'package:cached_network_image/cached_network_image.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/Category.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/ui/screens/product_list_screen.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class CatPageItem extends StatelessWidget {
  final Categories deals;
  double itemHeight, itemWidth;

  CatPageItem(
      {Key? key,
      required this.deals,
      required this.itemWidth,
      required this.itemHeight})
      : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(6.0),
      child: InkWell(
        onTap: () {
          Navigator.of(context).push(MaterialPageRoute(
              builder: (BuildContext context) => ProductListScreen(
                isPagination: true,
                url: ApiServices.getProductByCategory +
                    deals.categoryId!.toString(),
                showFilter: true,
                title: "${deals.categoryDescription!.name}",
              )));
        },
        child: Card(
          shape: RoundedRectangleBorder(
            side: const BorderSide(color: Colors.white70, width: 1),
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Center(
                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        borderRadius:
                            const BorderRadius.all(Radius.circular(8)),
                        color: Colors.purple[100]!.withOpacity(0.2),
                      ),
                      child: CachedNetworkImage(
                        imageUrl:
                        "${ApiServices.uploadURL}${ApiServices.uploadCategoryURL}${deals.image}",
                        placeholder: (context, url) => Container(
                          color: grey,
                        ),
                        errorWidget: (context, url, error) => Icon(Icons.error),
                      ),
                    ),
                  ),
                ),
              ),
              Center(
                child: Padding(
                  padding: const EdgeInsets.only(top: 3.0, left: 4, bottom: 10),
                  child: Text(
                    "${deals.categoryDescription!.name}",
                    maxLines: 1,
                    style: const TextStyle(
                        fontFamily: mediumFont,
                        fontSize: 14,
                        color: greyTextColor),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
