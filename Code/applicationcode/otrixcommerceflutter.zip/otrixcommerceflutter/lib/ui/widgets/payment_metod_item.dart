import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_vector_icons/flutter_vector_icons.dart';

class paymentMethodItem extends StatelessWidget {
    bool? isSelected;
    VoidCallback? selectPayment;
    paymentMethodItem({Key? key, this.isSelected, this.selectPayment}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: selectPayment,
      child: Container(
        width: double.maxFinite,
        color: isSelected == true ? primaryColor : white,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 15),
          child: Row(
            children: [
              Expanded(
                child: CustomText(
                  text: "Credit/ Debit/ ATM Card",
                  color: isSelected == true ? white : black,
                  family: mediumFont,
                  size: 16,
                ),
              ),
              const SizedBox(
                width: 10,
              ),
              Icon(
                isSelected == true
                    ? Ionicons.md_shield_checkmark
                    : Ionicons.radio_button_off,
                color: isSelected == true ? white : black,
              )
            ],
          ),
        ),
      ),
    );
  }
}
