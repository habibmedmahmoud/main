import 'package:flutter/cupertino.dart';

import 'package:ecommerce/core/common.dart';

class HomeLoadingView extends StatelessWidget {
  const HomeLoadingView({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Column(
      //mainAxisSize: MainAxisSize.min,
      children: [
        const SizedBox(
          height: 15,
        ),
        Container(
          height: 45,
          margin: const EdgeInsets.symmetric(horizontal: 3),
          width: double.maxFinite,
          color: white,
        ),
        const SizedBox(
          height: 25,
        ),
        SizedBox(
          height: 50,
          child: ListView.separated(
            itemBuilder: (context, index) {
              return Container(
                width: 50,
                height: 50,
                color: white,
              );
            },
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: 15,
            separatorBuilder: (BuildContext context, int index) {
              return const SizedBox(
                width: 7,
              );
            },
          ),
        ),
        const SizedBox(
          height: 25,
        ),
        Container(
          height: 170,
          margin: const EdgeInsets.symmetric(horizontal: 5),
          width: double.maxFinite,
          color: white,
        ),
        const SizedBox(
          height: 35,
        ),
        Row(
          children: [
            Container(
              height: 25,
              margin: const EdgeInsets.symmetric(horizontal: 15),
              width: 150,
              color: white,
            ),
            const Spacer(),
            Container(
              height: 25,
              margin: const EdgeInsets.symmetric(horizontal: 15),
              width: 100,
              color: white,
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                mainAxisExtent: 220, crossAxisCount: 2),
            itemBuilder: (context, index) {
              return Container(
                color: white,
                height: 180,
                margin: const EdgeInsets.symmetric(horizontal: 6, vertical: 6),
              );
            },
            itemCount: 10),
      ],
    );
  }
}
