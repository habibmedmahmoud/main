import 'package:ecommerce/core/common.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class CustomText extends StatelessWidget {
  String text;
  Color? color;
  String? family;
  double? size;
  FontWeight? weight;
  TextAlign? align;
  int? maxLines;

  CustomText(
      {required this.text,
      this.family,
      this.color,
      this.size,
      this.maxLines,
      this.weight,
      this.align});

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Text(
      text,
      textAlign: align ?? TextAlign.left,
      maxLines: maxLines ?? 1000,
      style: TextStyle(
          color: color ?? black,
          fontSize: size ?? 14,
          fontWeight: weight ?? FontWeight.w500,
          fontFamily: family ?? regularFont),
    );
  }
}
