import 'package:ecommerce/core/AppGlobal.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/BrandsResponse.dart';
import 'package:ecommerce/models/Category.dart';
import 'package:ecommerce/models/home_model/ResponseHome.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/provider/dashboard_provider.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/ui/screens/brand_screen.dart';
import 'package:ecommerce/ui/screens/product_list_screen.dart';
import 'package:ecommerce/ui/screens/search_screen.dart';
import 'package:ecommerce/ui/screens/wishlist_screen.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/home_loading_view.dart';
import 'package:ecommerce/ui/widgets/product_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:shimmer/shimmer.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  double itemWidth = 0;

  @override
  Widget build(BuildContext context) {
    itemWidth = (MediaQuery.of(context).size.width / 2);
    return Scaffold(
      appBar: null,
      body: Consumer<HomeProvider>(builder: (context, userHome, child) {
        return Padding(
          padding:
              const EdgeInsets.only(left: 15.0, right: 15, top: 15, bottom: 5),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 15),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: () {
                        Provider.of<DashboardProvider>(context, listen: false)
                            .changeViewNotifier(DashboardScreenView.PROFILE);
                      },
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(18.0),
                        child: userHome.userData != null
                            ? userHome.userData!.image != null
                                ? CachedNetworkImage(
                                    imageUrl:
                                        "${ApiServices.uploadURL}${ApiServices.uploadUserProfileURL}${userHome.userData!.image}",
                                    placeholder: (context, url) => Image.asset(
                                      "assets/images/man.jpg",
                                      height: 35,
                                    ),
                                    errorWidget: (context, url, error) =>
                                        Image.asset(
                                      "assets/images/man.jpg",
                                      height: 35,
                                    ),
                                    imageBuilder: (context, imageProvider) =>
                                        Container(
                                      width: 35.0,
                                      height: 35.0,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        image: DecorationImage(
                                            image: imageProvider,
                                            fit: BoxFit.cover),
                                      ),
                                    ),
                                  )
                                : Image.asset(
                                    "assets/images/man.jpg",
                                    height: 35,
                                  )
                            : Image.asset(
                                "assets/images/man.jpg",
                                height: 35,
                              ),
                      ),
                    ),
                    Expanded(
                      child: Center(
                        child: CustomText(
                          text: 'Otrixweb',
                          color: primaryColor,
                          family: boldFont,
                          size: 24,
                        ),
                      ),
                    ),
                    if (userHome.isHomeDataLoaded)
                      InkWell(
                        onTap: () {
                          //  if (userHome.isUserLoggedIn) {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  const WishlistScreen()));
                          // }
                        },
                        child: Stack(
                          children: [
                            Padding(
                              padding: const EdgeInsets.all(8.0),
                              child: Image.asset(
                                "assets/images/heart.png",
                                color: Colors.red,
                                height: 25,
                                width: 25,
                              ),
                            ),
                            if (userHome.wishListItems.isNotEmpty)
                              Positioned(
                                right: 0,
                                top: 0,
                                child: Container(
                                  decoration: const BoxDecoration(
                                      color: primaryColor,
                                      shape: BoxShape.circle,
                                      boxShadow: [
                                        BoxShadow(
                                          color: Colors.grey,
                                          blurRadius: 1.0,
                                        ),
                                      ]),
                                  child: Padding(
                                    padding: const EdgeInsets.all(6.0),
                                    child: CustomText(
                                      text:
                                          "${userHome.wishListItems.length < 100 ? userHome.wishListItems.length : "99+"}",
                                      color: white,
                                      size: 8,
                                    ),
                                  ),
                                ),
                              ),
                          ],
                        ),
                      )
                  ],
                ),
              ),
              Expanded(
                child: userHome.isHomeDataLoaded
                    ? SingleChildScrollView(
                        child: mainView(userHome),
                      )
                    : Shimmer.fromColors(
                        baseColor: Colors.grey[300]!,
                        highlightColor: Colors.grey[100]!,
                        // enabled: _enabled,
                        child: const SingleChildScrollView(
                          physics: NeverScrollableScrollPhysics(),
                          child: HomeLoadingView(),
                        ),
                      ),
              ),
            ],
          ),
        );
      }),
    );
  }

  Widget mainView(HomeProvider userHome) {
    return Column(
      //mainAxisSize: MainAxisSize.min,
      children: [
        createSearchFormField(),
        const SizedBox(
          height: 35,
        ),
        if (userHome.categories.isNotEmpty)
          Row(
            children: [
              CustomText(
                text: "Top Categories",
                color: black,
                size: 16,
                family: mediumFont,
              ),
              const Spacer(),
              GestureDetector(
                onTap: () =>
                    Provider.of<DashboardProvider>(context, listen: false)
                        .changeViewNotifier(DashboardScreenView.CATEGORIES),
                child: CustomText(
                  text: "VIEW ALL",
                  color: primaryColor,
                  size: 14,
                  family: mediumFont,
                ),
              ),
            ],
          ),
        if (userHome.categories.isNotEmpty)
          const SizedBox(
            height: 15,
          ),
        if (userHome.categories.isNotEmpty)
          SizedBox(
            height: 90,
            child: ListView.separated(
              itemBuilder: (BuildContext context, int index) =>
                  categoryItemsView(context, userHome.categories[index]),
              shrinkWrap: true,
              scrollDirection: Axis.horizontal,
              itemCount: userHome.categories.length,
              separatorBuilder: (BuildContext context, int index) {
                return const SizedBox(
                  width: 7,
                );
              },
            ),
          ),
        const SizedBox(
          height: 25,
        ),
        if (userHome.banners != null)
          SizedBox(
              height: 170,
              width: double.maxFinite,
              child: SliderBannersList(userHome.banners!)),
        const SizedBox(
          height: 35,
        ),
        Row(
          children: [
            CustomText(
              text: "New Product",
              color: black,
              size: 16,
              family: mediumFont,
            ),
            const Spacer(),
            GestureDetector(
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (BuildContext context) => ProductListScreen(
                        isPagination: false,
                        url: ApiServices.getNewProducts,
                        showFilter: false,
                        title: "New Product",
                      ))),
              child: CustomText(
                text: "VIEW ALL",
                color: primaryColor,
                size: 14,
                family: mediumFont,
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                mainAxisExtent: 220, crossAxisCount: 2),
            itemBuilder: (context, index) {
              return HomeProductWidget(
                products: userHome.newProducts[index],
                itemHeight: 180,
                isNew: true,
                itemWidth: itemWidth,
              );
            },
            itemCount: userHome.newProducts.length),
        const SizedBox(
          height: 35,
        ),
        Row(
          children: [
            CustomText(
              text: "Shop By Brands",
              color: black,
              size: 16,
              family: mediumFont,
            ),
            const Spacer(),
            GestureDetector(
              onTap: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => const BrandScreen()));
              },
              child: CustomText(
                text: "VIEW ALL",
                color: primaryColor,
                size: 14,
                family: mediumFont,
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 20,
        ),
        SizedBox(
          height: 70,
          child: ListView.separated(
            itemBuilder: (BuildContext context, int index) => brandsItemsView(
                context, index, userHome.manufacturersList[index]),
            shrinkWrap: true,
            scrollDirection: Axis.horizontal,
            itemCount: userHome.manufacturersList.length,
            separatorBuilder: (BuildContext context, int index) {
              return const SizedBox(
                width: 7,
              );
            },
          ),
        ),
        const SizedBox(
          height: 35,
        ),
        Row(
          children: [
            CustomText(
              text: "Deals of the Day",
              color: black,
              size: 16,
              family: mediumFont,
            ),
            const Spacer(),
            GestureDetector(
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (BuildContext context) => ProductListScreen(
                        isPagination: false,
                        url: ApiServices.getDODProductsFlutter,
                        showFilter: false,
                        title: "Deals of the Day",
                      ))),
              child: CustomText(
                text: "VIEW ALL",
                color: primaryColor,
                size: 14,
                family: mediumFont,
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                mainAxisExtent: 220, crossAxisCount: 2),
            itemBuilder: (context, index) {
              return HomeProductWidget(
                products: userHome.dodProducts[index],
                itemHeight: 180,
                itemWidth: itemWidth,
              );
            },
            itemCount: userHome.dodProducts.length),
        const SizedBox(
          height: 20,
        ),
        Image.asset("assets/images/banner2.jpg"),
        const SizedBox(
          height: 35,
        ),
        Row(
          children: [
            CustomText(
              text: "Trending Products",
              color: black,
              size: 16,
              family: mediumFont,
            ),
            const Spacer(),
            GestureDetector(
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (BuildContext context) => ProductListScreen(
                        isPagination: false,
                        url: ApiServices.getTrendingProducts,
                        showFilter: false,
                        title: "Trending Products",
                      ))),
              child: CustomText(
                text: "VIEW ALL",
                color: primaryColor,
                size: 14,
                family: mediumFont,
              ),
            ),
          ],
        ),
        const SizedBox(
          height: 10,
        ),
        GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                mainAxisExtent: 220, crossAxisCount: 2),
            itemBuilder: (context, index) {
              return HomeProductWidget(
                products: userHome.trendingProducts[index],
                itemHeight: 180,
                itemWidth: itemWidth,
              );
            },
            itemCount: userHome.trendingProducts.length),
      ],
    );
  }

  createSearchFormField() {
    return SizedBox(
      height: 45.0,
      child: Center(
        child: TextFormField(
          readOnly: true,
          onTap: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (BuildContext context) => const SearchScreen())),
          decoration: const InputDecoration(
              contentPadding:
                  EdgeInsets.symmetric(vertical: 10.0, horizontal: 0.0),
              hintText: 'Search Product',
              counterText: "",
              fillColor: backgroundColor,
              filled: true,
              hintStyle: TextStyle(
                  color: Colors.black26, fontSize: 14, fontFamily: regularFont),
              prefixIcon: Icon(
                Icons.search_sharp,
                size: 20,
                color: Colors.black26,
              ),
              isDense: true,
              border: InputBorder.none,
              focusedBorder: InputBorder.none,
              enabledBorder: InputBorder.none,
              disabledBorder: InputBorder.none),
        ),
      ),
    );
  }

  Widget SliderBannersList(Banners banners) {
    return CarouselSlider(
        options: CarouselOptions(
          aspectRatio: 1,
          viewportFraction: 0.85,
          initialPage: 0,
          enableInfiniteScroll: true,
          reverse: false,
          autoPlay: true,
          autoPlayInterval: const Duration(seconds: 4),
          autoPlayAnimationDuration: const Duration(milliseconds: 1000),
          autoPlayCurve: Curves.fastOutSlowIn,
          enlargeCenterPage: true,
          // onPageChanged: callbackFunction,
          scrollDirection: Axis.horizontal,
        ),
        items: banners.images
            ?.map((item) => CachedNetworkImage(
                  imageUrl:
                      '${ApiServices.uploadURL}${ApiServices.uploadBannerURL}${item.image}',
                  imageBuilder: (context, imageProvider) => Container(
                    width: double.maxFinite,
                    height: 200.0,
                    decoration: BoxDecoration(
                      shape: BoxShape.rectangle,
                      borderRadius: const BorderRadius.all(Radius.circular(10)),
                      image: DecorationImage(
                          image: imageProvider, fit: BoxFit.cover),
                    ),
                  ),
                  placeholder: (context, url) => Container(
                    color: grey,
                  ),
                  errorWidget: (context, url, error) => const Icon(Icons.error),
                ))
            .toList());
  }

  Widget categoryItemsView(BuildContext context, Categories category) {
    return GestureDetector(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
          builder: (BuildContext context) => ProductListScreen(
                isPagination: true,
                url: ApiServices.getProductByCategory +
                    category.categoryId!.toString(),
                showFilter: true,
                title: "${category.categoryDescription!.name}",
              ))),
      child: SizedBox(
        width: 70,
        child: Column(
          children: [
            Container(
              decoration: BoxDecoration(
                shape: BoxShape.rectangle,
                borderRadius: const BorderRadius.all(Radius.circular(8)),
                color: Colors.purple[200]!.withOpacity(0.1),
              ),
              child: CachedNetworkImage(
                imageUrl:
                    "${ApiServices.uploadURL}${ApiServices.uploadCategoryURL}${category.image}",
                placeholder: (context, url) => Container(
                  color: grey,
                ),
                imageBuilder: (context, imageProvider) => Container(
                  width: 60.0,
                  height: 50.0,
                  decoration: BoxDecoration(
                    shape: BoxShape.rectangle,
                    borderRadius: const BorderRadius.all(Radius.circular(8)),
                    image:
                        DecorationImage(image: imageProvider, fit: BoxFit.fill),
                  ),
                ),
                errorWidget: (context, url, error) => const Icon(Icons.error),
                height: 50,
                width: 60,
              ),
            ),
            Text(
              "${category.categoryDescription!.name}",
              maxLines: 2,
              textAlign: TextAlign.center,
              style: const TextStyle(
                fontSize: 12,
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget brandsItemsView(BuildContext context, int index, BrandsData data) {
    return GestureDetector(
      onTap: () => Navigator.of(context).push(MaterialPageRoute(
          builder: (BuildContext context) => ProductListScreen(
                isPagination: true,
                url: ApiServices.getProductByManufacturer + data.id!.toString(),
                showFilter: true,
                title: "${data.name}",
              ))),
      child: SizedBox(
        width: 70,
        child: Column(
          children: [
            Container(
              width: 70,
              height: 50,
              color: backgroundColor,
              padding: const EdgeInsets.all(8.0),
              child: CachedNetworkImage(
                imageUrl:
                    "${ApiServices.uploadURL}${ApiServices.uploadManufacturerURL}${data.image}",
                placeholder: (context, url) => Container(
                  color: grey,
                ),
                errorWidget: (context, url, error) => Container(),
                height: 50,
                width: 70,
              ),

              /*decoration: BoxDecoration(
                borderRadius: BorderRadius.all(Radius.circular(10))
              ),*/
            ),
            Text(
              "${data.name}",
              maxLines: 1,
            )
          ],
        ),
      ),
    );
  }
}
