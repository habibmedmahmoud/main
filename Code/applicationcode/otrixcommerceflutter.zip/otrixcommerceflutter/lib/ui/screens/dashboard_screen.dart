import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/dashboard_provider.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/ui/screens/cart_screen.dart';
import 'package:ecommerce/ui/screens/category_screen.dart';
import 'package:ecommerce/ui/screens/home_screen.dart';
import 'package:ecommerce/ui/screens/profile_screen.dart';
import 'package:ecommerce/ui/screens/register_screen.dart';
import 'package:ecommerce/ui/screens/setting_screen.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Widget currentScreen = const HomeScreen();

  @override
  void initState() {
    Provider.of<HomeProvider>(context, listen: false).fetchHomeData();
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      body: Consumer<DashboardProvider>(builder: (
        context,
        dashboardData,
        snapshot,
      ) {
        if (dashboardData.currentView == DashboardScreenView.HOME) {
          currentScreen = const HomeScreen(key: ValueKey(1));
        } else if (dashboardData.currentView ==
            DashboardScreenView.CATEGORIES) {
          currentScreen = const CategoryScreen(key: ValueKey(2));
        } else if (dashboardData.currentView == DashboardScreenView.CART) {
          currentScreen = const CartScreen(key: ValueKey(3));
        } else if (dashboardData.currentView == DashboardScreenView.PROFILE) {
          currentScreen = const ProfileScreen(key: ValueKey(4));
        } else if (dashboardData.currentView == DashboardScreenView.SETTING) {
          currentScreen = const SettingScreen(key: ValueKey(5));
        } else if (dashboardData.currentView == DashboardScreenView.LOGIN ||
            dashboardData.currentView == DashboardScreenView.PROFILE_LOGIN) {
          currentScreen = const ProfileScreen(key: ValueKey(6));
        } else if (dashboardData.currentView == DashboardScreenView.REGISTER ||
            dashboardData.currentView == DashboardScreenView.PROFILE_REGISTER) {
          currentScreen = RegisterScreen(key: const ValueKey(7));
        } else {
          currentScreen = const HomeScreen();
        }

        return SafeArea(
          child: Column(
            children: [
              Expanded(
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 500),
                  transitionBuilder: (child, animation) {
                    const begin = Offset(1.0, 0.0);
                    const end = Offset.zero;
                    final tween = Tween(begin: begin, end: end);
                    final offsetAnimation = animation.drive(tween);
                    return SlideTransition(
                      position: offsetAnimation,
                      child: child,
                    );
                  },
                  child: currentScreen,
                ),
              ),
              Container(
                height: 50,
                color: white,
                child: Row(
                  children: [
                    bottomBarItem(
                        dashboardData, DashboardScreenView.HOME, "Home"),
                    bottomBarItem(dashboardData, DashboardScreenView.CATEGORIES,
                        "Category"),
                    Expanded(child: Consumer<HomeProvider>(
                        builder: (context, homeProvider, child) {
                      return GestureDetector(
                        onTap: () {
                          dashboardData
                              .changeViewNotifier(DashboardScreenView.CART);
                        },
                        child: Column(
                          children: [
                            Container(
                              height: 50,
                              decoration: const BoxDecoration(
                                color: commonBackgroundColor,
                                // border color
                                shape: BoxShape.circle,
                              ),
                              child: Stack(
                                children: [
                                  Center(
                                    child: Padding(
                                      padding: const EdgeInsets.all(12.0),
                                      child: Image.asset(
                                        "assets/images/bottomtab/Bottom_cart.png",
                                        width: 30,
                                        height: 30,
                                      ),
                                    ),
                                  ),
                                  if (homeProvider.cartCount > 0)
                                    Positioned(
                                      right: 10,
                                      top: 5,
                                      child: Container(
                                        decoration: const BoxDecoration(
                                            color: white,
                                            shape: BoxShape.circle,
                                            boxShadow: [
                                              BoxShadow(
                                                color: Colors.grey,
                                                blurRadius: 1.0,
                                              ),
                                            ]),
                                        child: Padding(
                                          padding: const EdgeInsets.all(6.0),
                                          child: CustomText(
                                            text:
                                                "${homeProvider.cartCount < 100 ? homeProvider.cartCount : "99+"}",
                                            color: primaryColor,
                                            size: 8,
                                          ),
                                        ),
                                      ),
                                    ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    })),
                    bottomBarItem(
                        dashboardData, DashboardScreenView.PROFILE, "Profile"),
                    bottomBarItem(
                        dashboardData, DashboardScreenView.SETTING, "Setting"),
                  ],
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  bottomBarItem(DashboardProvider dashboardData, DashboardScreenView viewType,
      String tabName) {
    debugPrint("dashboardData====== ${dashboardData.currentView.toString()}");
    return Expanded(
        child: GestureDetector(
      onTap: () {
        dashboardData.changeViewNotifier(viewType);
      },
      child: Container(
        color: Colors.transparent,
        padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 10),
        child: Image.asset(
          dashboardData.currentView == viewType
              ? "assets/images/bottomtab/Bottom_${tabName}_Fill.png"
              : "assets/images/bottomtab/Bottom_${tabName}.png",
          width: 20,
          height: 20,
        ),
      ),
    ));
  }
}
