import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/provider/change_password_provider.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_form_field.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../core/common.dart';

class ChangePasswordScreen extends StatefulWidget {
  const ChangePasswordScreen({Key? key}) : super(key: key);

  @override
  State<ChangePasswordScreen> createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  var formKey = GlobalKey<FormState>();
  TextEditingController oldPassController = TextEditingController();
  TextEditingController newPassController = TextEditingController();
  TextEditingController confirmPassController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<ChangePasswordProvider>(
      create: (context) => ChangePasswordProvider(),
      child: Scaffold(
        appBar: null,
        
        body: Consumer<ChangePasswordProvider>(
            builder: (context, provider, child) {
          return SafeArea(
            child: Padding(
                padding: const EdgeInsets.only(
                    left: 15.0, right: 15, top: 15, bottom: 5),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(
                        height: 15,
                      ),
                      Row(
                        children: [
                          GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: Card(
                              shape: RoundedRectangleBorder(
                                side: const BorderSide(
                                    color: Colors.white, width: 1),
                                borderRadius: BorderRadius.circular(25),
                              ),
                              child: SizedBox(
                                  height: 30,
                                  width: 30,
                                  child: Padding(
                                    padding: const EdgeInsets.all(5.5),
                                    child: Image.asset(
                                      "assets/images/back.png",
                                      width: 30,
                                      height: 30,
                                    ),
                                  )),
                            ),
                          ),
                          const SizedBox(
                            width: 20,
                          ),
                          Expanded(
                            child: CustomText(
                              text: "Update Password",
                              color: black,
                              family: boldFont,
                              size: 22,
                            ),
                          ),
                        ],
                      ),
                      Expanded(
                        child: Form(
                          key: formKey,
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            child: SingleChildScrollView(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  CustomTextFormField(
                                    hint: "Old Password",
                                    controller: oldPassController,
                                    isPassword: true,
                                    obsecure: provider.oldPasswordShow,
                                    onvisibilityChange: () {
                                      provider.updateOldPassShow();
                                    },
                                    // validator: AppGlobal().passwordValidator,
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  CustomTextFormField(
                                    hint: "New Password",
                                    controller: newPassController,
                                    isPassword: true,
                                    obsecure: provider.newPasswordShow,
                                    onvisibilityChange: () {
                                      provider.updateNewPassShow();
                                    },
                                    validator: AppGlobal().passwordValidator,
                                  ),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  CustomTextFormField(
                                    hint: "Confirm Password",
                                    isPassword: true,
                                    controller: confirmPassController,
                                    obsecure: provider.confirmPasswordShow,
                                    onvisibilityChange: () {
                                      provider.updateConfirmPassShow();
                                    },
                                    validator: (p1) => AppGlobal()
                                        .confirmPasswordValidator(
                                            p1, newPassController.text),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  CommonButton(
                                      onPressed: () async {
                                        if (formKey.currentState!.validate() &&
                                            !provider.passwordChanging) {
                                          bool result =
                                              await provider.changePassword({
                                            "current_password":
                                                oldPassController.text
                                                    .toString()
                                                    .trim(),
                                            "new_password": newPassController
                                                .text
                                                .toString()
                                                .trim()
                                          });
                                          if (result == true) {
                                            oldPassController.text = "";
                                            newPassController.text = "";
                                            confirmPassController.text = "";
                                          }
                                        }
                                      },
                                      text: provider.passwordChanging
                                          ? const CircularProgressIndicator(
                                              color: white,
                                            )
                                          : CustomText(
                                              text: 'Update',
                                              color: white,
                                              //weight: FontWeight.bold,
                                              family: mediumFont,
                                              size: 16,
                                            )),
                                  const SizedBox(
                                    height: 10,
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ),
                      ),
                    ])),
          );
        }),
      ),
    );
  }
}
