// ignore_for_file: non_constant_identifier_names

import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/dashboard_provider.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/ui/screens/checkout_screen.dart';
import 'package:ecommerce/ui/screens/login_screen.dart';
import 'package:ecommerce/ui/widgets/cart_item.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CartScreen extends StatefulWidget {
  const CartScreen({Key? key}) : super(key: key);

  @override
  State<CartScreen> createState() => _CartScreenState();
}

class _CartScreenState extends State<CartScreen> {
  var formKey = GlobalKey<FormState>();
  bool isEmpty = false;
  TextEditingController discountController = TextEditingController();

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Provider.of<HomeProvider>(context, listen: false).getCartDetailApi();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Consumer<HomeProvider>(builder: (context, provider, child) {
      return Scaffold(
        
        body: provider.isUserLoggedIn
            ? CartView(provider)
            : LoginScreen(
                provider: provider,
              ),
      );
    });
  }

  CartView(HomeProvider provider) {
    return SafeArea(
      child: Form(
        key: formKey,
        child: Padding(
            padding: const EdgeInsets.only(
                left: 15.0, right: 15, top: 15, bottom: 5),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SizedBox(
                height: 15,
              ),
              Row(
                children: [
                  const SizedBox(
                    width: 20,
                  ),
                  Expanded(
                    child: CustomText(
                      text: "Shopping Cart",
                      color: black,
                      family: boldFont,
                      size: 20,
                    ),
                  ),
                ],
              ),
              const SizedBox(
                height: 15,
              ),
              Expanded(
                  child: provider.cartItemsLoading
                      ? const Center(
                          child: CircularProgressIndicator(
                            color: primaryColor,
                          ),
                        )
                      : provider.cartResponse == null ||
                              provider.cartItemList.isEmpty
                          ? emptyCartUI()
                          : cartView(provider)),
            ])),
      ),
    );
  }

  emptyCartUI() {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          CustomText(
            text: "Cart is Empty!",
            color: greyTextColor,
            size: 22,
            family: mediumFont,
          ),
          const SizedBox(
            height: 15,
          ),
          CommonButton(
              width: 150,
              onPressed: () {
                Provider.of<DashboardProvider>(context, listen: false)
                    .changeViewNotifier(DashboardScreenView.HOME);
              },
              text: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset(
                    "assets/images/bottomtab/Bottom_cart.png",
                    color: white,
                    height: 15,
                    width: 15,
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                  CustomText(
                    text: "Cart is Empty",
                    color: white,
                    size: 14,
                    family: mediumFont,
                  ),
                ],
              )),
        ],
      ),
    );
  }

  cartView(HomeProvider provider) {
    return Column(
      children: [
        Expanded(
          child: ListView.builder(
            shrinkWrap: true,
            itemBuilder: (context, index) {
              return CartItemWidget(
                cartProductItem: provider.cartItemList[index],
                qtyMinus: () {
                  if (provider.cartItemList[index].quantity != null) {
                    int qty = int.parse(provider.cartItemList[index].quantity!);
                    if (qty > 1) {
                      provider.updateCartQty(
                          provider.cartItemList[index].cartId!, --qty);
                    }
                  }
                },
                qtyPlus: () {
                  if (provider.cartItemList[index].quantity != null) {
                    int qty = int.parse(provider.cartItemList[index].quantity!);
                    provider.updateCartQty(
                        provider.cartItemList[index].cartId!, ++qty);
                  }
                },
                openProduct: () {},
                deleteProduct: () {
                  provider.deleteCartITem(provider.cartItemList[index].cartId!);
                },
              );
            },
            itemCount: provider.cartItemList.length,
          ),
        ),
        const SizedBox(
          height: 10,
        ),
        TextFormField(
          controller: discountController,
          style: const TextStyle(
              color: blackDarkLight, fontSize: 14, fontFamily: mediumFont),
          keyboardType: TextInputType.text,
          decoration: InputDecoration(
              contentPadding:
                  const EdgeInsets.symmetric(vertical: 10.0, horizontal: 10.0),
              hintText: 'Coupon Code (Use otrixweb)',
              counterText: "",
              hintStyle: const TextStyle(
                  color: Colors.black26, fontSize: 14, fontFamily: mediumFont),
              isDense: true,
              errorStyle: const TextStyle(
                height: 0.3,
                fontSize: 10,
              ),
              suffixIcon: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (provider.discount != null)
                    InkWell(
                        onTap: () {
                          discountController.text = "";
                          provider.setDiscount(null);
                        },
                        child: const Padding(
                          padding: EdgeInsets.all(8.0),
                          child: Icon(
                            Icons.cancel,
                            color: Colors.red,
                            size: 15,
                          ),
                        )),
                  InkWell(
                    onTap: () {
                      if (discountController.text.trim().isNotEmpty) {
                        provider.applyDiscount(discountController.text.trim());
                      }
                    },
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(right: 10.0, left: 10),
                          child: CustomText(
                            text: "Apply",
                            color: primaryColor,
                            family: mediumFont,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              errorBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(3.0),
                borderSide: const BorderSide(color: Colors.red, width: 0.5),
              ),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(3.0),
                borderSide: const BorderSide(width: 0.5, color: Colors.green),
              ),
              enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(3.0),
                borderSide: const BorderSide(color: greyTextColor, width: 0.5),
              ),
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(3.0),
                borderSide: const BorderSide(color: primaryColor, width: 0.5),
              )),
        ),
        Container(
          margin: const EdgeInsets.symmetric(vertical: 10),
          height: 0.2,
          width: double.maxFinite,
          color: greyTextColor,
        ),
        bottomItem("Sub Total", "$currency${provider.cartResponse!.subTotal ?? " "}"),
        const SizedBox(
          height: 10,
        ),
        if (provider.cartResponse!.taxes != null)
          if (provider.cartResponse!.taxes!.taxAmount != null)
            if (provider.cartResponse!.taxes!.taxAmount! > 0)
              bottomItem("Tax",
                  "$currency${provider.cartResponse!.taxes!.taxAmount!.toString()}"),
        if (provider.cartResponse!.taxes != null)
          if (provider.cartResponse!.taxes!.taxAmount != null)
            if (provider.cartResponse!.taxes!.taxAmount! > 0)
              const SizedBox(
                height: 10,
              ),
        if (provider.discount != null)
          bottomItem("${provider.discount!.name}",
              "-$currency${provider.discount!.discountAmt}"),
        if (provider.discount != null)
          const SizedBox(
            height: 10,
          ),
        bottomItem("Total",
            "$currency${provider.grandTotalNew ?? provider.cartResponse!.grandTotal ?? " "}",
            isGrand: true),
        const SizedBox(
          height: 15,
        ),
        CommonButton(
            onPressed: () {
              if (provider.cartItemList.isNotEmpty) {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) => const CheckoutScreen()));
              }
            },
            text: CustomText(
              text: "Checkout",
              family: mediumFont,
              size: 18,
              color: white,
            )),
        const SizedBox(
          height: 15,
        ),
      ],
    );
  }

  bottomItem(String title, String value, {bool? isGrand}) {
    return Row(
      children: [
        CustomText(
          text: title,
          family: mediumFont,
          size: 18,
          color: greyTextColor,
        ),
        Expanded(
            child: Align(
                alignment: Alignment.centerRight,
                child: CustomText(
                  text: value,
                  family: mediumFont,
                  size: 20,
                  color: isGrand == true ? primaryColor : black,
                )))
      ],
    );
  }
}
