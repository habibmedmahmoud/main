import 'dart:convert';

import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/app_provider.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/ui/screens/home_screen.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_form_field.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({Key? key}) : super(key: key);

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  var formKey = GlobalKey<FormState>();
  TextEditingController fNameController = TextEditingController();
  TextEditingController lNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController mobileController = TextEditingController();

  late HomeProvider homeProvider;

  @override
  void initState() {
    homeProvider = context.read<HomeProvider>();
    fNameController.text = homeProvider.userData!.firstname ?? "";
    lNameController.text = homeProvider.userData!.lastname ?? "";
    emailController.text = homeProvider.userData!.email ?? "";
    mobileController.text = homeProvider.userData!.telephone ?? "";

    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      
      body: SafeArea(
        child: Consumer<HomeProvider>(builder: (context, provider, child) {
          return Form(
            key: formKey,
            child: Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15, top: 15, bottom: 5),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 15,
                    ),
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Card(
                            shape: RoundedRectangleBorder(
                              side: const BorderSide(
                                  color: Colors.white, width: 1),
                              borderRadius: BorderRadius.circular(25),
                            ),
                            child: SizedBox(
                                height: 30,
                                width: 30,
                                child: Padding(
                                  padding: const EdgeInsets.all(5.5),
                                  child: Image.asset(
                                    "assets/images/back.png",
                                    width: 30,
                                    height: 30,
                                  ),
                                )),
                          ),
                        ),
                        const SizedBox(
                          width: 20,
                        ),
                        Expanded(
                          child: CustomText(
                            text: "Edit Profile",
                            color: black,
                            family: boldFont,
                            size: 26,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    CustomTextFormField(
                      hint: "First Name",
                      controller: fNameController,
                      validator: (val) =>
                          AppGlobal().valueValidator(val, "Enter first name"),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    CustomTextFormField(
                      hint: "Last Name",
                      controller: lNameController,
                      validator: (val) =>
                          AppGlobal().valueValidator(val, "Enter last name"),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    CustomTextFormField(
                      hint: "Email ",
                      readOnly: true,
                      controller: emailController,
                      validator: (val) => AppGlobal().emailValidator(val),
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    CustomTextFormField(
                      hint: "Mobile Number",
                      controller: mobileController,
                      validator: (val) =>
                          AppGlobal().mobileNumberValidator(val),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    CommonButton(
                        onPressed: () {
                          if (formKey.currentState!.validate() &&
                              !provider.profileUpdating) {
                            provider.updateUserProfile({
                              "firstname":
                                  fNameController.text.toString().trim(),
                              "lastname":
                                  lNameController.text.toString().trim(),
                              "telephone":
                                  mobileController.text.toString().trim(),
                              //"firebase_token":abc
                            });
                          }
                        },
                        text: provider.profileUpdating
                            ? const Padding(
                              padding: EdgeInsets.symmetric(vertical: 5.0),
                              child: CircularProgressIndicator(
                                  color: white,
                                  strokeWidth: 2,
                                ),
                            )
                            : CustomText(
                                text: 'Update',
                                color: white,
                                family: mediumFont,
                                size: 15,
                              )),
                  ],
                ),
              ),
            ),
          );
        }),
      ),
    );
  }
}
