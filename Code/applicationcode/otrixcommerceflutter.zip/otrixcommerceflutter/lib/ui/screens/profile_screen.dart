import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/provider/dashboard_provider.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/ui/screens/add_address_screen.dart';
import 'package:ecommerce/ui/screens/address_screen.dart';
import 'package:ecommerce/ui/screens/change_password_screen.dart';
import 'package:ecommerce/ui/screens/edit_profile.dart';
import 'package:ecommerce/ui/screens/login_screen.dart';
import 'package:ecommerce/ui/screens/my_orders_screen.dart';
import 'package:ecommerce/ui/screens/wishlist_screen.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/profile_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_vector_icons/flutter_vector_icons.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final ImagePicker _picker = ImagePicker();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      
      body: Consumer<HomeProvider>(builder: (context, provider, child) {
        return provider.isUserLoggedIn
            ? Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 20,
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 30.0, vertical: 0),
                    child: CustomText(
                      text: "My Profile",
                      family: boldFont,
                      color: black,
                      size: 20,
                    ),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  ProfileImageView(provider),
                  const SizedBox(
                    height: 30,
                  ),
                  Expanded(
                    child: Container(
                      width: double.maxFinite,
                      decoration: const BoxDecoration(
                          color: white,
                          borderRadius: BorderRadius.only(
                              topLeft: Radius.circular(30),
                              topRight: Radius.circular(30))),
                      child: Column(
                        children: [
                          Expanded(
                            child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 25, vertical: 15),
                              child: SingleChildScrollView(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    ProfileItemWidget(
                                      title: 'Edit Profile',
                                      iconImage: FontAwesome5Solid.user_edit,
                                      onItemClick: () {
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (BuildContext
                                                        context) =>
                                                    const EditProfileScreen()));
                                      },
                                    ),
                                    ProfileItemWidget(
                                      title: 'Wishlist',
                                      iconImage: MaterialIcons.favorite,
                                      onItemClick: () {
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (BuildContext
                                                        context) =>
                                                    const WishlistScreen()));
                                      },
                                    ),
                                    ProfileItemWidget(
                                      title: 'Manage Address',
                                      iconImage:
                                          FontAwesome5Regular.address_book,
                                      onItemClick: () {
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder:
                                                    (BuildContext context) =>
                                                        const AddressScreen()));
                                      },
                                    ),
                                    ProfileItemWidget(
                                      title: 'My Orders',
                                      iconImage: Fontisto.shopping_bag_1,
                                      onItemClick: () {
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (BuildContext
                                                        context) =>
                                                    const MyOrdersScreen()));
                                      },
                                    ),
                                    ProfileItemWidget(
                                      title: 'Change Password',
                                      iconImage: Fontisto.locked,
                                      onItemClick: () {
                                        Navigator.of(context).push(
                                            MaterialPageRoute(
                                                builder: (BuildContext
                                                        context) =>
                                                    const ChangePasswordScreen()));
                                      },
                                    ),
                                    ProfileItemWidget(
                                      title: 'Logout',
                                      iconImage: AntDesign.logout,
                                      onItemClick: () async {
                                        bool result = await provider.logout();
                                        if (result == true) {
                                          // ignore: use_build_context_synchronously
                                          Provider.of<DashboardProvider>(
                                                  context,
                                                  listen: false)
                                              .changeViewNotifier(
                                                  DashboardScreenView.HOME);
                                        }
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              )
            : LoginScreen(provider: provider);
      }),
    );
  }

  // ignore: non_constant_identifier_names
  ProfileImageView(HomeProvider provider) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 0),
      width: double.maxFinite,
      child: Column(
        children: [
          Stack(
            children: [
              InkWell(
                onTap: () {
                  if (!provider.imageUploading) selectImage(provider);
                },
                child: Container(
                  height: 100,
                  width: 100,
                  decoration: BoxDecoration(
                      borderRadius: const BorderRadius.all(Radius.circular(5)),
                      border: Border.all(color: white, width: 5)),
                  child: provider.userData != null
                      ? provider.userData!.image != null
                          ? CachedNetworkImage(
                              imageUrl:
                                  "${ApiServices.uploadURL}${ApiServices.uploadUserProfileURL}${provider.userData!.image}",
                              placeholder: (context, url) => Container(
                                height: 100,
                              ),
                              errorWidget: (context, url, error) => Image.asset(
                                "assets/images/man.jpg",
                                height: 100,
                              ),
                              height: 100,
                              fit: BoxFit.fill,
                            )
                          : Image.asset(
                              "assets/images/man.jpg",
                              height: 100,
                            )
                      : Image.asset(
                          "assets/images/man.jpg",
                          height: 100,
                        ),
                ),
              ),
              if (provider.imageUploading)
                const Positioned.fill(
                    child: Align(
                        alignment: Alignment.center,
                        child: CircularProgressIndicator(
                          color: primaryColor,
                        ))),
            ],
          ),
          const SizedBox(
            height: 5,
          ),
          CustomText(
            text:
                "${provider.userData!.firstname} ${provider.userData!.lastname}",
            family: mediumFont,
            color: black,
            size: 18,
          ),
          const SizedBox(
            height: 3,
          ),
          CustomText(
            text: "${provider.userData!.email}",
            family: regularFont,
            color: greyTextColor,
            size: 14,
          ),
        ],
      ),
    );
  }

  selectImage(HomeProvider provider) async {
    // Pick an image
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      File imageFile = File(image.path);
      if (await imageFile.exists()) {
        // Upload Image code
        //print(imageFile.path);
        provider.uploadImage(imageFile);
      }
    }
  }
}
