import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/language_provider.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/language_item.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class LanguageScreen extends StatefulWidget {
  const LanguageScreen({Key? key}) : super(key: key);

  @override
  State<LanguageScreen> createState() => _LanguageScreenState();
}

class _LanguageScreenState extends State<LanguageScreen> {
  @override
  void initState() {
    // Provider.of<LanguageProvider>(context);
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      
      body: Consumer<LanguageProvider>(builder: (
        context,
        languageData,
        snapshot,
      ) {
        return Padding(
          padding:
              const EdgeInsets.only(left: 15.0, right: 15, top: 45, bottom: 5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(
                  bottom: 0,
                  left: 00,
                  right: 0,
                ),
                child: Row(
                  children: [
                    Card(
                      // borderRadius: BorderRadius.circular(8),
                      shape: RoundedRectangleBorder(
                        side: BorderSide(color: Colors.white, width: 1),
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: Container(
                          height: 30,
                          width: 30,
                          /*decoration: const BoxDecoration(
                      borderRadius: BorderRadius.all(Radius.circular(25)),
                      color: white,
                    ),*/
                          child: Padding(
                            padding: const EdgeInsets.all(5.5),
                            child: Image.asset(
                              "assets/images/back.png",
                              width: 30,
                              height: 30,
                            ),
                          )),
                    ),
                    const SizedBox(
                      width: 25,
                    ),
                    CustomText(
                      text: 'Language',
                      color: black,
                      family: boldFont,
                      size: 22,
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 35,
              ),
              Expanded(
                child: SingleChildScrollView(
                    child: Column(
                  children: [
                    LanguageItemWidget(
                        title: 'English',
                        onItemClick: () => {languageData.changeLanguage("en")},
                        isSelected: languageData.selectedLanguage == "en"),
                    LanguageItemWidget(
                        title: 'Arabic',
                        onItemClick: () => {languageData.changeLanguage("ar")},
                        isSelected: languageData.selectedLanguage == "ar"),
                    SizedBox(
                      height: 15,
                    ),
                    CommonButton(
                      onPressed: () => {},
                      text: CustomText(
                        text: "Save",
                        size: 18,
                        color: white,
                        family: mediumFont,
                      ),
                    )
                  ],
                )),
              ),
            ],
          ),
        );
      }),
    );
  }
}
