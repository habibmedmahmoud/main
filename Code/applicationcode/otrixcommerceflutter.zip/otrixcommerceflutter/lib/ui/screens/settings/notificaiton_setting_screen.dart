import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/setting_provider.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/notification_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class NotificationSettingScreen extends StatefulWidget {
  const NotificationSettingScreen({Key? key}) : super(key: key);

  @override
  State<NotificationSettingScreen> createState() =>
      _NotificationSettingScreenState();
}

class _NotificationSettingScreenState extends State<NotificationSettingScreen> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<SettingProvider>(
      create: (context) => SettingProvider(
        context,
        pageType: 'notification',
      ),
      child: Scaffold(
        appBar: null,
        
        body: Consumer<SettingProvider>(builder: (context, provider, child) {
          return SafeArea(
            child: Padding(
                padding: const EdgeInsets.only(
                    left: 15.0, right: 15, top: 15, bottom: 5),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(
                        height: 15,
                      ),
                      Row(
                        children: [
                          GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: Card(
                              shape: RoundedRectangleBorder(
                                side: const BorderSide(
                                    color: Colors.white, width: 1),
                                borderRadius: BorderRadius.circular(25),
                              ),
                              child: SizedBox(
                                  height: 30,
                                  width: 30,
                                  child: Padding(
                                    padding: const EdgeInsets.all(5.5),
                                    child: Image.asset(
                                      "assets/images/back.png",
                                      width: 30,
                                      height: 30,
                                    ),
                                  )),
                            ),
                          ),
                          const SizedBox(
                            width: 20,
                          ),
                          Expanded(
                            child: CustomText(
                              text: "Notification Settings",
                              color: black,
                              family: boldFont,
                              size: 18,
                            ),
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      Expanded(
                        child: SingleChildScrollView(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              CustomText(
                                text: "Enable Notification For",
                                color: black,
                                family: boldFont,
                                size: 18,
                              ),
                              const SizedBox(
                                height: 7,
                              ),
                              ListView.builder(
                                shrinkWrap: true,
                                physics: const NeverScrollableScrollPhysics(),
                                itemBuilder: (BuildContext context, int index) {
                                  return NotificationItemWidget(
                                    name: provider.forYouList[index],
                                    isSelected:
                                        provider.selectedForYou.contains(index),
                                    onselect: (val) {
                                      provider.UpdateForYouSelection(index);
                                    },
                                  );
                                },
                                itemCount: provider.forYouList.length,
                              ),
                              const SizedBox(
                                height: 15,
                              ),
                              if (provider.categoriesLis.isNotEmpty)
                                CustomText(
                                  text: "Enable Notification For",
                                  color: black,
                                  family: boldFont,
                                  size: 18,
                                ),
                              const SizedBox(
                                height: 7,
                              ),
                              if (provider.categoriesLis.isNotEmpty)
                                ListView.builder(
                                  shrinkWrap: true,
                                  physics: const NeverScrollableScrollPhysics(),
                                  itemBuilder:
                                      (BuildContext context, int index) {
                                    return NotificationItemWidget(
                                      name: provider.categoriesLis[index]
                                          .categoryDescription!.name!,
                                      isSelected: provider.selectedNotifications
                                          .contains(index),
                                      onselect: (val) {
                                        provider.UpdateNotificaitonSelection(
                                            index);
                                      },
                                    );
                                  },
                                  itemCount: provider.categoriesLis.length,
                                ),
                            ],
                          ),
                        ),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      CommonButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          text: CustomText(
                            text: "Save",
                            color: white,
                            family: mediumFont,
                          )),
                      const SizedBox(
                        height: 10,
                      ),
                    ])),
          );
        }),
      ),
    );
  }
}
