import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/setting_provider.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:provider/provider.dart';

class PagesScreen extends StatefulWidget {
  int pageNumber;
  String title;

  PagesScreen({Key? key, required this.pageNumber, required this.title})
      : super(key: key);

  @override
  State<PagesScreen> createState() => _PagesScreenState();
}

class _PagesScreenState extends State<PagesScreen> {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<SettingProvider>(
      create: (context) => SettingProvider(context,
          pageType: 'page', pageNumber: widget.pageNumber),
      child: Scaffold(
        appBar: null,
        
        body: Consumer<SettingProvider>(builder: (context, provider, child) {
          return SafeArea(
            child: Padding(
                padding: const EdgeInsets.only(
                    left: 15.0, right: 15, top: 15, bottom: 5),
                child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const SizedBox(
                        height: 15,
                      ),
                      Row(
                        children: [
                          GestureDetector(
                            onTap: () => Navigator.pop(context),
                            child: Card(
                              shape: RoundedRectangleBorder(
                                side: const BorderSide(
                                    color: Colors.white, width: 1),
                                borderRadius: BorderRadius.circular(25),
                              ),
                              child: SizedBox(
                                  height: 30,
                                  width: 30,
                                  child: Padding(
                                    padding: const EdgeInsets.all(5.5),
                                    child: Image.asset(
                                      "assets/images/back.png",
                                      width: 30,
                                      height: 30,
                                    ),
                                  )),
                            ),
                          ),
                          const SizedBox(
                            width: 20,
                          ),
                          Expanded(
                            child: CustomText(
                              text: "${widget.title}",
                              color: black,
                              family: boldFont,
                              size: 18,
                            ),
                          ),
                          const SizedBox(
                            width: 10,
                          ),
                        ],
                      ),
                      const SizedBox(
                        height: 15,
                      ),
                      Flexible(
                        child: provider.loading
                            ? const Center(
                                child: CircularProgressIndicator(
                                  color: primaryColor,
                                ),
                              )
                            : provider.pagesData == null
                                ? Center(
                                    child: CustomText(
                                      text: "Data not found",
                                      color: black,
                                      family: mediumFont,
                                      size: 16,
                                    ),
                                  )
                                : SingleChildScrollView(
                                    child: Container(
                                      margin: const EdgeInsets.all(10),
                                      padding: const EdgeInsets.all(10),
                                      decoration: BoxDecoration(
                                          border:
                                              Border.all(color: greyTextColor),
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(10)),
                                          color: white),
                                      child: Html(
                                        shrinkWrap: true,
                                        style: {
                                          "body": Style(
                                              margin: EdgeInsets.zero,
                                              padding: EdgeInsets.zero)
                                        },
                                        data: provider.pagesData!.description ??
                                            "",
                                      ),
                                    ),
                                  ),
                      ),
                    ])),
          );
        }),
      ),
    );
  }
}
