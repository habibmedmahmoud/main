import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/ui/screens/product_list_screen.dart';
import 'package:ecommerce/ui/widgets/brand_widget.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class BrandScreen extends StatefulWidget {
  const BrandScreen({Key? key}) : super(key: key);

  @override
  State<BrandScreen> createState() => _BrandScreenState();
}

class _BrandScreenState extends State<BrandScreen> {
  double itemWidth = 0;

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Provider.of<HomeProvider>(context, listen: false).fetBrandsResponse();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    itemWidth = (MediaQuery.of(context).size.width / 2);
    return Scaffold(
      appBar: null,
      
      body: SafeArea(
        child: Consumer<HomeProvider>(builder: (context, userHome, child) {
          return Padding(
            padding: const EdgeInsets.only(
                left: 15.0, right: 15, top: 15, bottom: 5),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(
                  height: 15,
                ),
                Row(
                  children: [
                    GestureDetector(
                      onTap: () => Navigator.pop(context),
                      child: Card(
                        shape: RoundedRectangleBorder(
                          side: const BorderSide(color: Colors.white, width: 1),
                          borderRadius: BorderRadius.circular(25),
                        ),
                        child: SizedBox(
                            height: 30,
                            width: 30,
                            child: Padding(
                              padding: const EdgeInsets.all(5.5),
                              child: Image.asset(
                                "assets/images/back.png",
                                width: 30,
                                height: 30,
                              ),
                            )),
                      ),
                    ),
                    const SizedBox(
                      width: 20,
                    ),
                    CustomText(
                      text: 'Brands',
                      color: black,
                      family: boldFont,
                      size: 26,
                    ),
                  ],
                ),
                const SizedBox(
                  height: 15,
                ),
                Expanded(
                  child: GridView.builder(
                      shrinkWrap: true,
                      gridDelegate:
                          const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2),
                      itemBuilder: (context, index) {
                        return BrandWidget(
                          deals: userHome.brandsList[index],
                          itemHeight: 220,
                          itemWidth: 220,
                        );
                      },
                      itemCount: userHome.brandsList.length),
                ),
              ],
            ),
          );
        }),
      ),
    );
  }
}
