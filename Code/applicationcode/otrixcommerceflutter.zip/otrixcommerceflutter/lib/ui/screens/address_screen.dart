import 'package:ecommerce/provider/address_provider.dart';
import 'package:ecommerce/ui/screens/address_list_screen.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class AddressScreen extends StatelessWidget {
  const AddressScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<AddressProvider>(
      create: (context) => AddressProvider(context),
      child: Consumer<AddressProvider>(builder: (context, provider, child) {
        return Scaffold(
          appBar: null,
          body: SafeArea(
            child:  AddressListScreen(provider),
          ),
        );
      }),
    );
  }
}
