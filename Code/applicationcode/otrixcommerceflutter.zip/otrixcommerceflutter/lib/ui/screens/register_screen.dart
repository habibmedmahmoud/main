// ignore_for_file: use_build_context_synchronously

import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/dashboard_provider.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_form_field.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class RegisterScreen extends StatefulWidget {
  bool? navigateToPushBack;

  RegisterScreen({Key? key, this.navigateToPushBack}) : super(key: key);

  @override
  _RegisterScreenState createState() => _RegisterScreenState();
}

class _RegisterScreenState extends State<RegisterScreen> {
  bool passwordHide = true, confirmPasswordHide = true;
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmPasswordController = TextEditingController();
  TextEditingController fNameController = TextEditingController();
  TextEditingController lNameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController mobileController = TextEditingController();

  var formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Consumer<HomeProvider>(builder: (context, provider, child) {
      return Scaffold(
          appBar: null,
          body: SafeArea(
            child: SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12.0, vertical: 30),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        text: "Register Account",
                        family: mediumFont,
                        size: 28,
                      ),
                      CustomText(
                        text: "Create account to continue shopping with otrixweb",
                        family: regularFont,
                        color: greyTextColor,
                        size: 14,
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      CustomTextFormField(
                        hint: "First Name",
                        controller: fNameController,
                        validator: (val) =>
                            AppGlobal().valueValidator(val, "Enter first name"),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      CustomTextFormField(
                        hint: "Last Name",
                        controller: lNameController,
                        validator: (val) =>
                            AppGlobal().valueValidator(val, "Enter last name"),
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      CustomTextFormField(
                        hint: "Email Address",
                        controller: emailController,
                        textInputType: TextInputType.emailAddress,
                        validator: AppGlobal().emailValidator,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      CustomTextFormField(
                        hint: "Mobile Number",
                        controller: mobileController,
                        maxLength: 15,
                        textInputType: TextInputType.phone,
                        validator: AppGlobal().mobileNumberValidator,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      CustomTextFormField(
                        hint: "Password",
                        isPassword: true,
                        controller: passwordController,
                        obsecure: passwordHide,
                        onvisibilityChange: () {
                          setState(() {
                            passwordHide = !passwordHide;
                          });
                        },
                        validator: AppGlobal().passwordValidator,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      CustomTextFormField(
                        hint: "Confirm Password",
                        isPassword: true,
                        controller: confirmPasswordController,
                        obsecure: confirmPasswordHide,
                        onvisibilityChange: () {
                          setState(() {
                            confirmPasswordHide = !confirmPasswordHide;
                          });
                        },
                        validator: (val) {
                          return AppGlobal().confirmPasswordValidator(
                              val, passwordController.text.toString().trim());
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      CommonButton(
                          onPressed: () async {
                            if (formKey.currentState!.validate() &&
                                !provider.isRegisterLoading) {
                              Map<String, dynamic> data = {
                                "firstname":
                                    fNameController.text.toString().trim(),
                                "lastname":
                                    lNameController.text.toString().trim(),
                                "email": emailController.text.toString().trim(),
                                "telephone":
                                    mobileController.text.toString().trim(),
                                "password":
                                    passwordController.text.toString().trim(),
                                "is_flutter": true,
                                "firebase_token":
                                    await FirebaseMessaging.instance.getToken() ??
                                        ""
                              };
                              await provider.registerUser(data);

                              if (provider.isUserLoggedIn &&
                                  widget.navigateToPushBack == true) {
                                Navigator.pop(context, "1");
                              } else if (provider.isUserLoggedIn) {
                                Provider.of<DashboardProvider>(context,
                                        listen: false)
                                    .changeViewNotifier(DashboardScreenView.HOME);
                              }
                            }
                          },
                          text: provider.isRegisterLoading
                              ? const SizedBox(
                                  height: 20,
                                  width: 20,
                                  child: CircularProgressIndicator(
                                    color: white,
                                  ))
                              : CustomText(
                                  text: 'Register Now',
                                  color: white,
                                  family: mediumFont,
                                  size: 15,
                                )),
                      const SizedBox(
                        height: 25,
                      ),
                      Align(
                        alignment: Alignment.center,
                        child: RichText(
                          textAlign: TextAlign.center,
                          text: TextSpan(
                              text: 'Already have an account? ',
                              style: const TextStyle(
                                  color: greyTextColor,
                                  fontFamily: regularFont,
                                  fontSize: 16),
                              children: [
                                TextSpan(
                                    text: 'Sign in',
                                    style: const TextStyle(
                                        color: primaryColor,
                                        fontWeight: FontWeight.w700),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        if (widget.navigateToPushBack == true) {
                                          Navigator.pop(context);
                                        } else {
                                          Provider.of<DashboardProvider>(context,
                                                  listen: false)
                                              .changeViewNotifier(
                                                  DashboardScreenView.LOGIN);
                                        }
                                      }),
                              ]),
                        ),
                      ),
                      const SizedBox(
                        height: 25,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ));
    });
  }
}
