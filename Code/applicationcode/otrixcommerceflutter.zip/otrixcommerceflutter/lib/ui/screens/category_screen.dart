import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/ui/screens/product_list_screen.dart';
import 'package:ecommerce/ui/widgets/cat_page_item.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CategoryScreen extends StatefulWidget {
  const CategoryScreen({Key? key}) : super(key: key);

  @override
  State<CategoryScreen> createState() => _CategoryScreenState();
}

class _CategoryScreenState extends State<CategoryScreen> {
  double itemWidth = 0;

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Provider.of<HomeProvider>(context, listen: false).fetCategoriesResponse();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    itemWidth = (MediaQuery.of(context).size.width / 2) as double;
    return Scaffold(
      appBar: null,
      body: Consumer<HomeProvider>(builder: (context, userHome, child) {
        return Padding(
          padding:
              const EdgeInsets.only(left: 15.0, right: 15, top: 15, bottom: 5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(bottom: 15),
                child: CustomText(
                  text: 'Categories',
                  color: black,
                  family: boldFont,
                  size: 26,
                ),
              ),
              Expanded(
                child: userHome.catLoading && userHome.categoriesLis.isEmpty
                    ? const Center(
                        child: CircularProgressIndicator(),
                      )
                    : GridView.builder(
                        shrinkWrap: true,
                        gridDelegate:
                            const SliverGridDelegateWithFixedCrossAxisCount(
                                crossAxisCount: 2),
                        itemBuilder: (context, index) {
                          return CatPageItem(
                            deals: userHome.categoriesLis[index],
                            itemHeight: 180,
                            itemWidth: itemWidth,
                          );
                        },
                        itemCount: userHome.categoriesLis.length),
              ),
            ],
          ),
        );
      }),
    );
  }
}
