import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/address/address_model.dart';
import 'package:ecommerce/provider/address_provider.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_form_field.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class AddAddressScreen extends StatefulWidget {
  AddressProvider provider;
  AddressModel? addressModel;

  AddAddressScreen(this.provider, {Key? key, this.addressModel})
      : super(key: key);

  @override
  State<AddAddressScreen> createState() => _AddAddressScreenState();
}

class _AddAddressScreenState extends State<AddAddressScreen> {
  TextEditingController countryController = TextEditingController();
  TextEditingController nameController = TextEditingController();
  TextEditingController cityController = TextEditingController();
  TextEditingController postcodeController = TextEditingController();
  TextEditingController address1Controller = TextEditingController();
  TextEditingController address2Controller = TextEditingController();

  var formKey = GlobalKey<FormState>();
  AddressModel addressModel = AddressModel();

  @override
  void initState() {
    if (widget.addressModel != null) {
      addressModel = widget.addressModel!;
      countryController.text = addressModel.country ?? "";
      nameController.text = addressModel.name ?? "";
      cityController.text = addressModel.city ?? "";
      postcodeController.text = addressModel.postcode ?? "";
      address1Controller.text = addressModel.address1 ?? "";
      address2Controller.text = addressModel.address2 ?? "";
      WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
        try {
          widget.provider.selectCountry(widget.provider.countryList.firstWhere(
              (element) => element.id!.toString() == addressModel.countryId));
        } catch (ex) {
          countryController.text = "";
          widget.provider.selectCountry(null);
        }
      });
    } else {
      WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
        countryController.text = "";
        widget.provider.selectCountry(null);
      });
    }

    widget.provider.addListener(listenCountryChange);
    super.initState();
  }

  void listenCountryChange() {
    if (widget.provider.countryChange) {
      if (widget.provider.selectedCountry != null) {
        countryController.text = widget.provider.selectedCountry!.name ?? "";
      }
    }
  }

  @override
  void dispose() {
    widget.provider.removeListener(listenCountryChange);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Form(
          key: formKey,
          child: Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15, top: 15, bottom: 5),
              child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(
                      height: 15,
                    ),
                    Row(
                      children: [
                        GestureDetector(
                          onTap: () => Navigator.pop(context),
                          child: Card(
                            shape: RoundedRectangleBorder(
                              side: const BorderSide(
                                  color: Colors.white, width: 1),
                              borderRadius: BorderRadius.circular(25),
                            ),
                            child: SizedBox(
                                height: 30,
                                width: 30,
                                child: Padding(
                                  padding: const EdgeInsets.all(8),
                                  child: Image.asset(
                                    "assets/images/cancel.png",
                                    width: 20,
                                    height: 20,
                                  ),
                                )),
                          ),
                        ),
                        const SizedBox(
                          width: 20,
                        ),
                        Expanded(
                          child: CustomText(
                            text: "Add Address",
                            color: black,
                            family: boldFont,
                            size: 20,
                          ),
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                      ],
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    Expanded(
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            CustomTextFormField(
                              hint: "Name",
                              controller: nameController,
                              validator: (val) =>
                                  AppGlobal().valueValidator(val, "Enter name"),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            GestureDetector(
                              onTap: () => showModal(context, widget.provider),
                              child: CustomTextFormField(
                                hint: "Country ",
                                controller: countryController,
                                readOnly: true,
                                validator: (val) => AppGlobal()
                                    .valueValidator(val, "Select Country"),
                              ),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            CustomTextFormField(
                              hint: "City",
                              controller: cityController,
                              validator: (val) =>
                                  AppGlobal().valueValidator(val, "Enter City"),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            CustomTextFormField(
                              hint: "Post Code",
                              controller: postcodeController,
                              validator: (val) => AppGlobal()
                                  .valueValidator(val, "Enter PostCode"),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            CustomTextFormField(
                              hint: "Address 1",
                              controller: address1Controller,
                              maxLines: 3,
                              textInputType: TextInputType.multiline,
                              textInputAction: TextInputAction.newline,
                              validator: (val) => AppGlobal()
                                  .valueValidator(val, "Enter Address 1"),
                            ),
                            const SizedBox(
                              height: 10,
                            ),
                            CustomTextFormField(
                              hint: "Address 2",
                              maxLines: 3,
                              controller: address2Controller,
                              textInputType: TextInputType.multiline,
                              textInputAction: TextInputAction.newline,
                            ),
                            const SizedBox(
                              height: 15,
                            ),
                            CommonButton(
                                onPressed: () async {
                                  if (formKey.currentState!.validate() &&
                                      widget.provider.selectedCountry != null &&
                                      !widget.provider.addAddressLoading) {
                                    Map<String, dynamic> data = {
                                      "name":
                                          nameController.text.trim().toString(),
                                      "address_1": address1Controller.text
                                          .trim()
                                          .toString(),
                                      "address_2": address2Controller.text
                                          .trim()
                                          .toString(),
                                      "city":
                                          cityController.text.trim().toString(),
                                      "country_id":
                                          widget.provider.selectedCountry!.id,
                                      "postcode": postcodeController.text
                                          .trim()
                                          .toString(),
                                    };
                                    late bool result;
                                    if (addressModel.id == null) {
                                      // Add new Address
                                      result = await widget.provider
                                          .addAddress(data);
                                    } else {
                                      //Update Old Address
                                      result = await widget.provider
                                          .updateAddress(
                                              data, addressModel.id!);
                                    }
                                    if (result == true) {
                                      // ignore: use_build_context_synchronously
                                      Navigator.pop(context, "1");
                                    }
                                  }
                                },
                                text: widget.provider.addAddressLoading
                                    ? const CircularProgressIndicator(
                                        color: white,
                                      )
                                    : CustomText(
                                        text: 'Add',
                                        color: white,
                                        family: mediumFont,
                                        size: 15,
                                      )),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(
                      height: 15,
                    ),
                  ])),
        ),
      ),
    );
  }

  void showModal(context, AddressProvider provider) {
    showModalBottomSheet(
        context: context,
        builder: (context) {
          return Container(
            padding: const EdgeInsets.all(8),
            height: 350,
            alignment: Alignment.center,
            child: Column(
              children: [
                Container(
                  width: 50,
                  height: 5,
                  decoration: const BoxDecoration(
                    color: greyTextColor,
                    borderRadius: const BorderRadius.all(Radius.circular(10)),
                  ),
                ),
                const SizedBox(
                  height: 5,
                ),
                Expanded(
                  child: ListView.separated(
                      shrinkWrap: true,
                      itemCount: provider.countryList.length,
                      separatorBuilder: (context, int) {
                        return const Divider();
                      },
                      itemBuilder: (context, index) {
                        return InkWell(
                            child: Container(
                                width: double.maxFinite,
                                color: provider.selectedCountry ==
                                        provider.countryList[index]
                                    ? Colors.green
                                    : Colors.transparent,
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 15.0, vertical: 10),
                                child: CustomText(
                                  text: "${provider.countryList[index].name}",
                                  size: 16,
                                  color: greyTextColor,
                                )),
                            onTap: () {
                              provider
                                  .selectCountry(provider.countryList[index]);
                              Navigator.of(context).pop();
                            });
                      }),
                ),
              ],
            ),
          );
        });
  }
}
