// ignore_for_file: curly_braces_in_flow_control_structures

import 'package:cached_network_image/cached_network_image.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/home_model/ResponseHome.dart' as homeModel;
import 'package:ecommerce/models/product/ProductAttributes.dart';
import 'package:ecommerce/models/product/ProductDetailResponse.dart';
import 'package:ecommerce/models/product/ProductOption.dart';
import 'package:ecommerce/network/api_services.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/provider/product_provider.dart';
import 'package:ecommerce/ui/screens/cart_screen.dart';
import 'package:ecommerce/ui/screens/home_screen.dart';
import 'package:ecommerce/ui/screens/login_screen.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/product_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:hexcolor/hexcolor.dart';
import 'package:provider/provider.dart';

// ignore: must_be_immutable
class ProductDetailScreen extends StatefulWidget {
  String productId;

  ProductDetailScreen({Key? key, required this.productId}) : super(key: key);

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<ProductProvider>(
      create: (BuildContext context) =>
          ProductProvider(context, widget.productId),
      child: Scaffold(
        appBar: null,
        body: Consumer<ProductProvider>(builder: (
          context,
          productProvider,
          snapshot,
        ) {
          return !productProvider.isProductLoaded
              ? const Center(child: CircularProgressIndicator())
              : productProvider.productData == null
                  ? Container()
                  : Padding(
                      padding: const EdgeInsets.only(top: 30),
                      child: Stack(
                        children: [
                          Column(
                            children: [
                              bannerImages(
                                  productProvider.productData!.productImages!),
                              Expanded(
                                child: Container(
                                  decoration: const BoxDecoration(
                                      color: white,
                                      borderRadius: BorderRadius.only(
                                          topLeft: Radius.circular(30),
                                          topRight: Radius.circular(30))),
                                  child: Column(
                                    children: [
                                      Expanded(
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 25, vertical: 15),
                                          child: SingleChildScrollView(
                                            child: Column(
                                              crossAxisAlignment:
                                                  CrossAxisAlignment.start,
                                              children: [
                                                Row(
                                                  children: [
                                                    Expanded(
                                                      child: CustomText(
                                                        text:
                                                            "${productProvider.productData!.data!.productDescription!.name}",
                                                        family: mediumFont,
                                                        color: greyTextColor,
                                                        size: 18,
                                                      ),
                                                    ),
                                                    const SizedBox(
                                                      width: 10,
                                                    ),
                                                    CustomText(
                                                      text: productProvider
                                                              .inStock
                                                          ? "In Stock"
                                                          : "Out of Stock",
                                                      color: productProvider
                                                              .inStock
                                                          ? Colors.greenAccent
                                                          : Colors.red,
                                                      family: regularFont,
                                                      size: 12,
                                                    )
                                                  ],
                                                ),
                                                const SizedBox(
                                                  height: 15,
                                                ),
                                                Row(
                                                  children: [
                                                    Expanded(
                                                      child: productProvider
                                                                  .productData!
                                                                  .productSpecial !=
                                                              null
                                                          ? Row(
                                                              crossAxisAlignment:
                                                                  CrossAxisAlignment
                                                                      .start,
                                                              children: [
                                                                Padding(
                                                                  padding: const EdgeInsets
                                                                          .only(
                                                                      top: 2.0),
                                                                  child: Text(
                                                                    productProvider.selectedProductOption ==
                                                                            null
                                                                        ? '$currency${double.parse(productProvider.productData!.productSpecial!.price!).toStringAsFixed(2)}'
                                                                        : productProvider.selectedProductOption!.price ==
                                                                                null
                                                                            ? '$currency${double.parse(productProvider.productData!.productSpecial!.price!).toStringAsFixed(2)}'
                                                                            : '$currency${(double.parse(productProvider.productData!.productSpecial!.price!) + double.parse(productProvider.selectedProductOption!.price!)).toStringAsFixed(2)}',
                                                                    style: const TextStyle(
                                                                        fontFamily:
                                                                            boldFont,
                                                                        color:
                                                                            primaryColor,
                                                                        fontSize:
                                                                            20),
                                                                  ),
                                                                ),
                                                                Text(
                                                                  productProvider
                                                                              .selectedProductOption ==
                                                                          null
                                                                      ? '$currency${productProvider.productData!.data!.price!}'
                                                                      : productProvider.selectedProductOption!.price ==
                                                                              null
                                                                          ? '$currency${productProvider.productData!.data!.price!}'
                                                                          : '$currency${(double.parse(productProvider.productData!.data!.price!) + double.parse(productProvider.selectedProductOption!.price!)).toStringAsFixed(2)}',
                                                                  style: const TextStyle(
                                                                      fontFamily:
                                                                          boldFont,
                                                                      fontSize:
                                                                          9,
                                                                      color:
                                                                          greyTextColor,
                                                                      decoration:
                                                                          TextDecoration
                                                                              .lineThrough),
                                                                ),
                                                              ],
                                                            )
                                                          : CustomText(
                                                              text: productProvider
                                                                          .selectedProductOption ==
                                                                      null
                                                                  ? '$currency${productProvider.productData!.data!.price!}'
                                                                  : productProvider
                                                                              .selectedProductOption!
                                                                              .price ==
                                                                          null
                                                                      ? '$currency${productProvider.productData!.data!.price!}'
                                                                      : '$currency${(double.parse(productProvider.productData!.data!.price!) + double.parse(productProvider.selectedProductOption!.price!)).toStringAsFixed(2)}',
                                                              family: boldFont,
                                                              color:
                                                                  primaryColor,
                                                              size: 20,
                                                            ),
                                                    ),
                                                    const SizedBox(
                                                      width: 10,
                                                    ),
                                                    Column(
                                                      children: [
                                                        SizedBox(
                                                          width: 75,
                                                          child: RatingBar(
                                                            itemSize: 15,
                                                            initialRating: productProvider
                                                                        .productData!
                                                                        .avgReview !=
                                                                    null
                                                                ? double.parse(
                                                                    productProvider
                                                                        .productData!
                                                                        .avgReview!)
                                                                : 0,
                                                            minRating: 0,
                                                            direction:
                                                                Axis.horizontal,
                                                            itemCount: 5,
                                                            itemPadding:
                                                                const EdgeInsets
                                                                    .all(0),
                                                            wrapAlignment:
                                                                WrapAlignment
                                                                    .start,
                                                            updateOnDrag: false,
                                                            tapOnlyMode: true,
                                                            ignoreGestures:
                                                                true,
                                                            ratingWidget:
                                                                RatingWidget(
                                                              full: const Icon(
                                                                Icons
                                                                    .star_rate_rounded,
                                                                color: Colors
                                                                    .amber,
                                                                size: 18,
                                                              ),
                                                              half: const Icon(
                                                                Icons
                                                                    .star_half_rounded,
                                                                color: Colors
                                                                    .amber,
                                                                size: 18,
                                                              ),
                                                              empty: const Icon(
                                                                Icons
                                                                    .star_border_rounded,
                                                                color:
                                                                    greyTextColor,
                                                                size: 18,
                                                              ),
                                                            ),
                                                            allowHalfRating:
                                                                true,
                                                            // ignore: avoid_returning_null_for_void
                                                            onRatingUpdate:
                                                                (rating) =>
                                                                    null,
                                                          ),
                                                        ),
                                                        CustomText(
                                                          text:
                                                              "(${productProvider.productData!.totalReviews ?? 0} Reviews)",
                                                          color: greyTextColor,
                                                          family: regularFont,
                                                          size: 10,
                                                        ),
                                                      ],
                                                    )
                                                  ],
                                                ),
                                                const SizedBox(
                                                  height: 15,
                                                ),
                                                Row(
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    Expanded(
                                                      child: productProvider
                                                                  .productData!
                                                                  .productOptions !=
                                                              null
                                                          ? getProductOptions(
                                                              productProvider
                                                                  .productData!
                                                                  .productOptions!,
                                                              productProvider)
                                                          : Container(),
                                                    ),
                                                    const SizedBox(
                                                      width: 10,
                                                    ),
                                                    Consumer<HomeProvider>(
                                                        builder: (context,
                                                            homeProvider,
                                                            child) {
                                                      return InkWell(
                                                        onTap: () async {
                                                          if (homeProvider
                                                              .isUserLoggedIn) {
                                                            if (await homeProvider
                                                                .updateDeleteWishListItem(
                                                                    widget
                                                                        .productId)) {
                                                              homeProvider
                                                                  .updateWishListItem(
                                                                      widget
                                                                          .productId);
                                                            }
                                                          } else {
                                                            Navigator.of(context).push(MaterialPageRoute(
                                                                builder: (BuildContext
                                                                        context) =>
                                                                    LoginScreen(
                                                                        provider:
                                                                            homeProvider)));
                                                          }
                                                        },
                                                        child: Card(
                                                            color: homeProvider
                                                                        .isUserLoggedIn &&
                                                                    homeProvider
                                                                        .wishListItems
                                                                        .contains(widget
                                                                            .productId)
                                                                ? primaryColor
                                                                : white,
                                                            shape: RoundedRectangleBorder(
                                                                borderRadius:
                                                                    BorderRadius
                                                                        .circular(
                                                                            50.0)),
                                                            child: Padding(
                                                              padding: const EdgeInsets
                                                                      .symmetric(
                                                                  horizontal:
                                                                      6.0,
                                                                  vertical: 6),
                                                              child: Icon(
                                                                homeProvider.isUserLoggedIn &&
                                                                        homeProvider
                                                                            .wishListItems
                                                                            .contains(widget
                                                                                .productId)
                                                                    ? Icons
                                                                        .favorite
                                                                    : Icons
                                                                        .favorite_border,
                                                                size: 16,
                                                                color: homeProvider
                                                                            .isUserLoggedIn &&
                                                                        homeProvider
                                                                            .wishListItems
                                                                            .contains(widget.productId)
                                                                    ? white
                                                                    : greyTextColor,
                                                              ),
                                                            )),
                                                      );
                                                    }),
                                                  ],
                                                ),
                                                const SizedBox(
                                                  height: 15,
                                                ),
                                                Container(
                                                  width: double.maxFinite,
                                                  height: 0.5,
                                                  color: greyTextColor
                                                      .withOpacity(0.5),
                                                ),
                                                const SizedBox(
                                                  height: 15,
                                                ),
                                                CustomText(
                                                  text: "Description",
                                                  family: mediumFont,
                                                  color: greyTextColor,
                                                  size: 18,
                                                ),
                                                const SizedBox(
                                                  height: 5,
                                                ),
                                                Html(
                                                  shrinkWrap: true,
                                                  style: {
                                                    "body": Style(
                                                        margin: EdgeInsets.zero,
                                                        padding:
                                                            EdgeInsets.zero)
                                                  },
                                                  data: productProvider
                                                              .productData!
                                                              .data !=
                                                          null
                                                      ? productProvider
                                                                  .productData!
                                                                  .data!
                                                                  .productDescription !=
                                                              null
                                                          ? "${productProvider.productData!.data!.productDescription!.description}"
                                                          : ""
                                                      : "",
                                                ),
                                                const SizedBox(
                                                  height: 10,
                                                ),
                                                showSpecification(
                                                    productProvider.productData!
                                                        .productAttributes),
                                                Container(
                                                  width: double.maxFinite,
                                                  height: 0.5,
                                                  color: greyTextColor
                                                      .withOpacity(0.5),
                                                ),
                                                const SizedBox(
                                                  height: 15,
                                                ),
                                                ratingView(productProvider),
                                                const SizedBox(
                                                  height: 20,
                                                ),
                                                if (productProvider
                                                    .productData!
                                                    .relatedProducts!
                                                    .isNotEmpty)
                                                  CustomText(
                                                    text: "Similar Products",
                                                    family: mediumFont,
                                                    color: black,
                                                    size: 14,
                                                  ),
                                                const SizedBox(
                                                  height: 5,
                                                ),
                                                if (productProvider
                                                    .productData!
                                                    .relatedProducts!
                                                    .isNotEmpty)
                                                  SizedBox(
                                                    height: 220,
                                                    child: ListView.separated(
                                                      itemBuilder:
                                                          (BuildContext context,
                                                              int index) {
                                                        homeModel.Products pr =
                                                            homeModel.Products.fromJson(
                                                                productProvider
                                                                    .productData!
                                                                    .relatedProducts![
                                                                        index]
                                                                    .toJson());
                                                        pr.copyWith(
                                                            special: productProvider
                                                                .productData!
                                                                .productSpecial);

                                                        return HomeProductWidget(
                                                          products: pr,
                                                          itemHeight: 220.0,
                                                          isNew: false,
                                                          itemWidth: 220.0,
                                                        );
                                                      },
                                                      shrinkWrap: true,
                                                      scrollDirection:
                                                          Axis.horizontal,
                                                      itemCount: productProvider
                                                          .productData!
                                                          .relatedProducts!
                                                          .length,
                                                      separatorBuilder:
                                                          (BuildContext context,
                                                              int index) {
                                                        return const SizedBox(
                                                          width: 7,
                                                        );
                                                      },
                                                    ),
                                                  ),
                                              ],
                                            ),
                                          ),
                                        ),
                                      ),
                                      Container(
                                        decoration: BoxDecoration(
                                          color: white,
                                          boxShadow: [
                                            BoxShadow(
                                              color:
                                                  Colors.grey.withOpacity(0.5),
                                              spreadRadius: 5,
                                              blurRadius: 2,
                                              offset: const Offset(0,
                                                  5), // changes position of shadow
                                            ),
                                          ],
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.symmetric(
                                              vertical: 10.0, horizontal: 15),
                                          child: Row(
                                            children: [
                                              Expanded(
                                                child: Consumer<HomeProvider>(
                                                    builder: (context,
                                                        homeProvider, child) {
                                                  return CommonButton(
                                                      onPressed: () async {
                                                        //Navigator.of(context).restorablePushAndRemoveUntil((context, arguments) => HomeScreen(), (route) => false)
                                                        if (!homeProvider
                                                            .isUserLoggedIn) {
                                                          final result = await Navigator
                                                                  .of(context)
                                                              .push(
                                                                  MaterialPageRoute(
                                                                      builder: (BuildContext
                                                                              context) =>
                                                                          LoginScreen(
                                                                            provider:
                                                                                homeProvider,
                                                                            navigateToPushBack:
                                                                                true,
                                                                          )));

                                                          if (result == "1" &&
                                                              homeProvider
                                                                  .isUserLoggedIn &&
                                                              productProvider
                                                                  .inStock) {
                                                            productProvider
                                                                .addToCart();
                                                          } else if (!productProvider
                                                              .inStock) {
                                                            AppGlobal.showSnackbar(
                                                                "Out of stock",
                                                                type: 2);
                                                          }
                                                        } else if (productProvider
                                                            .inStock) {
                                                          productProvider
                                                              .addToCart();
                                                        } else if (!productProvider
                                                            .inStock) {
                                                          AppGlobal.showSnackbar(
                                                              "Out of stock",
                                                              type: 2);
                                                        }
                                                      },
                                                      text: CustomText(
                                                        text: "Add to cart",
                                                        color: white,
                                                        family: mediumFont,
                                                      ));
                                                }),
                                              ),
                                              const SizedBox(
                                                width: 10,
                                              ),
                                              Card(
                                                child: Padding(
                                                  padding: const EdgeInsets
                                                          .symmetric(
                                                      horizontal: 8.0,
                                                      vertical: 3),
                                                  child: Row(
                                                    children: [
                                                      CustomText(
                                                        text:
                                                            "${productProvider.selectedQty}",
                                                        color: black,
                                                        family: mediumFont,
                                                      ),
                                                      const SizedBox(
                                                        width: 10,
                                                      ),
                                                      Column(
                                                        children: [
                                                          GestureDetector(
                                                              onTap: () {
                                                                productProvider
                                                                    .changeQty(
                                                                        true);
                                                              },
                                                              child: const Icon(
                                                                Icons
                                                                    .keyboard_arrow_up,
                                                                size: 17,
                                                                color:
                                                                    greyTextColor,
                                                              )),
                                                          const SizedBox(
                                                            height: 2,
                                                          ),
                                                          GestureDetector(
                                                              onTap: () {
                                                                productProvider
                                                                    .changeQty(
                                                                        false);
                                                              },
                                                              child: const Icon(
                                                                Icons
                                                                    .keyboard_arrow_down,
                                                                size: 17,
                                                                color:
                                                                    greyTextColor,
                                                              )),
                                                        ],
                                                      )
                                                    ],
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ],
                          ),
                          Positioned(
                            top: 20,
                            left: 15,
                            child: GestureDetector(
                              onTap: () => Navigator.pop(context),
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  side: const BorderSide(
                                      color: Colors.white, width: 1),
                                  borderRadius: BorderRadius.circular(25),
                                ),
                                child: Container(
                                    height: 30,
                                    width: 30,
                                    child: Padding(
                                      padding: const EdgeInsets.all(5.5),
                                      child: Image.asset(
                                        "assets/images/back.png",
                                        width: 30,
                                        height: 30,
                                      ),
                                    )),
                              ),
                            ),
                          ),
                          Positioned(
                            top: 20,
                            right: 20,
                            child: Consumer<HomeProvider>(
                                builder: (context, homeProvider, child) {
                              return InkWell(
                                onTap: () {
                                  if (homeProvider.cartCount > 0) {
                                    Navigator.of(context).push(
                                        MaterialPageRoute(
                                            builder: (BuildContext context) =>
                                                const CartScreen()));
                                  } else {
                                    AppGlobal.showSnackbar("Cart is empty",
                                        type: 2);
                                  }
                                },
                                child: Stack(
                                  children: [
                                    Padding(
                                      padding: const EdgeInsets.symmetric(
                                              horizontal: 10.0)
                                          .copyWith(bottom: 10),
                                      child: Image.asset(
                                        "assets/images/bottomtab/Bottom_cart.png",
                                        width: 30,
                                        height: 30,
                                      ),
                                    ),
                                    if (homeProvider.cartCount > 0)
                                      Positioned(
                                        right: 10,
                                        top: 0,
                                        child: Container(
                                          decoration: const BoxDecoration(
                                              color: white,
                                              shape: BoxShape.circle,
                                              boxShadow: [
                                                BoxShadow(
                                                  color: Colors.grey,
                                                  blurRadius: 1.0,
                                                ),
                                              ]),
                                          child: Padding(
                                            padding: const EdgeInsets.all(5.0),
                                            child: CustomText(
                                              text:
                                                  "${homeProvider.cartCount < 100 ? homeProvider.cartCount : "99+"}",
                                              color: primaryColor,
                                              size: 8,
                                            ),
                                          ),
                                        ),
                                      ),
                                  ],
                                ),
                              );
                            }),
                          ),
                        ],
                      ),
                    );
        }),
      ),
    );
  }

  Widget bannerImages(List<ProductImages> list) {
    return CarouselSlider(
        options: CarouselOptions(
          aspectRatio: 16 / 14,
          viewportFraction: 1,
          initialPage: 0,
          enableInfiniteScroll: true,
          reverse: false,
          autoPlay: true,

          autoPlayInterval: const Duration(seconds: 4),
          autoPlayAnimationDuration: const Duration(milliseconds: 1000),
          autoPlayCurve: Curves.fastOutSlowIn,
          enlargeCenterPage: true,
          // onPageChanged: callbackFunction,
          scrollDirection: Axis.horizontal,
        ),
        items: list
            .map((item) => Padding(
                  padding: const EdgeInsets.only(
                      left: 25.0, right: 25, top: 20, bottom: 5),
                  child: CachedNetworkImage(
                    imageUrl:
                        "${ApiServices.uploadURL}${ApiServices.uploadProductURL}${item.image}",
                    imageBuilder: (context, imageProvider) => Container(
                      decoration: BoxDecoration(
                        shape: BoxShape.rectangle,
                        borderRadius:
                            const BorderRadius.all(Radius.circular(10)),
                        image: DecorationImage(
                            image: imageProvider, fit: BoxFit.cover),
                      ),
                    ),
                    placeholder: (context, url) => Container(
                      color: grey,
                    ),
                    errorWidget: (context, url, error) =>
                        const Icon(Icons.error),
                  ),
                ))
            .toList());
  }

  ratingView(ProductProvider productProvider) {
    return SizedBox(
        width: double.maxFinite,
        child: Column(
          children: [
            CustomText(
              text: "Overall Rating",
              family: regularFont,
              color: greyTextColor,
              size: 16,
            ),
            const SizedBox(
              height: 5,
            ),
            CustomText(
              text: productProvider.productData!.avgReview ?? "0",
              family: mediumFont,
              color: black,
              size: 18,
            ),
            const SizedBox(
              height: 10,
            ),
            SizedBox(
              width: 95,
              child: RatingBar(
                itemSize: 18,
                initialRating: productProvider.productData!.avgReview != null
                    ? double.parse(productProvider.productData!.avgReview!)
                    : 0,
                minRating: 0,
                direction: Axis.horizontal,
                itemCount: 5,
                itemPadding: const EdgeInsets.all(0),
                wrapAlignment: WrapAlignment.start,
                updateOnDrag: false,
                tapOnlyMode: true,
                ignoreGestures: true,
                ratingWidget: RatingWidget(
                  full: const Icon(
                    Icons.star_rate_rounded,
                    color: Colors.amber,
                    size: 18,
                  ),
                  half: const Icon(
                    Icons.star_half_rounded,
                    color: Colors.amber,
                    size: 18,
                  ),
                  empty: const Icon(
                    Icons.star_border_rounded,
                    color: greyTextColor,
                    size: 18,
                  ),
                ),
                allowHalfRating: true,
                // ignore: avoid_returning_null_for_void
                onRatingUpdate: (rating) => null,
              ),
            ),
            const SizedBox(
              height: 3,
            ),
            CustomText(
              text:
                  "Based on ${productProvider.productData!.totalReviews ?? "0"} Review",
              family: regularFont,
              color: greyTextColor,
              size: 10,
            ),
            const SizedBox(
              height: 10,
            ),
            ratingLine(
                "Excellent",
                double.parse(productProvider.productData!.star5!) / 100,
                const Color(0xff3ad35c)),
            const SizedBox(
              height: 5,
            ),
            ratingLine(
                "Good",
                double.parse(productProvider.productData!.star4!) / 100,
                const Color(0xffefcd19)),
            const SizedBox(
              height: 5,
            ),
            ratingLine(
                "Average",
                double.parse(productProvider.productData!.star3!) / 100,
                const Color(0xffffce1f)),
            const SizedBox(
              height: 5,
            ),
            ratingLine(
                "Poor",
                double.parse(productProvider.productData!.star2!) / 100,
                const Color(0xffe9961a)),
            const SizedBox(
              height: 5,
            ),
            ratingLine(
                "Very Bad",
                double.parse(productProvider.productData!.star1!) / 100,
                const Color(0xffe83328)),
            const SizedBox(
              height: 5,
            ),
          ],
        ));
  }

  ratingLine(String s, double d, Color colorValue) {
    return Row(
      children: [
        Expanded(
          flex: 1,
          child: CustomText(
            text: s,
            family: regularFont,
            color: greyTextColor,
            size: 14,
          ),
        ),
        const SizedBox(
          width: 5,
        ),
        Expanded(
          flex: 3,
          child: SizedBox(
            width: double.maxFinite,
            height: 5,
            child: ClipRRect(
              borderRadius: const BorderRadius.all(Radius.circular(5)),
              child: LinearProgressIndicator(
                value: d,
                valueColor: AlwaysStoppedAnimation<Color>(colorValue),
                backgroundColor: backgroundColor,
              ),
            ),
          ),
        ),
      ],
    );
  }

  showSpecification(Map<String, List<ProductAttributes>>? productAttributes) {
    return productAttributes != null
        ? Container()
        : productAttributes!.isEmpty
            ? Container()
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Container(
                    width: double.maxFinite,
                    height: 0.5,
                    color: greyTextColor.withOpacity(0.5),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomText(
                    text: "Specification",
                    family: mediumFont,
                    color: greyTextColor,
                    size: 14,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  ListView.separated(
                    shrinkWrap: true,
                    padding: EdgeInsets.zero,
                    physics: const NeverScrollableScrollPhysics(),
                    itemBuilder: (BuildContext context, int index) {
                      String key = productAttributes.keys.toList()[index];
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: double.maxFinite,
                            padding: const EdgeInsets.symmetric(
                                horizontal: 5, vertical: 10),
                            color: commonBackgroundColor,
                            child: Text(
                              key,
                              style: const TextStyle(
                                  fontSize: 16,
                                  color: greyTextColor,
                                  fontFamily: mediumFont),
                            ),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          ListView.separated(
                            shrinkWrap: true,
                            padding: EdgeInsets.zero,
                            physics: const NeverScrollableScrollPhysics(),
                            itemBuilder: (BuildContext context, int index) {
                              ProductAttributes attributes =
                                  productAttributes[key]![index];
                              return Row(
                                children: [
                                  Expanded(
                                    flex: 2,
                                    child: Text(
                                      "${attributes.name}",
                                      style: const TextStyle(
                                          fontSize: 12,
                                          color: greyTextColor,
                                          fontFamily: regularFont),
                                    ),
                                  ),
                                  const SizedBox(
                                    width: 10,
                                  ),
                                  Expanded(
                                    flex: 5,
                                    child: Text(
                                      "${attributes.text}",
                                      style: const TextStyle(
                                          fontSize: 12,
                                          color: greyTextColor,
                                          fontFamily: regularFont),
                                    ),
                                  ),
                                ],
                              );
                            },
                            separatorBuilder:
                                (BuildContext context, int index) {
                              return const SizedBox(
                                height: 10,
                              );
                            },
                            itemCount: productAttributes[key]!.length,
                          ),
                        ],
                      );
                    },
                    separatorBuilder: (BuildContext context, int index) {
                      return const SizedBox(
                        height: 10,
                      );
                    },
                    itemCount: productAttributes.keys.length,
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                ],
              );
  }

  getProductOptions(Map<String, List<ProductOption>> productOptionsMap,
      ProductProvider productProvider) {
    return ListView.separated(
      shrinkWrap: true,
      padding: EdgeInsets.zero,
      physics: const NeverScrollableScrollPhysics(),
      separatorBuilder: (BuildContext context, int index) {
        return const SizedBox(
          height: 15,
        );
      },
      itemCount: productOptionsMap.keys.length,
      itemBuilder: (BuildContext context, int index) {
        String key = productOptionsMap.keys.toList()[index];
        return Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CustomText(
              text: key,
              family: regularFont,
              color: greyTextColor,
              size: 16,
            ),
            const SizedBox(
              width: 10,
            ),
            Expanded(
              child: SizedBox(
                height: 38,
                child: ListView.separated(
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemBuilder: (BuildContext context, int index) {
                    ProductOption productOption =
                        productOptionsMap[key]![index];

                    // print("====Color=== ${HexColor(productOption.colorCode!)}");
                    return InkWell(
                      onTap: () {
                        productProvider.selectNewProductOption(productOption);
                      },
                      child: productOption.type == "Color"
                          ? Center(
                              child: Column(
                                mainAxisSize: MainAxisSize.min,
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Expanded(
                                    child: Stack(
                                      children: [
                                        Container(
                                          width: 40,
                                          //height: 20,
                                          decoration: BoxDecoration(
                                              borderRadius:
                                                  const BorderRadius.all(
                                                      Radius.circular(5)),
                                              color: HexColor(
                                                  productOption.colorCode!)),
                                          padding: const EdgeInsets.symmetric(
                                              horizontal: 10.0, vertical: 4),
                                        ),
                                        if (productProvider
                                                .selectedProductOption !=
                                            null)
                                          if (productProvider
                                                  .selectedProductOption ==
                                              productOption)
                                            Positioned.fill(
                                              child: Align(
                                                alignment: Alignment.center,
                                                child: Icon(
                                                  Icons.check_circle_rounded,
                                                  color: HexColor(productOption
                                                              .colorCode!) ==
                                                          const Color(
                                                              0xffffffff)
                                                      ? black
                                                      : white,
                                                  size: 17,
                                                ),
                                              ),
                                            )
                                      ],
                                    ),
                                  ),
                                  productOption.price != null
                                      ? CustomText(
                                          text: "+${productOption.price}",
                                          size: 10,
                                          family: regularFont,
                                          color: greyTextColor,
                                        )
                                      : CustomText(
                                          text: "",
                                          size: 10,
                                          family: regularFont,
                                          color: greyTextColor,
                                        )
                                ],
                              ),
                            )
                          : Center(
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Container(
                                      decoration: BoxDecoration(
                                          borderRadius: const BorderRadius.all(
                                              Radius.circular(5)),
                                          border: Border.all(
                                              color: productProvider
                                                          .selectedProductOption !=
                                                      null
                                                  ? productProvider
                                                              .selectedProductOption ==
                                                          productOption
                                                      ? primaryColor
                                                      : greyTextColor
                                                          .withOpacity(0.5)
                                                  : greyTextColor
                                                      .withOpacity(0.5),
                                              width: 1),
                                          color: backgroundColor),
                                      padding: const EdgeInsets.symmetric(
                                          horizontal: 10.0, vertical: 4),
                                      child: CustomText(
                                        text: "${productOption.label}",
                                        size: 10,
                                        family: regularFont,
                                        color: productProvider
                                                    .selectedProductOption !=
                                                null
                                            ? productProvider
                                                        .selectedProductOption ==
                                                    productOption
                                                ? primaryColor
                                                : greyTextColor
                                            : greyTextColor,
                                      )),
                                  productOption.price != null
                                      ? CustomText(
                                          text: "+${productOption.price}",
                                          size: 10,
                                          family: regularFont,
                                          color: greyTextColor,
                                        )
                                      : CustomText(
                                          text: "",
                                          size: 10,
                                          family: regularFont,
                                          color: greyTextColor,
                                        )
                                ],
                              ),
                            ),
                    );
                  },
                  itemCount: productOptionsMap[key]!.length,
                  separatorBuilder: (BuildContext context, int index) {
                    return const SizedBox(
                      width: 15,
                    );
                  },
                ),
              ),
            ),
            const SizedBox(
              width: 10,
            ),
            const Icon(
              Icons.navigate_next,
              color: Colors.black,
            )
          ],
        );
      },
    );
  }
}
