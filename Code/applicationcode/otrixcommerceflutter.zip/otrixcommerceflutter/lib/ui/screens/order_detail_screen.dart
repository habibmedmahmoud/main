import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/order/order_item_data.dart';
import 'package:ecommerce/models/order/order_product.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_form_field.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/order_detail_product_widgte.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';

class OrderDetailScreen extends StatefulWidget {
  OrderItem orderItem;

  OrderDetailScreen({Key? key, required this.orderItem}) : super(key: key);

  @override
  State<OrderDetailScreen> createState() => _OrderDetailScreenState();
}

class _OrderDetailScreenState extends State<OrderDetailScreen> {
  late OrderItem orderItem;

  @override
  void initState() {
    orderItem = widget.orderItem;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      
      body: SafeArea(
        child: Padding(
            padding: const EdgeInsets.only(
                left: 15.0, right: 15, top: 15, bottom: 5),
            child:
                Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              const SizedBox(
                height: 15,
              ),
              Row(
                children: [
                  GestureDetector(
                    onTap: () => Navigator.pop(context),
                    child: Card(
                      shape: RoundedRectangleBorder(
                        side: const BorderSide(color: Colors.white, width: 1),
                        borderRadius: BorderRadius.circular(25),
                      ),
                      child: SizedBox(
                          height: 30,
                          width: 30,
                          child: Padding(
                            padding: const EdgeInsets.all(5.5),
                            child: Image.asset(
                              "assets/images/back.png",
                              width: 30,
                              height: 30,
                            ),
                          )),
                    ),
                  ),
                  const SizedBox(
                    width: 20,
                  ),
                  Expanded(
                    child: CustomText(
                      text: "My Orders",
                      color: black,
                      family: boldFont,
                      size: 22,
                    ),
                  ),
                  const SizedBox(
                    width: 10,
                  ),
                ],
              ),
              const SizedBox(
                height: 20,
              ),
              Expanded(
                child: SingleChildScrollView(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      CustomText(
                        text: "View Orders Details",
                        color: black,
                        family: mediumFont,
                        size: 16,
                      ),
                      OrderDetailView("Order Date", "${orderItem.orderDate}"),
                      OrderDetailView(
                          "Payment Method", "${orderItem.paymentMethod}"),
                      OrderDetailView("Order", "#${orderItem.id}"),
                      OrderDetailView("Order Total", "$currency${orderItem.total}"),
                      const SizedBox(
                        height: 10,
                      ),
                      CustomText(
                        text: "Shipping Address",
                        color: black,
                        family: mediumFont,
                        size: 16,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      AddressCard(),
                      const SizedBox(
                        height: 10,
                      ),
                      CustomText(
                        text: "Order Product List",
                        color: black,
                        family: mediumFont,
                        size: 16,
                      ),
                      ListView.separated(
                        padding: const EdgeInsets.all(10),
                        shrinkWrap: true,
                        physics: const NeverScrollableScrollPhysics(),
                        itemBuilder: (context, index) {
                          return OrderDetailProductWidget(
                            orderItem.products![index],
                            onRateClick: rateDialog,
                          );
                        },
                        itemCount: orderItem.products!.length,
                        separatorBuilder: (BuildContext context, int index) {
                          return const SizedBox(
                            height: 15,
                          );
                        },
                      ),
                      const SizedBox(
                        height: 20,
                      ),
                      CustomText(
                        text: "Order Product Summary",
                        color: black,
                        family: mediumFont,
                        size: 16,
                      ),
                      const SizedBox(
                        height: 10,
                      ),
                      OrderDetailView("Item Count", orderItem.products != null ?"${orderItem.products!.length}" : "0"),
                      OrderDetailView("Tax", orderItem.taxAmount != null ? "$currency${double.parse(orderItem.taxAmount!).toStringAsFixed(2)}" : "0"),
                      OrderDetailView("Discount", orderItem.discount != null ? "$currency${double.parse(orderItem.discount!).toStringAsFixed(2)}" : "0"),
                      OrderDetailView("Shipping Charges", orderItem.shippingCharge != null ? "$currency${double.parse(orderItem.shippingCharge!).toStringAsFixed(2)}" : "0"),
                      orderDetailTotalView("Order Total", orderItem.total != null ? "$currency${double.parse(orderItem.total!).toStringAsFixed(2)}" : "0"),
                    ],
                  ),
                ),
              ),
            ])),
      ),
    );
  }

  // ignore: non_constant_identifier_names
  OrderDetailView(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Expanded(
            flex: 4,
            child: CustomText(
              text: title,
              color: greyTextColor,
              family: mediumFont,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          Expanded(
            flex: 7,
            child: CustomText(
              text: value,
              color: black,
              family: mediumFont,
            ),
          ),
        ],
      ),
    );
  }

  Widget orderDetailTotalView(String title, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.start,
        children: [
          Expanded(
            flex: 4,
            child: CustomText(
              text: title,
              color: primaryColor,
              size: 18,
              family: mediumFont,
            ),
          ),
          const SizedBox(
            width: 10,
          ),
          Expanded(
            flex: 7,
            child: CustomText(
              text: value,
              color: primaryColor,
              size: 18,
              family: mediumFont,
            ),
          ),
        ],
      ),
    );
  }

  // ignore: non_constant_identifier_names
  AddressCard() {
    return Container(
      width: double.maxFinite,
      decoration: BoxDecoration(
          border: Border.all(color: greyTextColor.withOpacity(0.2), width: 0.5),
          color: white,
          borderRadius: const BorderRadius.all(Radius.circular(10))),
      padding: const EdgeInsets.symmetric(horizontal: 10.0, vertical: 5),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 5.0, vertical: 10),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            CustomText(
              text: "${orderItem.shippingName}",
              color: black,
              family: regularFont,
              size: 13,
            ),
            CustomText(
              text: "${orderItem.shippingAddress1}",
              color: black,
              family: regularFont,
              size: 13,
            ),
            CustomText(
              text: "${orderItem.shippingAddress2} , ${orderItem.shippingCity}",
              color: black,
              family: regularFont,
              size: 13,
            ),
            CustomText(
              text: "${orderItem.shippingPostcode}",
              color: black,
              family: regularFont,
              size: 13,
            ),
          ],
        ),
      ),
    );
  }

  rateDialog() {
    Dialog errorDialog = Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      //this right here
      backgroundColor: Colors.transparent,
      child: Stack(
        children: [
          //SizedBox(),
          Container(
            width: double.maxFinite,
            color: white,
            margin: const EdgeInsets.symmetric(vertical: 10),
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 15),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Align(
                    alignment: Alignment.centerRight,
                    child: InkWell(
                      onTap: () => Navigator.pop(context),
                      child: Image.asset(
                        "assets/images/cancel.png",
                        height: 15,
                        width: 15,
                      ),
                    )),
                const SizedBox(
                  height: 5,
                ),
                CustomText(
                  text: 'Rate Product Now!!',
                  family: mediumFont,
                  size: 18,
                  color: black,
                ),
                const SizedBox(
                  height: 10,
                ),
                RatingBar(
                  itemSize: 25,
                  initialRating: 0,
                  glow: false,
                  minRating: 0,
                  direction: Axis.horizontal,
                  itemCount: 5,
                  itemPadding: const EdgeInsets.all(3),
                  wrapAlignment: WrapAlignment.start,
                  updateOnDrag: true,
                  ratingWidget: RatingWidget(
                    full: const Icon(
                      Icons.star_rate_rounded,
                      color: Colors.amber,
                      size: 18,
                    ),
                    half: const Icon(
                      Icons.star_half_rounded,
                      color: Colors.amber,
                      size: 18,
                    ),
                    empty: const Icon(
                      Icons.star_border_rounded,
                      color: greyTextColor,
                      size: 18,
                    ),
                  ),
                  allowHalfRating: true,
                  // ignore: avoid_returning_null_for_void
                  onRatingUpdate: (rating) => null,
                ),
                const SizedBox(
                  height: 10,
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 15.0),
                  child: CustomTextFormField(
                    hint: "Comment",
                    maxLines: 2,
                    textInputType: TextInputType.multiline,
                    textInputAction: TextInputAction.newline,
                    validator: (val) => AppGlobal().mobileNumberValidator(val),
                  ),
                ),
                const Padding(padding: EdgeInsets.only(top: 35.0)),
              ],
            ),
          ),
          Positioned.fill(
              bottom: 0,
              left: 30,
              right: 30,
              child: Align(
                  alignment: Alignment.bottomCenter,
                  child: CommonButton(
                    height: 40,
                    onPressed: () {},
                    text: const Text("Submit"),
                  )))
        ],
      ),
    );
    showDialog(
        context: context, builder: (BuildContext context) => errorDialog);
  }
}
