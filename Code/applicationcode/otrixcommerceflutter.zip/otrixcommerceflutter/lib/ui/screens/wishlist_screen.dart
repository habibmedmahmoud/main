import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/provider/wishlist_provider.dart';
import 'package:ecommerce/ui/screens/login_screen.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/wishlist_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class WishlistScreen extends StatelessWidget {
  const WishlistScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      
      body: SafeArea(
        child: Consumer<HomeProvider>(builder: (context, homeProvider, child) {
          return homeProvider.isUserLoggedIn
              ? ChangeNotifierProvider<WishListProvider>(
                  create: (context) => WishListProvider(context),
                  child: Consumer<WishListProvider>(
                      builder: (context, provider, child) {
                    return Padding(
                      padding: const EdgeInsets.only(
                          left: 15.0, right: 15, top: 15, bottom: 5),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(
                            height: 15,
                          ),
                          Row(
                            children: [
                              GestureDetector(
                                onTap: () => Navigator.pop(context),
                                child: Card(
                                  shape: RoundedRectangleBorder(
                                    side: const BorderSide(
                                        color: Colors.white, width: 1),
                                    borderRadius: BorderRadius.circular(25),
                                  ),
                                  child: SizedBox(
                                      height: 30,
                                      width: 30,
                                      child: Padding(
                                        padding: const EdgeInsets.all(5.5),
                                        child: Image.asset(
                                          "assets/images/back.png",
                                          width: 30,
                                          height: 30,
                                        ),
                                      )),
                                ),
                              ),
                              const SizedBox(
                                width: 20,
                              ),
                              Expanded(
                                child: CustomText(
                                  text: "Wishlist",
                                  color: black,
                                  family: boldFont,
                                  size: 26,
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          Expanded(
                            child: provider.isLoading
                                ? const Center(
                                    child: CircularProgressIndicator(
                                      color: primaryColor,
                                    ),
                                  )
                                : ListView.separated(
                                    itemCount: provider.wishListProducts.length,
                                    shrinkWrap: true,
                                    separatorBuilder:
                                        (BuildContext context, int index) {
                                      return const SizedBox(
                                        height: 10,
                                      );
                                    },
                                    itemBuilder:
                                        (BuildContext context, int index) {
                                      return WishlistItemWidget(
                                        productData:
                                            provider.wishListProducts[index],
                                        itemClick: () {},
                                        deleteClick: () async {
                                          if (await provider
                                              .updateDeleteWishListItem(provider
                                                  .wishListProducts[index]
                                                  .productDescription!
                                                  .productId!)) {
                                            homeProvider.updateWishListItem(
                                                provider.wishListProducts[index]
                                                    .productDescription!.productId!
                                                    );
                                            provider.deleteItem(provider
                                                .wishListProducts[index]);
                                          }
                                        },
                                      );
                                    },
                                  ),
                          )
                        ],
                      ),
                    );
                  }),
                )
              : LoginScreen(provider: homeProvider);
        }),
      ),
    );
  }
}
