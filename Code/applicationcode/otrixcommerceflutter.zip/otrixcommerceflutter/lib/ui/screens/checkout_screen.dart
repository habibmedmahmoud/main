import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/checkout_provider.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/ui/widgets/address_item_widget.dart';
import 'package:ecommerce/ui/widgets/checkout_address_view.dart';
import 'package:ecommerce/ui/widgets/checkout_fingure_custom_paint.dart';
import 'package:ecommerce/ui/widgets/checkout_payment_view.dart';
import 'package:ecommerce/ui/widgets/checkout_product_widget.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_form_field.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/payment_metod_item.dart';
import 'package:ecommerce/ui/widgets/shipping_method_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutter_vector_icons/flutter_vector_icons.dart';
import 'package:provider/provider.dart';

class CheckoutScreen extends StatefulWidget {
  const CheckoutScreen({Key? key}) : super(key: key);

  @override
  State<CheckoutScreen> createState() => _CheckoutScreenState();
}

class _CheckoutScreenState extends State<CheckoutScreen> {
  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<CheckoutProvider>(
      create: (context) => CheckoutProvider(context),
      child: Scaffold(
        appBar: null,
        
        body: SafeArea(
          child:
              Consumer<CheckoutProvider>(builder: (context, provider, child) {
            return Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15, top: 15, bottom: 5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 15,
                  ),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Card(
                          shape: RoundedRectangleBorder(
                            side:
                                const BorderSide(color: Colors.white, width: 1),
                            borderRadius: BorderRadius.circular(25),
                          ),
                          child: SizedBox(
                              height: 30,
                              width: 30,
                              child: Padding(
                                padding: const EdgeInsets.all(5.5),
                                child: Image.asset(
                                  "assets/images/back.png",
                                  width: 30,
                                  height: 30,
                                ),
                              )),
                        ),
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      Expanded(
                        child: CustomText(
                          text: "Checkout",
                          color: black,
                          family: boldFont,
                          size: 26,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 25,
                  ),
                  Row(
                    children: [
                      const SizedBox(
                        width: 15,
                      ),
                      Expanded(
                        child: CustomPaint(
                          painter: CheckoutCustomPaint(
                              provider.checkoutSelection == 0
                                  ? primaryColor
                                  : Colors.transparent),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            // color: white,
                            child: Center(
                                child: CustomText(
                              text: "ADDRESS",
                              color: provider.checkoutSelection == 0
                                  ? primaryColor
                                  : greyTextColor,
                              family: mediumFont,
                            )),
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 10,
                      ),
                      Expanded(
                        child: CustomPaint(
                          painter: CheckoutCustomPaint(
                              provider.checkoutSelection == 1
                                  ? primaryColor
                                  : Colors.transparent),
                          child: Container(
                            padding: const EdgeInsets.symmetric(vertical: 10),
                            // color: white,
                            child: Center(
                                child: CustomText(
                              text: "PAYMENT",
                              color: provider.checkoutSelection == 1
                                  ? primaryColor
                                  : greyTextColor,
                              family: mediumFont,
                            )),
                          ),
                        ),
                      ),
                      const SizedBox(
                        width: 15,
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 25,
                  ),
                  Expanded(
                    child: provider.checkoutLoading
                        ? const Center(
                            child: CircularProgressIndicator(),
                          )
                        : provider.checkoutSelection == 0
                            ? CheckoutAddressView(provider)
                            : CheckoutPaymentView(provider),
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }
}
