import 'dart:convert';

import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/filter_provider.dart';
import 'package:ecommerce/provider/product_list_provider.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/product_widget.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import 'package:syncfusion_flutter_sliders/sliders.dart';

// ignore: must_be_immutable
class FilterScreen extends StatelessWidget {
  int selectedPrice = 0;
  int selectedRangeStart = 0;
  int selectedRangeEnd = 0;
  double rageLimit = 100;
  int selectedStar = 0;

  final GlobalKey _globalKey = GlobalKey();

  FilterScreen({
    Key? key,
    required this.selectedPrice,
    required this.selectedRangeStart,
    required this.selectedRangeEnd,
    required this.selectedStar,
    required this.rageLimit,
  }) : super(key: key);

  double itemWidth = 0;

  @override
  Widget build(BuildContext context) {
    itemWidth = (MediaQuery.of(context).size.width / 2);
    return ChangeNotifierProvider<FilterProductListProvider>(
      create: (context) => FilterProductListProvider(
          selectedPrice: selectedPrice,
          selectedRangeEnd: selectedRangeEnd,
          selectedRangeStart: selectedRangeStart,
          selectedStar: selectedStar,
          rageLimit: rageLimit),
      child: Scaffold(
        appBar: null,
        
        body: SafeArea(
          child: Consumer<FilterProductListProvider>(
              builder: (context, provider, child) {
            return Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15, top: 15, bottom: 5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 15,
                  ),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Card(
                          shape: RoundedRectangleBorder(
                            side:
                                const BorderSide(color: Colors.white, width: 1),
                            borderRadius: BorderRadius.circular(25),
                          ),
                          child: SizedBox(
                              height: 30,
                              width: 30,
                              child: Padding(
                                padding: const EdgeInsets.all(5.5),
                                child: Image.asset(
                                  "assets/images/back.png",
                                  width: 30,
                                  height: 30,
                                ),
                              )),
                        ),
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      Expanded(
                        child: CustomText(
                          text: "Filter",
                          color: black,
                          family: boldFont,
                          size: 26,
                        ),
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      GestureDetector(
                        onTap: (){
                          Map<String, dynamic> data = {
                            "selectedPrice": 0,
                            "selectedRangeStart": 0,
                            "selectedRangeEnd": 0,
                            "selectedStar": 0,
                          };
                          Navigator.pop(context, jsonEncode(data));
                        },
                        child: CustomText(
                          text: "CLEAR ALL",
                          color: primaryColor,
                          family: regularFont,
                          size: 12,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(
                    height: 25,
                  ),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          CustomText(
                            text: "Price:",
                            color: black,
                            family: mediumFont,
                            size: 16,
                          ),
                          Wrap(
                            children: listOfPrices(provider),
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Container(
                            width: double.maxFinite,
                            height: 0.3,
                            color: greyTextColor.withOpacity(0.5),
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          CustomText(
                            text: "Price Range:",
                            color: black,
                            family: mediumFont,
                            size: 16,
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          rangeSliderWidget(provider),
                          const SizedBox(
                            height: 10,
                          ),
                          Container(
                            width: double.maxFinite,
                            height: 0.3,
                            color: greyTextColor.withOpacity(0.5),
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          CustomText(
                            text: "Rating:",
                            color: black,
                            family: mediumFont,
                            size: 16,
                          ),
                          const SizedBox(
                            height: 15,
                          ),
                          Column(
                            key: _globalKey,
                            mainAxisSize: MainAxisSize.min,
                            children: listOfRatings(provider),
                          ),
                        ],
                      ),
                    ),
                  ),
                  if (provider.isDataChanged)
                    const SizedBox(
                      height: 10,
                    ),
                  if (provider.isDataChanged)
                    CommonButton(
                        onPressed: () {
                          Map<String, dynamic> data = {
                            "selectedPrice": provider.selectedPrice,
                            "selectedRangeStart": provider.selectedRangeStart,
                            "selectedRangeEnd": provider.selectedRangeEnd,
                            "selectedStar": provider.selectedStar,
                          };
                          Navigator.pop(context, jsonEncode(data));
                        },
                        text: CustomText(
                          text: 'Apply Filter',
                          color: white,
                          weight: FontWeight.bold,
                          family: boldFont,
                          size: 18,
                        )),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }

  List<Widget> listOfPrices(FilterProductListProvider provider) {
    List<int> text = [49, 99, 149, 199, 249, 299, 349, 399, 449, 499, 549, 599];
    return List.generate(text.length, (index) {
      return Padding(
        padding: const EdgeInsets.all(5.0),
        child: InkWell(
          onTap: () => provider.setSelectedPrice(text[index]),
          child: Container(
              decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(5)),
                  color: white,
                  border: Border.all(
                      color: provider.selectedPrice == text[index]
                          ? primaryColor
                          : greyTextColor.withOpacity(0.3))),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 8.0, horizontal: 10),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (provider.selectedPrice == text[index])
                      Image.asset(
                        "assets/images/check.png",
                        height: 15,
                        width: 15,
                      ),
                    if (provider.selectedPrice == text[index])
                      const SizedBox(
                        width: 5,
                      ),
                    CustomText(
                      text: "Under $currency${text[index]}",
                      color: black,
                      family: mediumFont,
                      size: 13,
                    ),
                  ],
                ),
              )),
        ),
      );
    });
  }

  List<Widget> listOfRatings(FilterProductListProvider provider) {
    List<int> text = [1, 2, 3, 4, 5];
    return List.generate(text.length, (index) {
      return Padding(
        padding: const EdgeInsets.all(2.0),
        child: InkWell(
          onTap: () => provider.setSelectedRating(text[index]),
          child: Container(
              width: 200,
              decoration: BoxDecoration(
                  borderRadius: const BorderRadius.all(Radius.circular(5)),
                  color: white,
                  border: Border.all(
                      color: provider.selectedPrice == text[index]
                          ? primaryColor
                          : Colors.transparent)),
              child: Padding(
                padding:
                    const EdgeInsets.symmetric(vertical: 8.0, horizontal: 10),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (provider.selectedStar == text[index])
                      Image.asset(
                        "assets/images/check.png",
                        height: 15,
                        width: 15,
                      ),
                    if (provider.selectedStar == text[index])
                      const SizedBox(
                        width: 5,
                      ),
                    Row(
                      children: List.generate(text[index], (index) {
                        return const Icon(
                          Icons.star,
                          color: Colors.amberAccent,
                          size: 20,
                        );
                      }),
                    )
                  ],
                ),
              )),
        ),
      );
    });
  }

  rangeSliderWidget(FilterProductListProvider provider) {
    return SizedBox(
      width: double.maxFinite,
      child: SfRangeSlider(
        max: rageLimit,
        min: 0,
        shouldAlwaysShowTooltip: true,
        onChanged: provider.updateRangeValue,
        tooltipShape: const SfRectangularTooltipShape(),
        stepSize: 1,
        activeColor: primaryColor,
        inactiveColor: greyTextColor.withOpacity(0.2),
        enableTooltip: true,
        endThumbIcon: Container(
          decoration: const BoxDecoration(shape: BoxShape.circle, color: white),
        ),
        startThumbIcon: Container(
          decoration: const BoxDecoration(shape: BoxShape.circle, color: white),
        ),
        values: SfRangeValues(
            provider.selectedRangeStart.round(),
            rageLimit > provider.selectedRangeEnd
                ? provider.selectedRangeEnd.round()
                : rageLimit),
      ),
    );

    /* return RangeSlider(
      values: RangeValues(
          provider.selectedRangeStart,
          rageLimit > provider.selectedRangeEnd
              ? provider.selectedRangeEnd
              : rageLimit),
      max: rageLimit,
      activeColor: Colors.red,

      divisions: rageLimit.round(),
      labels: RangeLabels(
        provider.selectedRangeStart.round().toString(),
        provider.selectedRangeEnd.round().toString(),
      ),
      onChanged: provider.updateRangeValue,
    );*/
  }
}
