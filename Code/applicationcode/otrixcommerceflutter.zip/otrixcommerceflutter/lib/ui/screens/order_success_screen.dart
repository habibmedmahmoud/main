// ignore_for_file: no_logic_in_create_state, must_be_immutable, use_build_context_synchronously

import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/dashboard_provider.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/ui/screens/dashboard_screen.dart';
import 'package:ecommerce/ui/screens/my_orders_screen.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class OrderSuccessScreen extends StatefulWidget {
  String orderId;

  OrderSuccessScreen({Key? key, required this.orderId}) : super(key: key);

  @override
  State<OrderSuccessScreen> createState() => _OrderSuccessScreenState(orderId);
}

class _OrderSuccessScreenState extends State<OrderSuccessScreen> {
  String orderId;

  _OrderSuccessScreenState(this.orderId);

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () {
        Provider.of<DashboardProvider>(context, listen: false)
            .changeViewNotifier(DashboardScreenView.HOME);
        Provider.of<HomeProvider>(context, listen: false).updateCartCount(0);
        Navigator.of(context).pushReplacement(MaterialPageRoute(
            builder: (BuildContext context) => const DashboardScreen()));
        return Future(() => false);
      },
      child: Scaffold(
          appBar: null,
          body:
              Consumer<DashboardProvider>(builder: (context, provider, child) {
            return SafeArea(
                child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 20),
              child: Column(
                children: [
                  const SizedBox(
                    height: 80,
                  ),
                  Image.asset(
                    "assets/images/checked.png",
                    height: 140,
                    width: 140,
                  ),
                  const SizedBox(
                    height: 10,
                  ),
                  CustomText(
                    text: "Payment Confirmed",
                    size: 20,
                    color: greyTextColor,
                    family: mediumFont,
                  ),
                  const SizedBox(
                    height: 40,
                  ),
                  CustomText(
                    text:
                        "Your order is confirmed you will receive an order confirmation email/SMS shortly with the expaceted delivery date your items",
                    size: 14,
                    color: greyTextColor,
                  ),
                  const SizedBox(
                    height: 25,
                  ),
                  CommonButton(
                      onPressed: () {
                        provider.changeViewNotifier(DashboardScreenView.HOME);
                        Provider.of<HomeProvider>(context, listen: false)
                            .updateCartCount(0);
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                            builder: (BuildContext context) =>
                                const DashboardScreen()));
                      },
                      buttonColor: primaryColor,
                      text: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.shopping_bag,
                            color: white,
                            size: 25,
                          ),
                          const SizedBox(
                            width: 3,
                          ),
                          CustomText(
                            text: "Countinue Shopping",
                            size: 14,
                            color: white,
                            family: mediumFont,
                          ),
                        ],
                      )),
                  const SizedBox(
                    height: 20,
                  ),
                  CommonButton(
                      onPressed: () async {
                        await Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) =>
                                const MyOrdersScreen()));
                        provider.changeViewNotifier(DashboardScreenView.HOME);
                        Provider.of<HomeProvider>(context, listen: false)
                            .updateCartCount(0);
                        Navigator.of(context).pushReplacement(MaterialPageRoute(
                            builder: (BuildContext context) =>
                                const DashboardScreen()));
                      },
                      buttonColor: Colors.green,
                      text: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Icon(
                            Icons.tag_faces_sharp,
                            color: white,
                            size: 25,
                          ),
                          const SizedBox(
                            width: 3,
                          ),
                          CustomText(
                            text: "View Order",
                            size: 14,
                            color: white,
                            family: mediumFont,
                          ),
                        ],
                      )),
                ],
              ),
            ));
          })),
    );
  }
}
