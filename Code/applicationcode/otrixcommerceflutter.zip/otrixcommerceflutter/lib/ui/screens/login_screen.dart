// ignore_for_file: use_build_context_synchronously

import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/dashboard_provider.dart';
import 'package:ecommerce/provider/home_provider.dart';
import 'package:ecommerce/ui/screens/register_screen.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_form_field.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class LoginScreen extends StatefulWidget {
  HomeProvider provider;
  bool? navigateToPushBack;

  LoginScreen({required this.provider, Key? key, this.navigateToPushBack})
      : super(key: key);

  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  bool passwordHide = true;
  var formKey = GlobalKey<FormState>();
  late HomeProvider provider;
  TextEditingController emailController = TextEditingController();
  TextEditingController passController = TextEditingController();

  @override
  void initState() {
    provider = widget.provider;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: null,
        
        body: Form(
          key: formKey,
          child: SafeArea(
            child: Padding(
              padding:
                  const EdgeInsets.symmetric(horizontal: 20.0, vertical: 30),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CustomText(
                      text: "Login Account",
                      family: mediumFont,
                      size: 28,
                    ),
                    CustomText(
                      text: "Enter your email and password to login",
                      family: regularFont,
                      color: greyTextColor,
                      size: 14,
                    ),
                    const SizedBox(
                      height: 20,
                    ),
                    CustomTextFormField(
                      hint: "Email Address",
                      controller: emailController,
                      validator: AppGlobal().emailValidator,
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    CustomTextFormField(
                      controller: passController,
                      hint: "Password",
                      isPassword: true,
                      obsecure: passwordHide,
                      onvisibilityChange: () {
                        setState(() {
                          passwordHide = !passwordHide;
                        });
                      },
                      validator: AppGlobal().passwordValidator,
                    ),
                    const SizedBox(
                      height: 10,
                    ),
                    CommonButton(
                        onPressed: () async {
                          if (formKey.currentState!.validate() &&
                              !provider.isLoginLoading) {
                            print({
                              "email": emailController.text.toString().trim(),
                              "password": passController.text.toString().trim(),
                              "creation": "D"
                            });
                            final result = await provider.loginUser({
                              "email": emailController.text.toString().trim(),
                              "password": passController.text.toString().trim(),
                              "creation": "D",
                              "firebase_token":
                                  await FirebaseMessaging.instance.getToken() ??
                                      ""
                            });
                            if (provider.isUserLoggedIn &&
                                widget.navigateToPushBack == true) {
                              Navigator.pop(context, "1");
                            }
                          }
                        },
                        text: provider.isLoginLoading
                            ? const SizedBox(
                                height: 20,
                                width: 20,
                                child: CircularProgressIndicator(
                                  color: white,
                                ))
                            : CustomText(
                                text: 'Login',
                                color: white,
                                weight: FontWeight.bold,
                                family: boldFont,
                                size: 18,
                              )),
                    const SizedBox(
                      height: 25,
                    ),
                    Align(
                      alignment: Alignment.center,
                      child: RichText(
                        textAlign: TextAlign.center,
                        text: TextSpan(
                            text: 'Don\'t have an account? ',
                            style: const TextStyle(
                                color: greyTextColor,
                                fontFamily: regularFont,
                                fontSize: 16),
                            children: [
                              TextSpan(
                                  text: 'Sign Up',
                                  style: const TextStyle(
                                      color: primaryColor,
                                      fontWeight: FontWeight.w700),
                                  recognizer: TapGestureRecognizer()
                                    ..onTap = () async {
                                      if (widget.navigateToPushBack == true) {
                                        final result = await Navigator.of(
                                                context)
                                            .push(MaterialPageRoute(
                                                builder: (BuildContext
                                                        context) =>
                                                    RegisterScreen(
                                                        navigateToPushBack: widget
                                                            .navigateToPushBack)));

                                        if (result == "1") {
                                          Navigator.pop(context, "1");
                                        }
                                      } else {
                                        Provider.of<DashboardProvider>(context,
                                                listen: false)
                                            .changeViewNotifier(
                                                DashboardScreenView.REGISTER);
                                      }
                                    }),
                            ]),
                      ),
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    Row(
                      children: [
                        Expanded(
                            child: Container(
                          height: 1,
                          width: double.maxFinite,
                          color: greyTextColor,
                        )),
                        const SizedBox(
                          width: 10,
                        ),
                        CustomText(
                          text: "OR",
                          family: mediumFont,
                          size: 18,
                          color: greyTextColor,
                        ),
                        const SizedBox(
                          width: 10,
                        ),
                        Expanded(
                            child: Container(
                          height: 1,
                          width: double.maxFinite,
                          color: greyTextColor,
                        )),
                      ],
                    ),
                    const SizedBox(
                      height: 25,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        InkWell(
                          onTap: () async {
                            await provider.googleLogin();

                            if (provider.isUserLoggedIn &&
                                widget.navigateToPushBack == true) {
                              // ignore: use_build_context_synchronously
                              Navigator.pop(context, "1");
                            }
                          },
                          child: Container(
                            height: 35,
                            width: 35,
                            color: white,
                            child: Padding(
                              padding: const EdgeInsets.all(5.0),
                              child: Image.asset(
                                "assets/images/google.png",
                                height: 25,
                                width: 25,
                              ),
                            ),
                          ),
                        ),
                        const SizedBox(
                          width: 20,
                        ),
                        Image.asset(
                          "assets/images/facebook.jpg",
                          height: 35,
                          width: 35,
                          fit: BoxFit.fill,
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ));
  }
}
