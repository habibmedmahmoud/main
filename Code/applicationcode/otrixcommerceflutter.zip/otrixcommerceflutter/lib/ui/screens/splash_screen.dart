import 'dart:async';
import 'dart:io';

import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/network/api_manager.dart';
import 'package:ecommerce/provider/app_provider.dart';
import 'package:ecommerce/ui/screens/dashboard_screen.dart';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  double begin = 1.0;
  double end = 0.0;

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((timeStamp) {
      Provider.of<AppProvider>(context, listen: false);
    });
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )
      ..forward()
      ..addListener(() {
        if (_controller.isCompleted) {
          double st = begin;
          begin = end;
          end = st;
          _animation = Tween(
            begin: begin,
            end: end,
          ).animate(_controller);
          _controller.repeat();
        }
      });
    //Implement animation here
    _animation = Tween(
      begin: begin,
      end: end,
    ).animate(_controller);
    super.initState();
    configureDio();
    Timer(const Duration(seconds: 3), () => checkLogin());
  }

  configureDio() async {
    Directory appDocDir = await getApplicationDocumentsDirectory();
    String appdocPath = appDocDir.path;

    await ApiManager().configureDio(appdocPath);
  }

  Widget logoWidget() {
    _controller.forward();
    return Container(
      color: commonBackgroundColor,
      height: MediaQuery.of(context).size.height,
      child: Center(
        child: FadeTransition(
          opacity: _animation,
          child: Image.asset("assets/images/splash_logo.png"),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      
      body: logoWidget(),
    );
  }

  checkLogin() async {
    Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (BuildContext context) => const DashboardScreen()));
  }
}
