// ignore_for_file: must_be_immutable

import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/address/address_model.dart';
import 'package:ecommerce/provider/address_provider.dart';
import 'package:ecommerce/ui/screens/add_address_screen.dart';
import 'package:ecommerce/ui/widgets/address_item_widget.dart';
import 'package:ecommerce/ui/widgets/common_button.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:flutter/material.dart';

class AddressListScreen extends StatelessWidget {
  AddressProvider provider;

  AddressListScreen(this.provider, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding:
            const EdgeInsets.only(left: 15.0, right: 15, top: 15, bottom: 5),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const SizedBox(
            height: 15,
          ),
          Row(
            children: [
              GestureDetector(
                onTap: () => Navigator.pop(context),
                child: Card(
                  shape: RoundedRectangleBorder(
                    side: const BorderSide(color: Colors.white, width: 1),
                    borderRadius: BorderRadius.circular(25),
                  ),
                  child: SizedBox(
                      height: 30,
                      width: 30,
                      child: Padding(
                        padding: const EdgeInsets.all(5.5),
                        child: Image.asset(
                          "assets/images/back.png",
                          width: 30,
                          height: 30,
                        ),
                      )),
                ),
              ),
              const SizedBox(
                width: 20,
              ),
              Expanded(
                child: CustomText(
                  text: "Manage Address",
                  color: black,
                  family: boldFont,
                  size: 22,
                ),
              ),
              const SizedBox(
                width: 10,
              ),
            ],
          ),
          const SizedBox(
            height: 15,
          ),
          CustomText(
            text: "Your Address",
            color: black,
            family: mediumFont,
            size: 16,
          ),
          const SizedBox(
            height: 20,
          ),
          provider.isListLoading
              ? const Expanded(
                  child: Center(
                    child: CircularProgressIndicator(),
                  ),
                )
              : Expanded(
                  child: ListView.separated(
                    padding: EdgeInsets.zero,
                    itemBuilder: (context, index) {
                      return AddressItemWidget(
                        addressModel: provider.addressList[index],
                        isDeleteVisible: true,
                        onDelete: () {
                          deleteAddressDialog(
                              context, provider.addressList[index]);
                        },
                        onEdit: () {
                          Navigator.of(context).push(MaterialPageRoute(
                              builder: (BuildContext context) =>
                                  AddAddressScreen(
                                    provider,
                                    addressModel: provider.addressList[index],
                                  )));
                        },
                      );
                    },
                    itemCount: provider.addressList.length,
                    separatorBuilder: (BuildContext context, int index) {
                      return const SizedBox(
                        height: 10,
                      );
                    },
                  ),
                ),
          const SizedBox(
            height: 15,
          ),
          CommonButton(
              onPressed: () {
                Navigator.of(context).push(MaterialPageRoute(
                    builder: (BuildContext context) =>
                        AddAddressScreen(provider)));
                //provider.changeAdd(true);
              },
              text: CustomText(
                text: '+ Add',
                color: white,
                family: mediumFont,
                size: 15,
              )),
          const SizedBox(
            height: 15,
          ),
        ]));
  }

  deleteAddressDialog(BuildContext context, AddressModel addressItem) {
    Dialog errorDialog = Dialog(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.0)),
      //this right here
      child: Container(
        // height: 300.0,
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 15),

        width: double.maxFinite,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            const SizedBox(
              height: 10,
            ),
            const Text(
              'Confirm',
              style: TextStyle(
                  color: greyTextColor, fontSize: 16, fontFamily: mediumFont),
            ),
            const SizedBox(
              height: 10,
            ),
            const Text(
              'Are you sure want to delete?',
              style: TextStyle(
                  color: greyTextColor, fontSize: 14, fontFamily: regularFont),
            ),
            const SizedBox(
              height: 15,
            ),
            Row(
              children: [
                Expanded(
                  child: CommonButton(
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                    text: const Text(
                      'No Cancel',
                      style: TextStyle(color: Colors.white),
                    ),
                    buttonColor: grey,
                  ),
                ),
                const SizedBox(
                  width: 10,
                ),
                Expanded(
                  child: CommonButton(
                    onPressed: () async {
                      provider.deleteAddress(addressItem).then((value) {
                        if (!value) {
                          deleteAddressDialog(context, addressItem);
                        }
                      });
                      Navigator.of(context).pop();
                    },
                    text: const Text(
                      'Yes, delete it',
                      style: TextStyle(color: Colors.white),
                    ),
                    buttonColor: Colors.red,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
    showDialog(
        context: context, builder: (BuildContext context) => errorDialog);
  }
}
