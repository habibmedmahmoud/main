import 'dart:convert';

import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/provider/product_list_provider.dart';
import 'package:ecommerce/ui/screens/filter_screen.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/product_list_loading.dart';
import 'package:ecommerce/ui/widgets/product_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shimmer/shimmer.dart';

// ignore: must_be_immutable
class ProductListScreen extends StatefulWidget {
  bool showFilter;
  bool isPagination;
  String url;
  String title;

  ProductListScreen(
      {Key? key,
      required this.showFilter,
      required this.isPagination,
      required this.url,
      required this.title})
      : super(key: key);

  @override
  State<ProductListScreen> createState() => _ProductListScreenState();
}

class _ProductListScreenState extends State<ProductListScreen> {
  double itemWidth = 0;
  int page = 1, lastPage = 1;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    itemWidth = (MediaQuery.of(context).size.width / 2);
    return ChangeNotifierProvider<ProductListProvider>(
      create: (context) => ProductListProvider(
          widget.showFilter, widget.isPagination, widget.url, widget.title),
      child: Scaffold(
        appBar: null,
        
        body: SafeArea(
          child: Consumer<ProductListProvider>(
              builder: (context, provider, child) {
            page = provider.page;
            lastPage = provider.page;
            return Padding(
              padding: const EdgeInsets.only(
                  left: 15.0, right: 15, top: 15, bottom: 5),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const SizedBox(
                    height: 15,
                  ),
                  Row(
                    children: [
                      GestureDetector(
                        onTap: () => Navigator.pop(context),
                        child: Card(
                          shape: RoundedRectangleBorder(
                            side:
                                const BorderSide(color: Colors.white, width: 1),
                            borderRadius: BorderRadius.circular(25),
                          ),
                          child: SizedBox(
                              height: 30,
                              width: 30,
                              child: Padding(
                                padding: const EdgeInsets.all(5.5),
                                child: Image.asset(
                                  "assets/images/back.png",
                                  width: 30,
                                  height: 30,
                                ),
                              )),
                        ),
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      Expanded(
                        child: CustomText(
                          text: widget.title,
                          color: black,
                          family: boldFont,
                          size: 26,
                        ),
                      ),
                      const SizedBox(
                        width: 20,
                      ),
                      if (widget.showFilter)
                        GestureDetector(
                          onTap: () async {
                            final result = await Navigator.of(context).push(
                                MaterialPageRoute(
                                    builder: (BuildContext context) =>
                                        FilterScreen(
                                          selectedPrice: provider.selectedPrice,
                                          selectedRangeStart:
                                              provider.selectedRangeStart,
                                          selectedRangeEnd:
                                              provider.selectedRangeEnd,
                                          selectedStar: provider.selectedStar,
                                          rageLimit: provider.rageLimit,
                                        )));
                            if (result != null) {
                              Map<String, dynamic> data = {
                                "selectedPrice": provider.selectedPrice,
                                "selectedRangeStart":
                                    provider.selectedRangeStart,
                                "selectedRangeEnd": provider.selectedRangeEnd,
                                "selectedStar": provider.selectedStar,
                              };
                              try {
                                Map<String, dynamic> data = jsonDecode(result);

                                provider.updateFilterData(
                                  selectedPrice: data["selectedPrice"],
                                  selectedRangeStart:
                                      data["selectedRangeStart"],
                                  selectedRangeEnd: data["selectedRangeEnd"],
                                  selectedStar: data["selectedStar"],
                                );
                              } catch (ex) {
                                print("exception === ${ex.toString()}");
                              }
                            }
                          },
                          child: Card(
                            shape: RoundedRectangleBorder(
                              side: const BorderSide(
                                  color: Colors.white, width: 1),
                              borderRadius: BorderRadius.circular(25),
                            ),
                            child: SizedBox(
                                height: 30,
                                width: 30,
                                child: Padding(
                                  padding: const EdgeInsets.all(6),
                                  child: Image.asset(
                                    "assets/images/filter.png",
                                    width: 30,
                                    height: 30,
                                  ),
                                )),
                          ),
                        ),
                    ],
                  ),
                  const SizedBox(
                    height: 15,
                  ),
                  provider.isLoading
                      ? Expanded(
                          child: Shimmer.fromColors(
                            baseColor: Colors.grey[300]!,
                            highlightColor: Colors.grey[100]!,
                            // enabled: _enabled,
                            child: const SingleChildScrollView(
                              physics: NeverScrollableScrollPhysics(),
                              child: ProductListLoadingView(),
                            ),
                          ),
                        )
                      : provider.productsList.isEmpty
                          ? Expanded(
                              child: SizedBox(
                                width: double.maxFinite,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Image.asset(
                                      "assets/images/box.png",
                                      color: greyTextColor,
                                      height: 250,
                                      width: 250,
                                    ),
                                    const SizedBox(
                                      height: 15,
                                    ),
                                    CustomText(
                                      text: "No Products Found!",
                                      color: greyTextColor,
                                      family: mediumFont,
                                      size: 14,
                                    )
                                  ],
                                ),
                              ),
                            )
                          : Expanded(
                              child: NotificationListener<ScrollNotification>(
                                onNotification: (scrollInfo) =>
                                    _scrollNotification(scrollInfo, provider),
                                child: RefreshIndicator(
                                  onRefresh: () async {
                                    if (provider.isPagination) {
                                      await provider
                                          .callToGetPaginationProductList(1);
                                    } else {
                                      await provider
                                          .callToGetNonPaginationProductList();
                                    }
                                  },
                                  child: GridView.builder(
                                      shrinkWrap: true,
                                      gridDelegate:
                                          SliverGridDelegateWithMaxCrossAxisExtent(
                                              mainAxisExtent: 240,
                                              maxCrossAxisExtent:
                                                  itemWidth < 280
                                                      ? itemWidth
                                                      : 280),
                                      itemBuilder: (context, index) {
                                        return HomeProductWidget(
                                          products:
                                              provider.productsList[index],
                                          itemHeight:
                                              itemWidth < 280 ? itemWidth : 280,
                                          itemWidth:
                                              itemWidth < 280 ? itemWidth : 280,
                                        );
                                      },
                                      itemCount: provider.productsList.length),
                                ),
                              ),
                            ),
                  if (provider.isMoreLoading)
                    const Center(child: CircularProgressIndicator()),
                ],
              ),
            );
          }),
        ),
      ),
    );
  }

  bool _scrollNotification(
      ScrollNotification scrollInfo, ProductListProvider provider) {
    if (!provider.isMoreLoading &&
        scrollInfo.metrics.pixels == scrollInfo.metrics.maxScrollExtent &&
        provider.page < provider.lastPage) {
      provider.callToGetPaginationProductList(++provider.page);
    }
    return true;
  }
}
