import 'package:ecommerce/core/MyBehavior.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/ui/screens/settings/pages_screen.dart';
import 'package:ecommerce/ui/screens/settings/notificaiton_setting_screen.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/setting_screen_item.dart';
import 'package:flutter/material.dart';
import 'package:flutter_vector_icons/flutter_vector_icons.dart';

class SettingScreen extends StatefulWidget {
  const SettingScreen({Key? key}) : super(key: key);

  @override
  State<SettingScreen> createState() => _SettingScreenState();
}

class _SettingScreenState extends State<SettingScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: null,
      
      body: Padding(
        padding:
            const EdgeInsets.only(left: 15.0, right: 15, top: 15, bottom: 5),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(
                bottom: 15,
                left: 7.0,
                right: 7,
              ),
              child: CustomText(
                text: 'Settings',
                color: black,
                family: boldFont,
                size: 26,
              ),
            ),
            Expanded(
              child: ScrollConfiguration(
                behavior: MyBehavior(),
                child: SingleChildScrollView(
                    child: Column(
                  children: [
                    /*  SettingItemWidget(
                      title: 'Language',
                      iconImage: FontAwesome.language,
                      onItemClick: () => {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) =>
                                LanguageScreen())),
                      },
                    ),*/
                    SettingItemWidget(
                      title: 'Notification Setting',
                      iconImage: Ionicons.notifications_outline,
                      onItemClick: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) =>
                                NotificationSettingScreen()));
                      },
                    ),
                    SettingItemWidget(
                      title: 'Terms and Conditions',
                      iconImage: FontAwesome.file_text_o,
                      onItemClick: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) => PagesScreen(
                                pageNumber: 2, title: 'Terms and Conditions')));
                      },
                    ),
                    SettingItemWidget(
                      title: 'Privacy Policy',
                      iconImage: MaterialIcons.privacy_tip,
                      onItemClick: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) => PagesScreen(
                                pageNumber: 1, title: 'Privacy Policy')));
                      },
                    ),
                    SettingItemWidget(
                      title: 'Return & Refund Policy',
                      iconImage: MaterialIcons.rotate_left,
                      onItemClick: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) => PagesScreen(
                                pageNumber: 3,
                                title: 'Return & Refund Policy')));
                      },
                    ),
                    SettingItemWidget(
                      title: 'Shipping & Delivery Policy',
                      iconImage: FontAwesome5Solid.shipping_fast,
                      onItemClick: () {
                        Navigator.of(context).push(MaterialPageRoute(
                            builder: (BuildContext context) => PagesScreen(
                                pageNumber: 4,
                                title: 'Shipping & Delivery Policy')));
                      },
                    ),
                    SettingItemWidget(
                      title: 'Rate Otrixapp',
                      iconImage: FontAwesome.star_o,
                      onItemClick: () {},
                    ),
                    SettingItemWidget(
                      title: 'Share this App',
                      iconImage: Ionicons.share_social,
                      onItemClick: () {},
                    ),
                  ],
                )),
              ),
            ),
            Container(
              width: double.maxFinite,
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Image.asset(
                    "assets/images/logo.png",
                    height: 40,
                  ),
                  const SizedBox(
                    height: 5,
                  ),
                  CustomText(
                    text: 'Version: 1.0',
                    color: greyTextColor,
                    family: regularFont,
                    size: 10,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
