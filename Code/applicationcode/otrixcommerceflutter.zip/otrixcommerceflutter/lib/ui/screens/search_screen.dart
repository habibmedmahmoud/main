import 'package:ecommerce/core/AppGlobal.dart';
import 'package:ecommerce/core/common.dart';
import 'package:ecommerce/models/home_model/ResponseHome.dart';
import 'package:ecommerce/provider/SearchProvider.dart';
import 'package:ecommerce/ui/screens/product_detail_screen.dart';
import 'package:ecommerce/ui/widgets/custom_text_form_field.dart';
import 'package:ecommerce/ui/widgets/custom_text_view.dart';
import 'package:ecommerce/ui/widgets/search_item_widget.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class SearchScreen extends StatefulWidget {
  const SearchScreen({Key? key}) : super(key: key);

  @override
  State<SearchScreen> createState() => _SearchScreenState();
}

class _SearchScreenState extends State<SearchScreen> {
  TextEditingController searchController = TextEditingController();
  var formKey = GlobalKey<FormState>();

  List<String> searchItems = [
    "Smart watch",
    "Shoes",
    "Bag",
    "Cap",
    "Sun Glass",
    "Mac",
    "Shirt for men",
    "Perfume",
    "Cloth"
  ];

  @override
  void initState() {
    super.initState();
  }

  @override
  void dispose() {
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider<SearchProvider>(
      create: (context) => SearchProvider(context),
      child: Scaffold(
        body: Consumer<SearchProvider>(builder: (context, provider, child) {
          return SafeArea(
            child: Form(
              key: formKey,
              child: Padding(
                  padding: const EdgeInsets.only(
                      left: 15.0, right: 15, top: 15, bottom: 5),
                  child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(
                          height: 15,
                        ),
                        Row(
                          children: [
                            GestureDetector(
                              onTap: () => Navigator.pop(context),
                              child: Card(
                                shape: RoundedRectangleBorder(
                                  side: const BorderSide(
                                      color: Colors.white, width: 1),
                                  borderRadius: BorderRadius.circular(25),
                                ),
                                child: SizedBox(
                                    height: 30,
                                    width: 30,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8),
                                      child: Image.asset(
                                        "assets/images/back.png",
                                        width: 20,
                                        height: 20,
                                      ),
                                    )),
                              ),
                            ),
                            const SizedBox(
                              width: 20,
                            ),
                            Expanded(
                              child: CustomTextFormField(
                                hint: "Search Product",
                                controller: searchController,
                                validator: (val) => AppGlobal()
                                    .valueValidator(val, "Enter product name"),
                                onChange: (value) {
                                  provider.searchProduct(value);
                                },
                              ),
                            ),
                            const SizedBox(
                              width: 10,
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 15,
                        ),
                        provider.searchQuery.isEmpty
                            ? Container(
                                width: double.maxFinite,
                                decoration: const BoxDecoration(
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10)),
                                  color: white,
                                ),
                                padding: const EdgeInsets.symmetric(
                                    horizontal: 10.0, vertical: 10),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Align(
                                      alignment: Alignment.centerLeft,
                                      child: CustomText(
                                        text: "Most Searches",
                                        family: mediumFont,
                                        size: 16,
                                      ),
                                    ),
                                    const SizedBox(
                                      height: 10,
                                    ),
                                    Wrap(
                                      alignment: WrapAlignment.center,
                                      crossAxisAlignment:
                                          WrapCrossAlignment.center,
                                      spacing: 15,
                                      runSpacing: 10,
                                      children: searchItems
                                          .map((e) => InkWell(
                                                onTap: () {
                                                  searchController.text = e;
                                                  provider.searchProduct(e);
                                                },
                                                child: Container(
                                                  decoration: BoxDecoration(
                                                    borderRadius:
                                                        const BorderRadius.all(
                                                            Radius.circular(
                                                                10)),
                                                    color: greyTextColor
                                                        .withOpacity(0.1),
                                                  ),
                                                  padding: const EdgeInsets
                                                          .symmetric(
                                                      horizontal: 10.0,
                                                      vertical: 8),
                                                  child: CustomText(
                                                    text: e,
                                                    family: mediumFont,
                                                    color: greyTextColor,
                                                    size: 12,
                                                  ),
                                                ),
                                              ))
                                          .toList(),
                                    )
                                  ],
                                ),
                              )
                            : Expanded(
                                child: provider.searching
                                    ? const Center(
                                        child: CircularProgressIndicator(),
                                      )
                                    : ListView.builder(
                                        shrinkWrap: true,
                                        itemBuilder:
                                            (BuildContext context, int index) {
                                          return SearchProductItem(
                                            product: provider
                                                .searchProductList[index],
                                            openProduct: () {
                                              if (provider
                                                      .searchProductList[index]
                                                      .productDescription !=
                                                  null) {
                                                Navigator.of(context).push(MaterialPageRoute(
                                                    builder: (BuildContext
                                                            context) =>
                                                        ProductDetailScreen(
                                                            productId: provider
                                                                .searchProductList[
                                                                    index]
                                                                .productDescription!
                                                                .productId!)));
                                              }
                                            },
                                          );
                                        },
                                        itemCount:
                                            provider.searchProductList.length,
                                      ))
                      ])),
            ),
          );
        }),
      ),
    );
  }
}
